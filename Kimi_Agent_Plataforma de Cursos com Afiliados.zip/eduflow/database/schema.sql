-- ==========================================
-- EduFlow - Schema do Banco de Dados
-- PostgreSQL 14+
-- ==========================================

-- Habilitar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==========================================
-- TABELAS PRINCIPAIS
-- ==========================================

-- Usuários
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    full_name VARCHAR(200) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255),
    phone VARCHAR(20),
    avatar VARCHAR(255),
    document_type VARCHAR(10) CHECK (document_type IN ('cpf', 'cnpj')),
    document VARCHAR(20) UNIQUE,
    birth_date DATE,
    role VARCHAR(20) DEFAULT 'customer' CHECK (role IN ('master', 'producer', 'affiliate', 'customer')),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('active', 'inactive', 'pending', 'blocked', 'suspended')),
    email_verified BOOLEAN DEFAULT FALSE,
    email_verification_token VARCHAR(255),
    email_verification_expires TIMESTAMP,
    password_reset_token VARCHAR(255),
    password_reset_expires TIMESTAMP,
    two_factor_enabled BOOLEAN DEFAULT FALSE,
    two_factor_secret VARCHAR(255),
    two_factor_verified BOOLEAN DEFAULT FALSE,
    -- Endereço
    address VARCHAR(255),
    address_number VARCHAR(20),
    complement VARCHAR(100),
    neighborhood VARCHAR(100),
    city VARCHAR(100),
    state VARCHAR(2),
    zip_code VARCHAR(10),
    country VARCHAR(100) DEFAULT 'Brasil',
    -- Dados bancários
    bank_name VARCHAR(100),
    bank_code VARCHAR(10),
    agency VARCHAR(20),
    account_number VARCHAR(20),
    account_type VARCHAR(20),
    pix_key VARCHAR(255),
    -- Contas de pagamento
    stripe_account_id VARCHAR(255),
    mercado_pago_account_id VARCHAR(255),
    -- Social login
    google_id VARCHAR(255),
    facebook_id VARCHAR(255),
    -- Notificações
    email_notifications BOOLEAN DEFAULT TRUE,
    marketing_emails BOOLEAN DEFAULT TRUE,
    affiliate_notifications BOOLEAN DEFAULT TRUE,
    -- Metadados
    metadata JSONB,
    last_ip INET,
    last_login_at TIMESTAMP,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Categorias
CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    image VARCHAR(255),
    icon VARCHAR(255),
    color VARCHAR(7),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    sort_order INTEGER DEFAULT 0,
    parent_id UUID REFERENCES categories(id),
    meta_title VARCHAR(255),
    meta_description TEXT,
    meta_keywords VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Produtos
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(200) UNIQUE NOT NULL,
    description TEXT,
    short_description TEXT,
    type VARCHAR(20) DEFAULT 'digital' CHECK (type IN ('digital', 'course', 'ebook', 'software', 'membership', 'bundle')),
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'pending', 'approved', 'rejected', 'published', 'unpublished', 'suspended')),
    price DECIMAL(10, 2) NOT NULL,
    compare_price DECIMAL(10, 2),
    cost_price DECIMAL(10, 2),
    currency VARCHAR(3) DEFAULT 'BRL',
    -- Mídia
    cover_image VARCHAR(255),
    gallery_images TEXT[],
    preview_video VARCHAR(255),
    sales_video VARCHAR(255),
    -- Arquivos
    main_file VARCHAR(255),
    additional_files TEXT[],
    file_size BIGINT,
    -- Comissões
    commission_type VARCHAR(20) DEFAULT 'percentage' CHECK (commission_type IN ('fixed', 'percentage')),
    commission_rate DECIMAL(5, 2) DEFAULT 30,
    commission_fixed DECIMAL(10, 2),
    platform_fee DECIMAL(5, 2) DEFAULT 10,
    -- Afiliados
    allow_affiliates BOOLEAN DEFAULT TRUE,
    affiliate_approval_required BOOLEAN DEFAULT FALSE,
    approved_affiliates UUID[],
    blocked_affiliates UUID[],
    -- SEO
    meta_title VARCHAR(255),
    meta_description TEXT,
    meta_keywords VARCHAR(500),
    sales_page_html TEXT,
    thank_you_page_html TEXT,
    -- Configurações
    guarantee_days INTEGER DEFAULT 7,
    has_unlimited_access BOOLEAN DEFAULT TRUE,
    access_duration INTEGER,
    max_downloads INTEGER DEFAULT 0,
    is_featured BOOLEAN DEFAULT FALSE,
    sort_order INTEGER DEFAULT 0,
    -- Estoque
    stock INTEGER,
    track_inventory BOOLEAN DEFAULT FALSE,
    -- Estatísticas
    view_count INTEGER DEFAULT 0,
    sales_count INTEGER DEFAULT 0,
    total_revenue DECIMAL(15, 2) DEFAULT 0,
    average_rating DECIMAL(3, 2),
    review_count INTEGER DEFAULT 0,
    -- Relacionamentos
    producer_id UUID NOT NULL REFERENCES users(id),
    category_id UUID REFERENCES categories(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    published_at TIMESTAMP
);

-- Cursos
CREATE TABLE courses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(200) UNIQUE NOT NULL,
    description TEXT,
    short_description TEXT,
    what_you_will_learn TEXT,
    requirements TEXT,
    target_audience TEXT,
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'pending', 'approved', 'published', 'unpublished')),
    level VARCHAR(20) DEFAULT 'all_levels' CHECK (level IN ('beginner', 'intermediate', 'advanced', 'all_levels')),
    currency VARCHAR(3) DEFAULT 'BRL',
    -- Mídia
    cover_image VARCHAR(255),
    trailer_video VARCHAR(255),
    -- Relacionamentos
    product_id UUID REFERENCES products(id),
    category_id UUID REFERENCES categories(id),
    -- Conteúdo
    total_duration INTEGER DEFAULT 0,
    lesson_count INTEGER DEFAULT 0,
    module_count INTEGER DEFAULT 0,
    -- Configurações
    has_certificate BOOLEAN DEFAULT TRUE,
    has_lifetime_access BOOLEAN DEFAULT TRUE,
    access_duration INTEGER,
    allow_download BOOLEAN DEFAULT TRUE,
    allow_discussion BOOLEAN DEFAULT TRUE,
    price DECIMAL(10, 2),
    -- SEO
    meta_title VARCHAR(255),
    meta_description TEXT,
    meta_keywords VARCHAR(500),
    -- Estatísticas
    enrollment_count INTEGER DEFAULT 0,
    completion_count INTEGER DEFAULT 0,
    average_rating DECIMAL(3, 2),
    review_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    published_at TIMESTAMP
);

-- Módulos de curso
CREATE TABLE modules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    sort_order INTEGER DEFAULT 0,
    is_published BOOLEAN DEFAULT TRUE,
    is_free BOOLEAN DEFAULT FALSE,
    duration INTEGER DEFAULT 0,
    lesson_count INTEGER DEFAULT 0,
    course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Aulas
CREATE TABLE lessons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(200) NOT NULL,
    description TEXT,
    type VARCHAR(20) DEFAULT 'video' CHECK (type IN ('video', 'audio', 'text', 'pdf', 'quiz', 'assignment', 'live')),
    sort_order INTEGER DEFAULT 0,
    is_published BOOLEAN DEFAULT TRUE,
    is_free BOOLEAN DEFAULT FALSE,
    -- Vídeo
    video_provider VARCHAR(20) DEFAULT 'local' CHECK (video_provider IN ('local', 'youtube', 'vimeo', 'wistia', 'pandavideo')),
    video_url VARCHAR(255),
    video_file VARCHAR(255),
    video_size BIGINT,
    duration INTEGER,
    thumbnail VARCHAR(255),
    video_id VARCHAR(100),
    -- Conteúdo
    content TEXT,
    attachments JSONB,
    downloads JSONB,
    quiz_data JSONB,
    -- Ao vivo
    live_start_time TIMESTAMP,
    live_end_time TIMESTAMP,
    live_url VARCHAR(255),
    recording_url VARCHAR(255),
    -- Configurações
    allow_comments BOOLEAN DEFAULT FALSE,
    allow_download BOOLEAN DEFAULT TRUE,
    is_preview BOOLEAN DEFAULT FALSE,
    drip_days INTEGER,
    drip_after_lesson_id UUID,
    -- Estatísticas
    view_count INTEGER DEFAULT 0,
    completion_count INTEGER DEFAULT 0,
    module_id UUID NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Afiliados
CREATE TABLE affiliates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(50) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'blocked', 'suspended')),
    tier VARCHAR(20) DEFAULT 'bronze' CHECK (tier IN ('bronze', 'silver', 'gold', 'platinum', 'diamond')),
    -- Bio e marketing
    bio TEXT,
    website VARCHAR(255),
    social_media TEXT[],
    traffic_source VARCHAR(255),
    marketing_strategy TEXT,
    -- Comissões
    custom_commission_rate DECIMAL(5, 2),
    has_custom_commission BOOLEAN DEFAULT FALSE,
    -- Estatísticas
    total_clicks INTEGER DEFAULT 0,
    total_conversions INTEGER DEFAULT 0,
    conversion_rate DECIMAL(5, 2) DEFAULT 0,
    total_commission DECIMAL(15, 2) DEFAULT 0,
    pending_commission DECIMAL(15, 2) DEFAULT 0,
    available_commission DECIMAL(15, 2) DEFAULT 0,
    withdrawn_commission DECIMAL(15, 2) DEFAULT 0,
    total_sales DECIMAL(15, 2) DEFAULT 0,
    tier_sales_count INTEGER DEFAULT 0,
    tier_sales_amount DECIMAL(15, 2) DEFAULT 0,
    -- Aprovação
    rejection_reason TEXT,
    approved_by UUID,
    approved_at TIMESTAMP,
    -- Relacionamentos
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Links de afiliado
CREATE TABLE affiliate_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(100) UNIQUE NOT NULL,
    type VARCHAR(20) DEFAULT 'product' CHECK (type IN ('product', 'category', 'home', 'checkout', 'custom')),
    custom_url VARCHAR(500),
    title VARCHAR(255),
    description TEXT,
    utm_source VARCHAR(255),
    utm_medium VARCHAR(255),
    utm_campaign VARCHAR(255),
    utm_content VARCHAR(255),
    -- Estatísticas
    total_clicks INTEGER DEFAULT 0,
    unique_clicks INTEGER DEFAULT 0,
    total_conversions INTEGER DEFAULT 0,
    total_revenue DECIMAL(15, 2) DEFAULT 0,
    total_commission DECIMAL(15, 2) DEFAULT 0,
    conversion_rate DECIMAL(5, 2) DEFAULT 0,
    last_clicked_at TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    -- Relacionamentos
    affiliate_id UUID NOT NULL REFERENCES affiliates(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Vendas
CREATE TABLE sales (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_number VARCHAR(50) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'refunded', 'partially_refunded', 'cancelled', 'disputed', 'chargeback')),
    -- Preços
    original_price DECIMAL(10, 2) NOT NULL,
    discount_amount DECIMAL(10, 2) DEFAULT 0,
    final_price DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'BRL',
    -- Pagamento
    payment_method VARCHAR(20) CHECK (payment_method IN ('credit_card', 'debit_card', 'boleto', 'pix', 'bank_transfer', 'wallet', 'free')),
    payment_status VARCHAR(20) DEFAULT 'pending' CHECK (payment_status IN ('pending', 'authorized', 'paid', 'failed', 'refunded', 'cancelled')),
    payment_intent_id VARCHAR(255),
    payment_transaction_id VARCHAR(255),
    installments INTEGER DEFAULT 1,
    installment_amount DECIMAL(10, 2),
    paid_at TIMESTAMP,
    refunded_at TIMESTAMP,
    refunded_amount DECIMAL(10, 2),
    -- Taxas
    platform_fee DECIMAL(10, 2) DEFAULT 0,
    payment_fee DECIMAL(10, 2) DEFAULT 0,
    affiliate_commission DECIMAL(10, 2) DEFAULT 0,
    producer_revenue DECIMAL(10, 2) DEFAULT 0,
    -- Afiliado
    has_affiliate BOOLEAN DEFAULT FALSE,
    affiliate_code VARCHAR(100),
    affiliate_ip INET,
    affiliate_user_agent TEXT,
    affiliate_click_at TIMESTAMP,
    referrer VARCHAR(100),
    landing_page VARCHAR(255),
    utm_source VARCHAR(255),
    utm_medium VARCHAR(255),
    utm_campaign VARCHAR(255),
    -- Cliente (snapshot)
    customer_name VARCHAR(200) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20),
    customer_document VARCHAR(20),
    customer_ip INET NOT NULL,
    user_agent TEXT NOT NULL,
    fingerprint VARCHAR(100),
    is_self_purchase BOOLEAN DEFAULT FALSE,
    fraud_check JSONB,
    -- Garantia
    guarantee_days INTEGER DEFAULT 7,
    guarantee_expires_at TIMESTAMP,
    guarantee_claimed BOOLEAN DEFAULT FALSE,
    guarantee_claimed_at TIMESTAMP,
    -- Metadados
    metadata JSONB,
    notes TEXT,
    -- Relacionamentos
    customer_id UUID NOT NULL REFERENCES users(id),
    product_id UUID NOT NULL REFERENCES products(id),
    affiliate_id UUID REFERENCES affiliates(id),
    affiliate_link_id UUID REFERENCES affiliate_links(id),
    coupon_id UUID REFERENCES coupons(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Comissões
CREATE TABLE commissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type VARCHAR(20) DEFAULT 'affiliate' CHECK (type IN ('affiliate', 'producer', 'platform', 'bonus', 'tier_upgrade')),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'available', 'withdrawn', 'cancelled', 'refunded')),
    amount DECIMAL(10, 2) NOT NULL,
    rate DECIMAL(5, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'BRL',
    -- Venda
    sale_amount DECIMAL(10, 2) NOT NULL,
    order_number VARCHAR(50) NOT NULL,
    -- Produto
    product_name VARCHAR(200) NOT NULL,
    -- Timeline
    approved_at TIMESTAMP,
    approved_by UUID,
    available_at TIMESTAMP,
    withdrawn_at TIMESTAMP,
    withdrawal_id UUID,
    cancelled_at TIMESTAMP,
    cancellation_reason TEXT,
    refunded_at TIMESTAMP,
    -- Garantia
    guarantee_days INTEGER DEFAULT 7,
    guarantee_expires_at TIMESTAMP,
    guarantee_claimed BOOLEAN DEFAULT FALSE,
    -- Metadados
    metadata JSONB,
    notes TEXT,
    -- Relacionamentos
    affiliate_id UUID REFERENCES affiliates(id),
    producer_id UUID REFERENCES users(id),
    sale_id UUID NOT NULL REFERENCES sales(id),
    product_id UUID REFERENCES products(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Saques
CREATE TABLE withdrawals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reference_number VARCHAR(50) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'approved', 'rejected', 'completed', 'failed', 'cancelled')),
    method VARCHAR(20) CHECK (method IN ('bank_transfer', 'pix', 'paypal', 'stripe', 'mercado_pago')),
    amount DECIMAL(10, 2) NOT NULL,
    fee DECIMAL(10, 2) DEFAULT 0,
    net_amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'BRL',
    -- Dados bancários (snapshot)
    bank_name VARCHAR(100),
    bank_code VARCHAR(10),
    agency VARCHAR(20),
    account_number VARCHAR(20),
    account_type VARCHAR(20),
    pix_key VARCHAR(255),
    pix_key_type VARCHAR(50),
    -- Processamento
    processed_at TIMESTAMP,
    processed_by UUID,
    transaction_id VARCHAR(255),
    receipt_url VARCHAR(255),
    -- Rejeição
    rejection_reason TEXT,
    rejected_at TIMESTAMP,
    -- Falha
    failure_reason TEXT,
    failed_at TIMESTAMP,
    -- Comissões
    commission_ids UUID[] NOT NULL,
    commission_count INTEGER NOT NULL,
    -- Notas
    notes TEXT,
    admin_notes TEXT,
    -- Relacionamentos
    user_id UUID NOT NULL REFERENCES users(id),
    affiliate_id UUID REFERENCES affiliates(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Cupons
CREATE TABLE coupons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    type VARCHAR(20) DEFAULT 'percentage' CHECK (type IN ('percentage', 'fixed', 'free_shipping', 'buy_x_get_y')),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'expired', 'depleted', 'scheduled')),
    scope VARCHAR(20) DEFAULT 'global' CHECK (scope IN ('global', 'product', 'category', 'user')),
    -- Desconto
    discount_percentage DECIMAL(5, 2),
    discount_fixed DECIMAL(10, 2),
    max_discount_amount DECIMAL(10, 2),
    min_order_amount DECIMAL(10, 2),
    -- Limites
    max_uses INTEGER,
    used_count INTEGER DEFAULT 0,
    max_uses_per_user INTEGER,
    max_uses_per_product INTEGER,
    -- Validade
    start_date TIMESTAMP,
    end_date TIMESTAMP,
    -- Aplicabilidade
    applicable_product_ids UUID[],
    excluded_product_ids UUID[],
    applicable_category_ids UUID[],
    applicable_user_ids UUID[],
    first_purchase_only BOOLEAN DEFAULT FALSE,
    -- Afiliado
    is_affiliate_coupon BOOLEAN DEFAULT FALSE,
    affiliate_id UUID,
    affiliate_commission_override DECIMAL(5, 2),
    -- Estatísticas
    total_discount_given DECIMAL(15, 2) DEFAULT 0,
    total_revenue DECIMAL(15, 2) DEFAULT 0,
    -- Metadados
    metadata JSONB,
    -- Relacionamentos
    product_id UUID REFERENCES products(id),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Matrículas
CREATE TABLE enrollments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'completed', 'expired', 'cancelled', 'refunded', 'suspended')),
    completed_at TIMESTAMP,
    expires_at TIMESTAMP,
    progress_percentage INTEGER DEFAULT 0,
    completed_lessons INTEGER DEFAULT 0,
    total_lessons INTEGER DEFAULT 0,
    time_spent INTEGER DEFAULT 0,
    last_lesson_id INTEGER,
    last_accessed_at TIMESTAMP,
    last_access_ip INET,
    -- Certificado
    certificate_issued BOOLEAN DEFAULT FALSE,
    certificate_number VARCHAR(100),
    certificate_issued_at TIMESTAMP,
    certificate_url VARCHAR(255),
    -- Compra
    purchase_price DECIMAL(10, 2) NOT NULL,
    order_number VARCHAR(50) NOT NULL,
    -- Relacionamentos
    user_id UUID NOT NULL REFERENCES users(id),
    course_id UUID NOT NULL REFERENCES courses(id),
    product_id UUID REFERENCES products(id),
    sale_id UUID REFERENCES sales(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    UNIQUE(user_id, course_id)
);

-- Progresso
CREATE TABLE progress (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    progress_percentage INTEGER DEFAULT 0,
    time_spent INTEGER DEFAULT 0,
    last_position INTEGER,
    is_completed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMP,
    attempts INTEGER DEFAULT 0,
    quiz_results JSONB,
    notes TEXT,
    -- Relacionamentos
    enrollment_id UUID NOT NULL REFERENCES enrollments(id) ON DELETE CASCADE,
    lesson_id UUID NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(enrollment_id, lesson_id)
);

-- Avaliações
CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'rejected')),
    is_verified_purchase BOOLEAN DEFAULT FALSE,
    order_number VARCHAR(255),
    likes UUID[],
    likes_count INTEGER DEFAULT 0,
    dislikes UUID[],
    dislikes_count INTEGER DEFAULT 0,
    replies JSONB,
    is_highlighted BOOLEAN DEFAULT FALSE,
    highlight_order INTEGER,
    -- Moderação
    rejection_reason TEXT,
    moderated_by UUID,
    moderated_at TIMESTAMP,
    -- Relacionamentos
    user_id UUID NOT NULL REFERENCES users(id),
    product_id UUID REFERENCES products(id),
    course_id UUID REFERENCES courses(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    UNIQUE(user_id, product_id)
);

-- Configurações
CREATE TABLE configurations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key VARCHAR(100) UNIQUE NOT NULL,
    value TEXT NOT NULL,
    category VARCHAR(20) DEFAULT 'general' CHECK (category IN ('general', 'payment', 'affiliate', 'email', 'seo', 'security', 'appearance', 'integrations')),
    label VARCHAR(200) NOT NULL,
    description TEXT,
    type VARCHAR(20) DEFAULT 'string' CHECK (type IN ('string', 'number', 'boolean', 'json', 'array')),
    options JSONB,
    is_public BOOLEAN DEFAULT FALSE,
    is_editable BOOLEAN DEFAULT TRUE,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Logs
CREATE TABLE logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    level VARCHAR(20) NOT NULL CHECK (level IN ('debug', 'info', 'warn', 'error', 'fatal')),
    category VARCHAR(20) NOT NULL CHECK (category IN ('auth', 'user', 'product', 'sale', 'payment', 'affiliate', 'commission', 'withdrawal', 'system', 'security', 'api', 'webhook', 'email', 'database')),
    message TEXT NOT NULL,
    context JSONB,
    metadata JSONB,
    stack_trace TEXT,
    -- Usuário
    user_id UUID,
    user_email VARCHAR(255),
    user_role VARCHAR(100),
    -- Requisição
    method VARCHAR(10),
    path VARCHAR(500),
    request_body JSONB,
    request_headers JSONB,
    status_code INTEGER,
    response_time INTEGER,
    -- Cliente
    ip INET,
    user_agent TEXT,
    fingerprint VARCHAR(100),
    -- Entidade
    entity_type VARCHAR(50),
    entity_id UUID,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de favoritos (relação muitos-para-muitos)
CREATE TABLE user_favorites (
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, product_id)
);

-- Tabela de afiliados de produto (relação muitos-para-muitos)
CREATE TABLE product_affiliates (
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    affiliate_id UUID REFERENCES affiliates(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (product_id, affiliate_id)
);

-- ==========================================
-- ÍNDICES
-- ==========================================

-- Usuários
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_users_document ON users(document);

-- Produtos
CREATE INDEX idx_products_slug ON products(slug);
CREATE INDEX idx_products_status ON products(status);
CREATE INDEX idx_products_type ON products(type);
CREATE INDEX idx_products_producer ON products(producer_id);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_price ON products(price);
CREATE INDEX idx_products_featured ON products(is_featured);

-- Vendas
CREATE INDEX idx_sales_order_number ON sales(order_number);
CREATE INDEX idx_sales_status ON sales(status);
CREATE INDEX idx_sales_payment_status ON sales(payment_status);
CREATE INDEX idx_sales_customer ON sales(customer_id);
CREATE INDEX idx_sales_product ON sales(product_id);
CREATE INDEX idx_sales_affiliate ON sales(affiliate_id);
CREATE INDEX idx_sales_created_at ON sales(created_at);

-- Comissões
CREATE INDEX idx_commissions_status ON commissions(status);
CREATE INDEX idx_commissions_type ON commissions(type);
CREATE INDEX idx_commissions_affiliate ON commissions(affiliate_id);
CREATE INDEX idx_commissions_sale ON commissions(sale_id);
CREATE INDEX idx_commissions_available_at ON commissions(available_at);

-- Afiliados
CREATE INDEX idx_affiliates_code ON affiliates(code);
CREATE INDEX idx_affiliates_status ON affiliates(status);
CREATE INDEX idx_affiliates_tier ON affiliates(tier);
CREATE INDEX idx_affiliates_user ON affiliates(user_id);

-- Logs
CREATE INDEX idx_logs_level ON logs(level);
CREATE INDEX idx_logs_category ON logs(category);
CREATE INDEX idx_logs_user ON logs(user_id);
CREATE INDEX idx_logs_created_at ON logs(created_at);
CREATE INDEX idx_logs_ip ON logs(ip);

-- ==========================================
-- FUNÇÕES E TRIGGERS
-- ==========================================

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para atualizar updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON categories
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_courses_updated_at BEFORE UPDATE ON courses
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_modules_updated_at BEFORE UPDATE ON modules
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_lessons_updated_at BEFORE UPDATE ON lessons
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_affiliates_updated_at BEFORE UPDATE ON affiliates
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_affiliate_links_updated_at BEFORE UPDATE ON affiliate_links
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_sales_updated_at BEFORE UPDATE ON sales
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_commissions_updated_at BEFORE UPDATE ON commissions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_withdrawals_updated_at BEFORE UPDATE ON withdrawals
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_coupons_updated_at BEFORE UPDATE ON coupons
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_enrollments_updated_at BEFORE UPDATE ON enrollments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_reviews_updated_at BEFORE UPDATE ON reviews
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_configurations_updated_at BEFORE UPDATE ON configurations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ==========================================
-- DADOS INICIAIS
-- ==========================================

-- Usuário admin padrão (senha: Admin@123)
INSERT INTO users (
    id, first_name, last_name, full_name, email, password, role, status, email_verified
) VALUES (
    '00000000-0000-0000-0000-000000000001',
    'Administrador',
    'Master',
    'Administrador Master',
    'admin@eduflow.com.br',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/X4.VTtYA.qGZvKG6G',
    'master',
    'active',
    TRUE
);

-- Configurações padrão
INSERT INTO configurations (key, value, category, label, description, type) VALUES
('site_name', 'EduFlow', 'general', 'Nome do Site', 'Nome exibido no site', 'string'),
('site_description', 'Plataforma de cursos online', 'general', 'Descrição do Site', 'Descrição para SEO', 'string'),
('support_email', 'suporte@eduflow.com.br', 'general', 'E-mail de Suporte', 'E-mail para contato', 'string'),
('platform_fee', '10', 'payment', 'Taxa da Plataforma', 'Porcentagem cobrada em cada venda', 'number'),
('default_commission_rate', '30', 'affiliate', 'Comissão Padrão', 'Porcentagem padrão de comissão para afiliados', 'number'),
('guarantee_days', '7', 'general', 'Dias de Garantia', 'Prazo de garantia em dias', 'number'),
('min_withdrawal_amount', '50', 'affiliate', 'Saque Mínimo', 'Valor mínimo para saque', 'number'),
('enable_registration', 'true', 'security', 'Permitir Cadastro', 'Habilitar novos cadastros', 'boolean'),
('enable_email_verification', 'true', 'security', 'Verificação de E-mail', 'Exigir verificação de e-mail', 'boolean'),
('maintenance_mode', 'false', 'general', 'Modo de Manutenção', 'Ativar modo de manutenção', 'boolean');
