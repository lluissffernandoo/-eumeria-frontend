# Eumería - Plataforma de Cursos e Produtos Digitais

Eumería é uma plataforma completa para venda de cursos e produtos digitais com sistema de afiliados integrado.

## 🚀 Funcionalidades

### Para Administradores
- Dashboard completo com estatísticas
- Gerenciamento de usuários (Master Admin, Produtores, Afiliados, Clientes)
- Controle de produtos e cursos
- Relatórios de vendas e comissões
- Gestão de saques de afiliados
- Configurações da plataforma

### Para Produtores
- Criação e gestão de produtos digitais
- Criação de cursos com módulos e aulas
- Configuração de comissões para afiliados
- Relatórios de vendas e receita
- Controle de garantias

### Para Afiliados
- Geração de links de afiliado
- Tracking de cliques e conversões
- Dashboard de comissões
- Solicitação de saques
- Histórico de vendas

### Para Clientes
- Compra de produtos e cursos
- Área de membros com progresso
- Downloads de produtos digitais
- Histórico de compras
- Certificados de conclusão

## 🛠️ Tecnologias

### Backend
- **Framework:** NestJS com TypeScript
- **Banco de Dados:** PostgreSQL
- **ORM:** TypeORM
- **Autenticação:** JWT (Access + Refresh Tokens)
- **Pagamentos:** Stripe e Mercado Pago
- **Cache:** Redis
- **Documentação:** Swagger/OpenAPI

### Frontend
- **Framework:** React 18 com TypeScript
- **Build Tool:** Vite
- **Estilização:** Tailwind CSS
- **UI Components:** shadcn/ui
- **Gerenciamento de Estado:** React Context + Hooks
- **Roteamento:** React Router DOM
- **HTTP Client:** Axios

## 📁 Estrutura do Projeto

```
eumeria/
├── backend/
│   ├── src/
│   │   ├── modules/
│   │   │   ├── auth/           # Autenticação e autorização
│   │   │   ├── users/          # Gerenciamento de usuários
│   │   │   ├── products/       # Produtos digitais
│   │   │   ├── courses/        # Cursos, módulos e aulas
│   │   │   ├── sales/          # Vendas e checkout
│   │   │   ├── payments/       # Integração com gateways
│   │   │   ├── affiliates/     # Sistema de afiliados
│   │   │   ├── commissions/    # Cálculo de comissões
│   │   │   ├── withdrawals/    # Saques de afiliados
│   │   │   ├── coupons/        # Cupons de desconto
│   │   │   ├── members/        # Área de membros
│   │   │   ├── admin/          # Dashboard admin
│   │   │   └── upload/         # Upload de arquivos
│   │   ├── entities/           # Entidades TypeORM
│   │   ├── common/             # Guards, decorators, middlewares
│   │   └── config/             # Configurações
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── pages/              # Páginas da aplicação
│   │   │   ├── auth/           # Login, registro, recuperação
│   │   │   ├── dashboard/      # Dashboard do cliente
│   │   │   ├── admin/          # Painel administrativo
│   │   │   ├── producer/       # Painel do produtor
│   │   │   └── affiliate/      # Painel do afiliado
│   │   ├── components/         # Componentes reutilizáveis
│   │   ├── services/           # Serviços de API
│   │   ├── contexts/           # Contextos React
│   │   └── layouts/            # Layouts da aplicação
│   └── package.json
└── docker-compose.yml
```

## 🚀 Como Executar

### Pré-requisitos
- Node.js 18+
- PostgreSQL 14+
- Redis 7+

### Backend

```bash
cd backend

# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com suas configurações

# Executar migrações
npm run migration:run

# Iniciar em modo desenvolvimento
npm run start:dev

# Iniciar em modo produção
npm run build
npm run start:prod
```

### Frontend

```bash
cd frontend

# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com suas configurações

# Iniciar em modo desenvolvimento
npm run dev

# Build para produção
npm run build
```

### Docker

```bash
# Iniciar todos os serviços
docker-compose up -d

# Parar todos os serviços
docker-compose down
```

## ⚙️ Variáveis de Ambiente

### Backend (.env)
```env
# Aplicação
NODE_ENV=development
PORT=3001
API_PREFIX=/api/v1

# Banco de Dados
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=eumeria
DB_PASSWORD=eumeria123
DB_NAME=eumeria
DB_SSL=false

# JWT
JWT_SECRET=your-secret-key
JWT_EXPIRATION=15m
JWT_REFRESH_SECRET=your-refresh-secret
JWT_REFRESH_EXPIRATION=7d

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PUBLISHABLE_KEY=pk_test_...

# Mercado Pago
MERCADO_PAGO_ACCESS_TOKEN=TEST-...
MERCADO_PAGO_WEBHOOK_URL=https://your-domain.com/webhooks/mercado_pago

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# Frontend URL
FRONTEND_URL=http://localhost:5173
```

### Frontend (.env)
```env
VITE_API_URL=http://localhost:3001/api/v1
VITE_STRIPE_PUBLIC_KEY=pk_test_...
```

## 📚 API Endpoints

### Autenticação
- `POST /api/v1/auth/login` - Login
- `POST /api/v1/auth/register` - Registro
- `POST /api/v1/auth/logout` - Logout
- `POST /api/v1/auth/refresh` - Renovar token
- `POST /api/v1/auth/forgot-password` - Recuperar senha
- `POST /api/v1/auth/reset-password` - Redefinir senha

### Usuários
- `GET /api/v1/users` - Listar usuários
- `GET /api/v1/users/profile` - Perfil do usuário
- `PATCH /api/v1/users/profile` - Atualizar perfil
- `PATCH /api/v1/users/:id` - Atualizar usuário
- `DELETE /api/v1/users/:id` - Remover usuário

### Produtos
- `GET /api/v1/products` - Listar produtos
- `GET /api/v1/products/:id` - Detalhes do produto
- `POST /api/v1/products` - Criar produto
- `PATCH /api/v1/products/:id` - Atualizar produto
- `DELETE /api/v1/products/:id` - Remover produto
- `GET /api/v1/products/my-products` - Meus produtos
- `GET /api/v1/products/stats` - Estatísticas

### Cursos
- `GET /api/v1/courses` - Listar cursos
- `GET /api/v1/courses/:id` - Detalhes do curso
- `POST /api/v1/courses` - Criar curso
- `PATCH /api/v1/courses/:id` - Atualizar curso
- `DELETE /api/v1/courses/:id` - Remover curso
- `POST /api/v1/courses/:id/modules` - Criar módulo
- `POST /api/v1/courses/:id/modules/:moduleId/lessons` - Criar aula

### Vendas
- `GET /api/v1/sales` - Listar vendas
- `GET /api/v1/sales/:id` - Detalhes da venda
- `POST /api/v1/sales` - Criar venda
- `POST /api/v1/sales/:id/refund` - Reembolsar venda
- `GET /api/v1/sales/stats` - Estatísticas

### Afiliados
- `POST /api/v1/affiliates/register` - Registrar como afiliado
- `GET /api/v1/affiliates/profile` - Perfil do afiliado
- `GET /api/v1/affiliates/links` - Links de afiliado
- `POST /api/v1/affiliates/links` - Criar link
- `GET /api/v1/affiliates/commissions` - Comissões
- `GET /api/v1/affiliates/stats` - Estatísticas

### Comissões
- `GET /api/v1/commissions` - Listar comissões
- `POST /api/v1/commissions/:id/approve` - Aprovar comissão
- `POST /api/v1/commissions/:id/make-available` - Liberar comissão

### Saques
- `GET /api/v1/withdrawals` - Listar saques
- `POST /api/v1/withdrawals` - Solicitar saque
- `POST /api/v1/withdrawals/:id/cancel` - Cancelar saque

### Cupons
- `GET /api/v1/coupons` - Listar cupons
- `POST /api/v1/coupons` - Criar cupom
- `GET /api/v1/coupons/validate` - Validar cupom
- `PATCH /api/v1/coupons/:id` - Atualizar cupom
- `DELETE /api/v1/coupons/:id` - Remover cupom

### Admin
- `GET /api/v1/admin/dashboard` - Dashboard
- `GET /api/v1/admin/reports/sales` - Relatório de vendas
- `GET /api/v1/admin/reports/affiliates` - Relatório de afiliados
- `GET /api/v1/admin/activity` - Atividade recente

## 🔒 Sistema de Permissões (RBAC)

- **master**: Acesso total à plataforma
- **producer**: Criar e gerenciar produtos/cursos
- **affiliate**: Promover produtos e receber comissões
- **customer**: Comprar e acessar produtos

## 💳 Gateways de Pagamento

### Stripe
- Cartões de crédito/débito
- Webhooks para atualização de status

### Mercado Pago
- PIX
- Boleto
- Cartões

## 🎯 Sistema de Afiliados

- Tracking por cookie (30 dias)
- Links personalizados
- Comissões configuráveis por produto
- Período de garantia antes da liberação
- Saques via PIX, Transferência, PayPal ou Payoneer

## 📄 Licença

Este projeto está sob a licença MIT.

## 🤝 Contribuição

Contribuições são bem-vindas! Por favor, leia o guia de contribuição antes de enviar um PR.

## 📞 Suporte

Para suporte, envie um email para suporte@eumeria.com ou abra uma issue no GitHub.

---

Desenvolvido com ❤️ pela equipe Eumería