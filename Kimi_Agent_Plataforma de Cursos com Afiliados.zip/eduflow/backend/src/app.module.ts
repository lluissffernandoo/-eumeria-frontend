import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';

// Config
import { appConfig } from './config/app.config';
import { databaseConfig } from './config/database.config';
import { jwtConfig } from './config/jwt.config';
import { redisConfig } from './config/redis.config';
import { paymentConfig } from './config/payment.config';
import { emailConfig } from './config/email.config';

// Modules
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { ProductsModule } from './modules/products/products.module';
import { CoursesModule } from './modules/courses/courses.module';
import { AffiliatesModule } from './modules/affiliates/affiliates.module';
import { SalesModule } from './modules/sales/sales.module';
import { CommissionsModule } from './modules/commissions/commissions.module';
import { WithdrawalsModule } from './modules/withdrawals/withdrawals.module';
import { CouponsModule } from './modules/coupons/coupons.module';
import { PaymentsModule } from './modules/payments/payments.module';
import { AdminModule } from './modules/admin/admin.module';
import { UploadModule } from './modules/upload/upload.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { AnalyticsModule } from './modules/analytics/analytics.module';
import { MembersModule } from './modules/members/members.module';

// Middlewares
import { LoggerMiddleware } from './common/middlewares/logger.middleware';
import { SecurityMiddleware } from './common/middlewares/security.middleware';

// Entities
import { User } from './entities/user.entity';
import { Product } from './entities/product.entity';
import { Course } from './entities/course.entity';
import { Module as CourseModule } from './entities/module.entity';
import { Lesson } from './entities/lesson.entity';
import { Affiliate } from './entities/affiliate.entity';
import { AffiliateLink } from './entities/affiliate-link.entity';
import { Sale } from './entities/sale.entity';
import { Commission } from './entities/commission.entity';
import { Withdrawal } from './entities/withdrawal.entity';
import { Coupon } from './entities/coupon.entity';
import { Configuration } from './entities/configuration.entity';
import { Log } from './entities/log.entity';
import { Enrollment } from './entities/enrollment.entity';
import { Progress } from './entities/progress.entity';
import { Review } from './entities/review.entity';
import { Category } from './entities/category.entity';

@Module({
  imports: [
    // Configuração global
    ConfigModule.forRoot({
      isGlobal: true,
      load: [appConfig, databaseConfig, jwtConfig, redisConfig, paymentConfig, emailConfig],
      envFilePath: ['.env', '.env.local', '.env.production'],
    }),

    // Rate limiting
    ThrottlerModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        throttlers: [
          {
            ttl: config.get<number>('THROTTLE_TTL', 60000),
            limit: config.get<number>('THROTTLE_LIMIT', 100),
          },
        ],
      }),
    }),

    // Banco de dados
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'postgres',
        host: config.get<string>('DB_HOST', 'localhost'),
        port: config.get<number>('DB_PORT', 5432),
        username: config.get<string>('DB_USERNAME', 'eumeria'),
        password: config.get<string>('DB_PASSWORD', 'eumeria123'),
        database: config.get<string>('DB_NAME', 'eumeria'),
        entities: [
          User, Product, Course, CourseModule, Lesson,
          Affiliate, AffiliateLink, Sale, Commission,
          Withdrawal, Coupon, Configuration, Log,
          Enrollment, Progress, Review, Category,
        ],
        synchronize: config.get<string>('NODE_ENV') === 'development',
        logging: config.get<string>('NODE_ENV') === 'development',
        migrations: [__dirname + '/database/migrations/*{.ts,.js}'],
        migrationsRun: true,
        ssl: config.get<string>('DB_SSL') === 'true' ? {
          rejectUnauthorized: false,
        } : false,
      }),
    }),

    // Arquivos estáticos
    ServeStaticModule.forRoot({
      rootPath: join(__dirname, '..', 'uploads'),
      serveRoot: '/uploads',
    }),

    // Módulos da aplicação
    AuthModule,
    UsersModule,
    ProductsModule,
    CoursesModule,
    AffiliatesModule,
    SalesModule,
    CommissionsModule,
    WithdrawalsModule,
    CouponsModule,
    PaymentsModule,
    AdminModule,
    UploadModule,
    NotificationsModule,
    AnalyticsModule,
    MembersModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: ThrottlerGuard,
    },
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LoggerMiddleware, SecurityMiddleware)
      .forRoutes('*');
  }
}
