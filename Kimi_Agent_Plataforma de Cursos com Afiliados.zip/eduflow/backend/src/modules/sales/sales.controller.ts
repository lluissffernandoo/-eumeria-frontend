import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { SalesService } from './sales.service';
import { CreateSaleDto } from './dto/create-sale.dto';
import { SaleQueryDto } from './dto/sale-query.dto';
import { ProcessPaymentDto } from './dto/process-payment.dto';
import { RefundSaleDto } from './dto/refund-sale.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../../entities/user.entity';

@Controller('sales')
@UseGuards(JwtAuthGuard, RolesGuard)
export class SalesController {
  constructor(private readonly salesService: SalesService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @Roles(UserRole.CUSTOMER, UserRole.ADMIN)
  async create(@Body() createSaleDto: CreateSaleDto) {
    const sale = await this.salesService.create(createSaleDto);
    return {
      success: true,
      data: sale,
      message: 'Venda criada com sucesso',
    };
  }

  @Get()
  async findAll(@Query() query: SaleQueryDto, @Request() req) {
    const result = await this.salesService.findAll(query, req.user);
    return {
      success: true,
      data: result.data,
      meta: {
        total: result.total,
        page: result.page,
        limit: result.limit,
        totalPages: Math.ceil(result.total / result.limit),
      },
    };
  }

  @Get('stats')
  async getStats(@Request() req) {
    const stats = await this.salesService.getDashboardStats(req.user);
    return {
      success: true,
      data: stats,
    };
  }

  @Get(':id')
  async findOne(@Param('id') id: string, @Request() req) {
    const sale = await this.salesService.findOne(id, req.user);
    return {
      success: true,
      data: sale,
    };
  }

  @Get('order/:orderNumber')
  async findByOrderNumber(@Param('orderNumber') orderNumber: string, @Request() req) {
    const sale = await this.salesService.findByOrderNumber(orderNumber, req.user);
    return {
      success: true,
      data: sale,
    };
  }

  @Post(':id/process-payment')
  @Roles(UserRole.ADMIN)
  async processPayment(
    @Param('id') id: string,
    @Body() processPaymentDto: ProcessPaymentDto,
  ) {
    const sale = await this.salesService.processPayment(id, processPaymentDto);
    return {
      success: true,
      data: sale,
      message: 'Pagamento processado com sucesso',
    };
  }

  @Post(':id/refund')
  @Roles(UserRole.ADMIN, UserRole.PRODUCER)
  async refund(
    @Param('id') id: string,
    @Body() refundSaleDto: RefundSaleDto,
    @Request() req,
  ) {
    const sale = await this.salesService.refund(id, refundSaleDto, req.user);
    return {
      success: true,
      data: sale,
      message: 'Reembolso processado com sucesso',
    };
  }
}
