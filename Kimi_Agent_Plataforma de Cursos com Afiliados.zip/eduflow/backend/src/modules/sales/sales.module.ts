import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SalesController } from './sales.controller';
import { SalesService } from './sales.service';
import { Sale } from '../../entities/sale.entity';
import { Product } from '../../entities/product.entity';
import { User } from '../../entities/user.entity';
import { Affiliate } from '../../entities/affiliate.entity';
import { AffiliateLink } from '../../entities/affiliate-link.entity';
import { Coupon } from '../../entities/coupon.entity';
import { Commission } from '../../entities/commission.entity';
import { Log } from '../../entities/log.entity';
import { PaymentsModule } from '../payments/payments.module';
import { CommissionsModule } from '../commissions/commissions.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Sale,
      Product,
      User,
      Affiliate,
      AffiliateLink,
      Coupon,
      Commission,
      Log,
    ]),
    PaymentsModule,
    CommissionsModule,
  ],
  controllers: [SalesController],
  providers: [SalesService],
  exports: [SalesService],
})
export class SalesModule {}
