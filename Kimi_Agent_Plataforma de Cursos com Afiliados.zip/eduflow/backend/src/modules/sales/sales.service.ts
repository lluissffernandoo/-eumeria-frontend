import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Brackets } from 'typeorm';
import { Sale, SaleStatus, PaymentStatus } from '../../entities/sale.entity';
import { Product, ProductStatus } from '../../entities/product.entity';
import { User, UserRole } from '../../entities/user.entity';
import { Affiliate, AffiliateStatus } from '../../entities/affiliate.entity';
import { AffiliateLink } from '../../entities/affiliate-link.entity';
import { Coupon, CouponStatus } from '../../entities/coupon.entity';
import { Commission } from '../../entities/commission.entity';
import { Log } from '../../entities/log.entity';
import { CreateSaleDto } from './dto/create-sale.dto';
import { SaleQueryDto } from './dto/sale-query.dto';
import { ProcessPaymentDto } from './dto/process-payment.dto';
import { RefundSaleDto } from './dto/refund-sale.dto';
import { PaymentsService } from '../payments/payments.service';
import { CommissionsService } from '../commissions/commissions.service';

@Injectable()
export class SalesService {
  private readonly logger = new Logger(SalesService.name);

  constructor(
    @InjectRepository(Sale)
    private saleRepository: Repository<Sale>,
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectRepository(Affiliate)
    private affiliateRepository: Repository<Affiliate>,
    @InjectRepository(AffiliateLink)
    private affiliateLinkRepository: Repository<AffiliateLink>,
    @InjectRepository(Coupon)
    private couponRepository: Repository<Coupon>,
    @InjectRepository(Commission)
    private commissionRepository: Repository<Commission>,
    @InjectRepository(Log)
    private logRepository: Repository<Log>,
    private paymentsService: PaymentsService,
    private commissionsService: CommissionsService,
  ) {}

  async create(createSaleDto: CreateSaleDto): Promise<Sale> {
    // Validate product
    const product = await this.productRepository.findOne({
      where: { id: createSaleDto.productId, status: ProductStatus.PUBLISHED },
      relations: ['producer'],
    });

    if (!product) {
      throw new NotFoundException('Produto não encontrado ou não disponível');
    }

    // Check if it's a self-purchase
    const existingUser = await this.userRepository.findOne({
      where: { email: createSaleDto.customerEmail },
    });

    const isSelfPurchase = existingUser?.id === product.producerId;

    if (isSelfPurchase) {
      throw new BadRequestException('Não é permitido comprar seu próprio produto');
    }

    // Calculate pricing
    let originalPrice = Number(product.price);
    let discountAmount = 0;
    let coupon: Coupon | null = null;

    // Apply coupon if provided
    if (createSaleDto.couponCode) {
      coupon = await this.applyCoupon(createSaleDto.couponCode, product.id);
      if (coupon) {
        if (coupon.type === 'percentage') {
          discountAmount = (originalPrice * coupon.value) / 100;
        } else {
          discountAmount = coupon.value;
        }
        // Ensure discount doesn't exceed price
        discountAmount = Math.min(discountAmount, originalPrice);
      }
    }

    const finalPrice = Math.max(0, originalPrice - discountAmount);

    // Validate affiliate
    let affiliate: Affiliate | null = null;
    let affiliateLink: AffiliateLink | null = null;

    if (createSaleDto.affiliateCode) {
      affiliate = await this.affiliateRepository.findOne({
        where: {
          code: createSaleDto.affiliateCode,
          status: AffiliateStatus.APPROVED,
        },
      });

      if (affiliate) {
        // Check if affiliate is not the customer
        const affiliateUser = await this.userRepository.findOne({
          where: { id: affiliate.userId },
        });

        if (affiliateUser?.email === createSaleDto.customerEmail) {
          throw new BadRequestException('Afiliado não pode comprar com seu próprio link');
        }

        // Find affiliate link
        affiliateLink = await this.affiliateLinkRepository.findOne({
          where: {
            affiliateId: affiliate.id,
            productId: product.id,
          },
        });
      }
    }

    // Generate order number
    const orderNumber = await this.generateOrderNumber();

    // Calculate guarantee period
    const guaranteeDays = product.guaranteeDays || 7;
    const guaranteeExpiresAt = new Date();
    guaranteeExpiresAt.setDate(guaranteeExpiresAt.getDate() + guaranteeDays);

    // Create sale
    const sale = this.saleRepository.create({
      orderNumber,
      status: SaleStatus.PENDING,
      paymentStatus: PaymentStatus.PENDING,
      originalPrice,
      discountAmount,
      finalPrice,
      currency: 'BRL',
      paymentMethod: createSaleDto.paymentMethod,
      installments: createSaleDto.installments || 1,
      platformFee: finalPrice * 0.1, // 10% platform fee
      paymentFee: this.calculatePaymentFee(finalPrice, createSaleDto.paymentMethod),
      hasAffiliate: !!affiliate,
      affiliateCode: createSaleDto.affiliateCode,
      affiliateIp: createSaleDto.affiliateIp,
      affiliateUserAgent: createSaleDto.affiliateUserAgent,
      affiliateClickAt: new Date(),
      referrer: createSaleDto.referrer,
      landingPage: createSaleDto.landingPage,
      utmSource: createSaleDto.utmSource,
      utmMedium: createSaleDto.utmMedium,
      utmCampaign: createSaleDto.utmCampaign,
      customerName: createSaleDto.customerName,
      customerEmail: createSaleDto.customerEmail,
      customerPhone: createSaleDto.customerPhone,
      customerDocument: createSaleDto.customerDocument,
      customerIp: createSaleDto.customerIp,
      userAgent: createSaleDto.userAgent,
      fingerprint: createSaleDto.fingerprint,
      isSelfPurchase,
      guaranteeDays,
      guaranteeExpiresAt,
      productId: product.id,
      affiliateId: affiliate?.id || null,
      affiliateLinkId: affiliateLink?.id || null,
      couponId: coupon?.id || null,
      metadata: createSaleDto.metadata,
    });

    // Calculate affiliate commission and producer revenue
    if (affiliate) {
      const commissionRate = affiliateLink?.commissionRate || product.affiliateCommissionRate || 30;
      sale.affiliateCommission = (finalPrice * commissionRate) / 100;
    }

    sale.producerRevenue = finalPrice - sale.platformFee - sale.affiliateCommission - sale.paymentFee;

    const savedSale = await this.saleRepository.save(sale);

    // Create payment intent
    try {
      const paymentIntent = await this.paymentsService.createPaymentIntent({
        amount: finalPrice,
        currency: 'BRL',
        paymentMethod: createSaleDto.paymentMethod,
        installments: createSaleDto.installments,
        customerEmail: createSaleDto.customerEmail,
        customerName: createSaleDto.customerName,
        customerDocument: createSaleDto.customerDocument,
        description: `Compra de ${product.name}`,
        metadata: {
          saleId: savedSale.id,
          orderNumber: savedSale.orderNumber,
          productId: product.id,
        },
      });

      savedSale.paymentIntentId = paymentIntent.id;
      await this.saleRepository.save(savedSale);

      // Increment affiliate link conversions if applicable
      if (affiliateLink) {
        affiliateLink.conversions += 1;
        affiliateLink.revenue += finalPrice;
        affiliateLink.commission += sale.affiliateCommission;
        await this.affiliateLinkRepository.save(affiliateLink);
      }
    } catch (error) {
      this.logger.error('Erro ao criar payment intent:', error);
      savedSale.status = SaleStatus.FAILED;
      await this.saleRepository.save(savedSale);
      throw new BadRequestException('Erro ao processar pagamento');
    }

    // Log sale creation
    await this.logRepository.save({
      level: 'info',
      message: `Venda criada: ${orderNumber}`,
      context: { saleId: savedSale.id, productId: product.id },
      userId: existingUser?.id,
    });

    return savedSale;
  }

  async findAll(query: SaleQueryDto, user: User): Promise<{ data: Sale[]; total: number; page: number; limit: number }> {
    const { page = 1, limit = 20 } = query;
    const skip = (page - 1) * limit;

    const queryBuilder = this.saleRepository.createQueryBuilder('sale')
      .leftJoinAndSelect('sale.product', 'product')
      .leftJoinAndSelect('sale.affiliate', 'affiliate')
      .leftJoinAndSelect('sale.coupon', 'coupon')
      .leftJoinAndSelect('sale.commissions', 'commissions');

    // Apply role-based filtering
    if (user.role === UserRole.CUSTOMER) {
      queryBuilder.where('sale.customerId = :customerId', { customerId: user.id });
    } else if (user.role === UserRole.PRODUCER) {
      queryBuilder.where('product.producerId = :producerId', { producerId: user.id });
    } else if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (affiliate) {
        queryBuilder.where('sale.affiliateId = :affiliateId', { affiliateId: affiliate.id });
      }
    }

    // Apply filters
    if (query.status) {
      queryBuilder.andWhere('sale.status = :status', { status: query.status });
    }

    if (query.paymentStatus) {
      queryBuilder.andWhere('sale.paymentStatus = :paymentStatus', { paymentStatus: query.paymentStatus });
    }

    if (query.customerId && [UserRole.ADMIN, UserRole.PRODUCER].includes(user.role)) {
      queryBuilder.andWhere('sale.customerId = :customerId', { customerId: query.customerId });
    }

    if (query.productId) {
      queryBuilder.andWhere('sale.productId = :productId', { productId: query.productId });
    }

    if (query.affiliateId && [UserRole.ADMIN, UserRole.PRODUCER].includes(user.role)) {
      queryBuilder.andWhere('sale.affiliateId = :affiliateId', { affiliateId: query.affiliateId });
    }

    if (query.orderNumber) {
      queryBuilder.andWhere('sale.orderNumber ILIKE :orderNumber', { orderNumber: `%${query.orderNumber}%` });
    }

    if (query.search) {
      queryBuilder.andWhere(
        new Brackets((qb) => {
          qb.where('sale.customerName ILIKE :search', { search: `%${query.search}%` })
            .orWhere('sale.customerEmail ILIKE :search', { search: `%${query.search}%` })
            .orWhere('sale.orderNumber ILIKE :search', { search: `%${query.search}%` })
            .orWhere('product.name ILIKE :search', { search: `%${query.search}%` });
        }),
      );
    }

    if (query.startDate) {
      queryBuilder.andWhere('sale.createdAt >= :startDate', { startDate: query.startDate });
    }

    if (query.endDate) {
      queryBuilder.andWhere('sale.createdAt <= :endDate', { endDate: query.endDate });
    }

    // Apply sorting
    const sortBy = query.sortBy || 'createdAt';
    const sortOrder = query.sortOrder || 'DESC';
    queryBuilder.orderBy(`sale.${sortBy}`, sortOrder);

    // Apply pagination
    queryBuilder.skip(skip).take(limit);

    const [data, total] = await queryBuilder.getManyAndCount();

    return { data, total, page, limit };
  }

  async findOne(id: string, user: User): Promise<Sale> {
    const sale = await this.saleRepository.findOne({
      where: { id },
      relations: ['product', 'affiliate', 'affiliate.user', 'coupon', 'commissions'],
    });

    if (!sale) {
      throw new NotFoundException('Venda não encontrada');
    }

    // Check permissions
    if (user.role === UserRole.CUSTOMER && sale.customerId !== user.id) {
      throw new ForbiddenException('Você não tem permissão para ver esta venda');
    }

    if (user.role === UserRole.PRODUCER && sale.product.producerId !== user.id) {
      throw new ForbiddenException('Você não tem permissão para ver esta venda');
    }

    if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (!affiliate || sale.affiliateId !== affiliate.id) {
        throw new ForbiddenException('Você não tem permissão para ver esta venda');
      }
    }

    return sale;
  }

  async findByOrderNumber(orderNumber: string, user: User): Promise<Sale> {
    const sale = await this.saleRepository.findOne({
      where: { orderNumber },
      relations: ['product', 'affiliate', 'coupon', 'commissions'],
    });

    if (!sale) {
      throw new NotFoundException('Venda não encontrada');
    }

    // Check permissions
    if (user.role === UserRole.CUSTOMER && sale.customerId !== user.id) {
      throw new ForbiddenException('Você não tem permissão para ver esta venda');
    }

    return sale;
  }

  async processPayment(saleId: string, processPaymentDto: ProcessPaymentDto): Promise<Sale> {
    const sale = await this.saleRepository.findOne({
      where: { id: saleId },
      relations: ['product', 'affiliate'],
    });

    if (!sale) {
      throw new NotFoundException('Venda não encontrada');
    }

    sale.paymentStatus = processPaymentDto.status;
    sale.paymentTransactionId = processPaymentDto.transactionId || null;

    if (processPaymentDto.status === PaymentStatus.PAID) {
      sale.status = SaleStatus.COMPLETED;
      sale.paymentStatus = PaymentStatus.PAID;
      sale.paidAt = new Date();

      // Create commissions
      await this.commissionsService.createFromSale(sale);

      // Update product sales count
      const product = sale.product;
      product.salesCount += 1;
      product.revenue += sale.finalPrice;
      await this.productRepository.save(product);

      // Update affiliate stats if applicable
      if (sale.affiliate) {
        const affiliate = sale.affiliate;
        affiliate.totalSales += 1;
        affiliate.totalRevenue += sale.finalPrice;
        affiliate.pendingCommission += sale.affiliateCommission;
        await this.affiliateRepository.save(affiliate);
      }
    } else if (processPaymentDto.status === PaymentStatus.FAILED) {
      sale.status = SaleStatus.FAILED;
    }

    await this.saleRepository.save(sale);

    // Log payment processing
    await this.logRepository.save({
      level: 'info',
      message: `Pagamento processado: ${sale.orderNumber} - ${processPaymentDto.status}`,
      context: { saleId: sale.id, status: processPaymentDto.status },
    });

    return sale;
  }

  async processWebhook(provider: string, payload: any): Promise<void> {
    this.logger.log(`Processando webhook de ${provider}`);

    try {
      const paymentData = await this.paymentsService.processWebhook(provider, payload);

      if (paymentData.saleId) {
        await this.processPayment(paymentData.saleId, {
          paymentIntentId: paymentData.paymentIntentId,
          status: paymentData.status as PaymentStatus,
          transactionId: paymentData.transactionId,
          paymentData: paymentData.rawData,
        });
      }
    } catch (error) {
      this.logger.error('Erro ao processar webhook:', error);
      throw new BadRequestException('Erro ao processar webhook');
    }
  }

  async refund(id: string, refundSaleDto: RefundSaleDto, user: User): Promise<Sale> {
    const sale = await this.saleRepository.findOne({
      where: { id },
      relations: ['product', 'affiliate', 'commissions'],
    });

    if (!sale) {
      throw new NotFoundException('Venda não encontrada');
    }

    if (!sale.canRefund()) {
      throw new BadRequestException('Esta venda não pode ser reembolsada');
    }

    const refundAmount = refundSaleDto.amount || sale.finalPrice;

    if (refundAmount > sale.finalPrice) {
      throw new BadRequestException('Valor de reembolso não pode ser maior que o valor da venda');
    }

    // Process refund with payment provider
    try {
      await this.paymentsService.refundPayment(sale.paymentIntentId, refundAmount);
    } catch (error) {
      this.logger.error('Erro ao processar reembolso:', error);
      throw new BadRequestException('Erro ao processar reembolso');
    }

    // Update sale
    const isFullRefund = refundAmount === sale.finalPrice;
    sale.status = isFullRefund ? SaleStatus.REFUNDED : SaleStatus.PARTIALLY_REFUNDED;
    sale.paymentStatus = isFullRefund ? PaymentStatus.REFUNDED : sale.paymentStatus;
    sale.refundedAmount = (sale.refundedAmount || 0) + refundAmount;
    sale.refundedAt = new Date();

    await this.saleRepository.save(sale);

    // Cancel commissions
    for (const commission of sale.commissions) {
      await this.commissionsService.refund(commission.id);
    }

    // Update product stats
    const product = sale.product;
    product.salesCount = Math.max(0, product.salesCount - 1);
    product.revenue = Math.max(0, product.revenue - refundAmount);
    await this.productRepository.save(product);

    // Update affiliate stats if applicable
    if (sale.affiliate) {
      const affiliate = sale.affiliate;
      affiliate.totalSales = Math.max(0, affiliate.totalSales - 1);
      affiliate.totalRevenue = Math.max(0, affiliate.totalRevenue - refundAmount);
      affiliate.pendingCommission = Math.max(0, affiliate.pendingCommission - sale.affiliateCommission);
      await this.affiliateRepository.save(affiliate);
    }

    // Log refund
    await this.logRepository.save({
      level: 'info',
      message: `Reembolso processado: ${sale.orderNumber} - R$ ${refundAmount}`,
      context: { saleId: sale.id, amount: refundAmount, reason: refundSaleDto.reason },
      userId: user.id,
    });

    return sale;
  }

  async getStats(user: User, period?: { startDate: Date; endDate: Date }): Promise<any> {
    const queryBuilder = this.saleRepository.createQueryBuilder('sale')
      .leftJoin('sale.product', 'product');

    // Apply role-based filtering
    if (user.role === UserRole.PRODUCER) {
      queryBuilder.where('product.producerId = :producerId', { producerId: user.id });
    } else if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (affiliate) {
        queryBuilder.where('sale.affiliateId = :affiliateId', { affiliateId: affiliate.id });
      }
    }

    if (period?.startDate) {
      queryBuilder.andWhere('sale.createdAt >= :startDate', { startDate: period.startDate });
    }

    if (period?.endDate) {
      queryBuilder.andWhere('sale.createdAt <= :endDate', { endDate: period.endDate });
    }

    const [totalSales, paidSales, totalRevenue, totalRefunds] = await Promise.all([
      queryBuilder.getCount(),
      queryBuilder.clone()
        .andWhere('sale.paymentStatus = :status', { status: PaymentStatus.PAID })
        .getCount(),
      queryBuilder.clone()
        .select('COALESCE(SUM(sale.finalPrice), 0)', 'total')
        .andWhere('sale.paymentStatus = :status', { status: PaymentStatus.PAID })
        .getRawOne(),
      queryBuilder.clone()
        .select('COALESCE(SUM(sale.refundedAmount), 0)', 'total')
        .getRawOne(),
    ]);

    return {
      totalSales,
      paidSales,
      totalRevenue: Number(totalRevenue?.total || 0),
      totalRefunds: Number(totalRefunds?.total || 0),
      netRevenue: Number(totalRevenue?.total || 0) - Number(totalRefunds?.total || 0),
    };
  }

  async getDashboardStats(user: User): Promise<any> {
    const today = new Date();
    const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);

    const [totalStats, monthlyStats, weeklyStats] = await Promise.all([
      this.getStats(user),
      this.getStats(user, { startDate: thirtyDaysAgo, endDate: today }),
      this.getStats(user, { startDate: sevenDaysAgo, endDate: today }),
    ]);

    return {
      total: totalStats,
      last30Days: monthlyStats,
      last7Days: weeklyStats,
    };
  }

  private async generateOrderNumber(): Promise<string> {
    const prefix = 'EDF';
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${timestamp}-${random}`;
  }

  private async applyCoupon(code: string, productId: string): Promise<Coupon | null> {
    const coupon = await this.couponRepository.findOne({
      where: { code: code.toUpperCase() },
    });

    if (!coupon) return null;

    // Check if coupon is active
    if (coupon.status !== CouponStatus.ACTIVE) return null;

    // Check dates
    const now = new Date();
    if (coupon.startDate && now < coupon.startDate) return null;
    if (coupon.endDate && now > coupon.endDate) return null;

    // Check usage limit
    if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) return null;

    // Check product applicability
    if (coupon.productId && coupon.productId !== productId) return null;

    return coupon;
  }

  private calculatePaymentFee(amount: number, paymentMethod: string): number {
    const fees: Record<string, number> = {
      credit_card: 0.0399, // 3.99%
      debit_card: 0.0199, // 1.99%
      pix: 0.0099, // 0.99%
      boleto: 0.0199, // 1.99%
    };

    const feeRate = fees[paymentMethod] || 0.0399;
    return amount * feeRate;
  }
}
