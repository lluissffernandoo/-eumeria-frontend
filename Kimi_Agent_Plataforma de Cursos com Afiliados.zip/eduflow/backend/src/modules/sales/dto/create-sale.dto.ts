import {
  IsUUID,
  IsOptional,
  IsEnum,
  IsString,
  IsNumber,
  IsBoolean,
  Min,
  Max,
  Length,
  IsIP,
  IsObject,
} from 'class-validator';
import { Type } from 'class-transformer';
import { PaymentMethod } from '../../../entities/sale.entity';

export class CreateSaleDto {
  @IsUUID()
  productId: string;

  @IsOptional()
  @IsString()
  @Length(3, 20)
  couponCode?: string;

  @IsEnum(PaymentMethod)
  paymentMethod: PaymentMethod;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Max(12)
  @Type(() => Number)
  installments?: number;

  // Affiliate tracking
  @IsOptional()
  @IsString()
  affiliateCode?: string;

  @IsOptional()
  @IsIP()
  affiliateIp?: string;

  @IsOptional()
  @IsString()
  affiliateUserAgent?: string;

  @IsOptional()
  @IsString()
  referrer?: string;

  @IsOptional()
  @IsString()
  landingPage?: string;

  @IsOptional()
  @IsString()
  utmSource?: string;

  @IsOptional()
  @IsString()
  utmMedium?: string;

  @IsOptional()
  @IsString()
  utmCampaign?: string;

  // Customer info
  @IsString()
  @Length(2, 200)
  customerName: string;

  @IsString()
  @Length(5, 255)
  customerEmail: string;

  @IsOptional()
  @IsString()
  @Length(8, 20)
  customerPhone?: string;

  @IsOptional()
  @IsString()
  @Length(11, 14)
  customerDocument?: string;

  @IsIP()
  customerIp: string;

  @IsString()
  userAgent: string;

  @IsOptional()
  @IsString()
  fingerprint?: string;

  @IsOptional()
  @IsObject()
  metadata?: Record<string, any>;
}
