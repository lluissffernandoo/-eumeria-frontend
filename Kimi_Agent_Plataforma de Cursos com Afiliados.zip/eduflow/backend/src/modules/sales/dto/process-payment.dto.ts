import {
  IsString,
  IsOptional,
  IsObject,
  IsEnum,
} from 'class-validator';
import { PaymentStatus } from '../../../entities/sale.entity';

export class ProcessPaymentDto {
  @IsString()
  paymentIntentId: string;

  @IsEnum(PaymentStatus)
  status: PaymentStatus;

  @IsOptional()
  @IsString()
  transactionId?: string;

  @IsOptional()
  @IsObject()
  paymentData?: Record<string, any>;
}
