import {
  IsString,
  IsUUID,
  IsNumber,
  Min,
} from 'class-validator';
import { Type } from 'class-transformer';

export class ValidateCouponDto {
  @IsString()
  code: string;

  @IsUUID()
  productId: string;

  @IsNumber()
  @Min(0)
  @Type(() => Number)
  amount: number;
}
