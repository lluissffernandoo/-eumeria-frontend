import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Brackets } from 'typeorm';
import { Coupon, CouponStatus, CouponType } from '../../entities/coupon.entity';
import { Product } from '../../entities/product.entity';
import { Log } from '../../entities/log.entity';
import { User, UserRole } from '../../entities/user.entity';
import { CreateCouponDto } from './dto/create-coupon.dto';
import { UpdateCouponDto } from './dto/update-coupon.dto';
import { CouponQueryDto } from './dto/coupon-query.dto';
import { ValidateCouponDto } from './dto/validate-coupon.dto';

@Injectable()
export class CouponsService {
  private readonly logger = new Logger(CouponsService.name);

  constructor(
    @InjectRepository(Coupon)
    private couponRepository: Repository<Coupon>,
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    @InjectRepository(Log)
    private logRepository: Repository<Log>,
  ) {}

  async create(createCouponDto: CreateCouponDto, user: User): Promise<Coupon> {
    // Check if code already exists
    const existingCoupon = await this.couponRepository.findOne({
      where: { code: createCouponDto.code.toUpperCase() },
    });

    if (existingCoupon) {
      throw new BadRequestException('Código de cupom já existe');
    }

    // Validate product if specified
    if (createCouponDto.productId) {
      const product = await this.productRepository.findOne({
        where: { id: createCouponDto.productId },
      });

      if (!product) {
        throw new NotFoundException('Produto não encontrado');
      }

      // Check if user owns the product
      if (user.role === UserRole.PRODUCER && product.producerId !== user.id) {
        throw new ForbiddenException('Você não tem permissão para criar cupom para este produto');
      }
    }

    // Validate dates
    if (createCouponDto.startDate && createCouponDto.endDate) {
      if (new Date(createCouponDto.startDate) > new Date(createCouponDto.endDate)) {
        throw new BadRequestException('Data de início não pode ser maior que data de término');
      }
    }

    // Validate value
    if (createCouponDto.type === CouponType.PERCENTAGE && createCouponDto.value > 100) {
      throw new BadRequestException('Porcentagem não pode ser maior que 100%');
    }

    const coupon = this.couponRepository.create({
      ...createCouponDto,
      code: createCouponDto.code.toUpperCase(),
      status: CouponStatus.ACTIVE,
      usageCount: 0,
      createdBy: user.id,
    });

    const savedCoupon = await this.couponRepository.save(coupon);

    // Log creation
    await this.logRepository.save({
      level: 'info',
      message: `Cupom criado: ${savedCoupon.code}`,
      context: { couponId: savedCoupon.id, value: savedCoupon.value },
      userId: user.id,
    });

    return savedCoupon;
  }

  async findAll(query: CouponQueryDto, user: User): Promise<{ data: Coupon[]; total: number; page: number; limit: number }> {
    const { page = 1, limit = 20 } = query;
    const skip = (page - 1) * limit;

    const queryBuilder = this.couponRepository.createQueryBuilder('coupon')
      .leftJoinAndSelect('coupon.product', 'product');

    // Apply role-based filtering
    if (user.role === UserRole.PRODUCER) {
      queryBuilder.where(
        new Brackets((qb) => {
          qb.where('product.producerId = :producerId', { producerId: user.id })
            .orWhere('coupon.productId IS NULL');
        }),
      );
    }

    // Apply filters
    if (query.status) {
      queryBuilder.andWhere('coupon.status = :status', { status: query.status });
    }

    if (query.type) {
      queryBuilder.andWhere('coupon.type = :type', { type: query.type });
    }

    if (query.productId) {
      queryBuilder.andWhere('coupon.productId = :productId', { productId: query.productId });
    }

    if (query.code) {
      queryBuilder.andWhere('coupon.code ILIKE :code', { code: `%${query.code}%` });
    }

    if (query.isPublic !== undefined) {
      queryBuilder.andWhere('coupon.isPublic = :isPublic', { isPublic: query.isPublic });
    }

    // Apply sorting
    const sortBy = query.sortBy || 'createdAt';
    const sortOrder = query.sortOrder || 'DESC';
    queryBuilder.orderBy(`coupon.${sortBy}`, sortOrder);

    // Apply pagination
    queryBuilder.skip(skip).take(limit);

    const [data, total] = await queryBuilder.getManyAndCount();

    return { data, total, page, limit };
  }

  async findOne(id: string, user: User): Promise<Coupon> {
    const coupon = await this.couponRepository.findOne({
      where: { id },
      relations: ['product', 'sales'],
    });

    if (!coupon) {
      throw new NotFoundException('Cupom não encontrado');
    }

    // Check permissions
    if (user.role === UserRole.PRODUCER && coupon.product && coupon.product.producerId !== user.id) {
      throw new ForbiddenException('Você não tem permissão para ver este cupom');
    }

    return coupon;
  }

  async findByCode(code: string): Promise<Coupon> {
    const coupon = await this.couponRepository.findOne({
      where: { code: code.toUpperCase() },
      relations: ['product'],
    });

    if (!coupon) {
      throw new NotFoundException('Cupom não encontrado');
    }

    return coupon;
  }

  async update(id: string, updateCouponDto: UpdateCouponDto, user: User): Promise<Coupon> {
    const coupon = await this.findOne(id, user);

    // Check permissions
    if (user.role === UserRole.PRODUCER) {
      if (coupon.product && coupon.product.producerId !== user.id) {
        throw new ForbiddenException('Você não tem permissão para editar este cupom');
      }
    }

    // Validate product if being changed
    if (updateCouponDto.productId && updateCouponDto.productId !== coupon.productId) {
      const product = await this.productRepository.findOne({
        where: { id: updateCouponDto.productId },
      });

      if (!product) {
        throw new NotFoundException('Produto não encontrado');
      }

      if (user.role === UserRole.PRODUCER && product.producerId !== user.id) {
        throw new ForbiddenException('Você não tem permissão para associar este produto');
      }
    }

    // Validate dates
    if (updateCouponDto.startDate && updateCouponDto.endDate) {
      if (new Date(updateCouponDto.startDate) > new Date(updateCouponDto.endDate)) {
        throw new BadRequestException('Data de início não pode ser maior que data de término');
      }
    }

    // Validate value
    if (updateCouponDto.type === CouponType.PERCENTAGE && updateCouponDto.value > 100) {
      throw new BadRequestException('Porcentagem não pode ser maior que 100%');
    }

    Object.assign(coupon, updateCouponDto);

    const savedCoupon = await this.couponRepository.save(coupon);

    // Log update
    await this.logRepository.save({
      level: 'info',
      message: `Cupom atualizado: ${savedCoupon.code}`,
      context: { couponId: savedCoupon.id },
      userId: user.id,
    });

    return savedCoupon;
  }

  async remove(id: string, user: User): Promise<void> {
    const coupon = await this.findOne(id, user);

    // Check permissions
    if (user.role === UserRole.PRODUCER) {
      if (coupon.product && coupon.product.producerId !== user.id) {
        throw new ForbiddenException('Você não tem permissão para excluir este cupom');
      }
    }

    await this.couponRepository.softRemove(coupon);

    // Log deletion
    await this.logRepository.save({
      level: 'info',
      message: `Cupom removido: ${coupon.code}`,
      context: { couponId: coupon.id },
      userId: user.id,
    });
  }

  async validate(validateCouponDto: ValidateCouponDto): Promise<{ valid: boolean; coupon?: Coupon; discount?: number; message?: string }> {
    const coupon = await this.couponRepository.findOne({
      where: { code: validateCouponDto.code.toUpperCase() },
      relations: ['product'],
    });

    if (!coupon) {
      return { valid: false, message: 'Cupom não encontrado' };
    }

    // Check status
    if (coupon.status !== CouponStatus.ACTIVE) {
      return { valid: false, message: 'Cupom não está ativo' };
    }

    // Check dates
    const now = new Date();
    if (coupon.startDate && now < coupon.startDate) {
      return { valid: false, message: 'Cupom ainda não está válido' };
    }
    if (coupon.endDate && now > coupon.endDate) {
      return { valid: false, message: 'Cupom expirado' };
    }

    // Check usage limit
    if (coupon.usageLimit && coupon.usageCount >= coupon.usageLimit) {
      return { valid: false, message: 'Limite de uso do cupom atingido' };
    }

    // Check product applicability
    if (coupon.productId && coupon.productId !== validateCouponDto.productId) {
      return { valid: false, message: 'Cupom não válido para este produto' };
    }

    // Calculate discount
    let discount = 0;
    if (coupon.type === CouponType.PERCENTAGE) {
      discount = (validateCouponDto.amount * coupon.value) / 100;
    } else {
      discount = coupon.value;
    }

    // Apply max discount if set
    if (coupon.maxDiscount && discount > coupon.maxDiscount) {
      discount = coupon.maxDiscount;
    }

    // Ensure discount doesn't exceed amount
    discount = Math.min(discount, validateCouponDto.amount);

    return {
      valid: true,
      coupon,
      discount,
    };
  }

  async incrementUsage(id: string): Promise<void> {
    await this.couponRepository.increment({ id }, 'usageCount', 1);
  }

  async getStats(user: User): Promise<any> {
    const queryBuilder = this.couponRepository.createQueryBuilder('coupon')
      .leftJoin('coupon.product', 'product');

    // Apply role-based filtering
    if (user.role === UserRole.PRODUCER) {
      queryBuilder.where('product.producerId = :producerId', { producerId: user.id });
    }

    const [
      totalCoupons,
      activeCoupons,
      inactiveCoupons,
      expiredCoupons,
      totalUsage,
    ] = await Promise.all([
      queryBuilder.getCount(),
      queryBuilder.clone().andWhere('coupon.status = :status', { status: CouponStatus.ACTIVE }).getCount(),
      queryBuilder.clone().andWhere('coupon.status = :status', { status: CouponStatus.INACTIVE }).getCount(),
      queryBuilder.clone().andWhere('coupon.status = :status', { status: CouponStatus.EXPIRED }).getCount(),
      queryBuilder.clone().select('COALESCE(SUM(coupon.usageCount), 0)', 'total').getRawOne(),
    ]);

    return {
      total: totalCoupons,
      active: activeCoupons,
      inactive: inactiveCoupons,
      expired: expiredCoupons,
      totalUsage: Number(totalUsage?.total || 0),
    };
  }

  async checkExpiredCoupons(): Promise<number> {
    const now = new Date();

    const expiredCoupons = await this.couponRepository.find({
      where: {
        status: CouponStatus.ACTIVE,
        endDate: now,
      },
    });

    let updatedCount = 0;

    for (const coupon of expiredCoupons) {
      coupon.status = CouponStatus.EXPIRED;
      await this.couponRepository.save(coupon);
      updatedCount++;
    }

    this.logger.log(`${updatedCount} cupons expirados atualizados`);

    return updatedCount;
  }
}
