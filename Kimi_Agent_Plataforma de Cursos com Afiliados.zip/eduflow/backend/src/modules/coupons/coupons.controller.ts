import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { CouponsService } from './coupons.service';
import { CreateCouponDto } from './dto/create-coupon.dto';
import { UpdateCouponDto } from './dto/update-coupon.dto';
import { CouponQueryDto } from './dto/coupon-query.dto';
import { ValidateCouponDto } from './dto/validate-coupon.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../../entities/user.entity';

@Controller('coupons')
@UseGuards(JwtAuthGuard, RolesGuard)
export class CouponsController {
  constructor(private readonly couponsService: CouponsService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @Roles(UserRole.ADMIN, UserRole.PRODUCER)
  async create(@Body() createCouponDto: CreateCouponDto, @Request() req) {
    const coupon = await this.couponsService.create(createCouponDto, req.user);
    return {
      success: true,
      data: coupon,
      message: 'Cupom criado com sucesso',
    };
  }

  @Get()
  async findAll(@Query() query: CouponQueryDto, @Request() req) {
    const result = await this.couponsService.findAll(query, req.user);
    return {
      success: true,
      data: result.data,
      meta: {
        total: result.total,
        page: result.page,
        limit: result.limit,
        totalPages: Math.ceil(result.total / result.limit),
      },
    };
  }

  @Get('stats')
  async getStats(@Request() req) {
    const stats = await this.couponsService.getStats(req.user);
    return {
      success: true,
      data: stats,
    };
  }

  @Get('validate')
  async validate(@Query() validateCouponDto: ValidateCouponDto) {
    const result = await this.couponsService.validate(validateCouponDto);
    return {
      success: true,
      data: result,
    };
  }

  @Get(':id')
  async findOne(@Param('id') id: string, @Request() req) {
    const coupon = await this.couponsService.findOne(id, req.user);
    return {
      success: true,
      data: coupon,
    };
  }

  @Get('code/:code')
  async findByCode(@Param('code') code: string) {
    const coupon = await this.couponsService.findByCode(code);
    return {
      success: true,
      data: coupon,
    };
  }

  @Patch(':id')
  @Roles(UserRole.ADMIN, UserRole.PRODUCER)
  async update(
    @Param('id') id: string,
    @Body() updateCouponDto: UpdateCouponDto,
    @Request() req,
  ) {
    const coupon = await this.couponsService.update(id, updateCouponDto, req.user);
    return {
      success: true,
      data: coupon,
      message: 'Cupom atualizado com sucesso',
    };
  }

  @Delete(':id')
  @Roles(UserRole.ADMIN, UserRole.PRODUCER)
  async remove(@Param('id') id: string, @Request() req) {
    await this.couponsService.remove(id, req.user);
    return {
      success: true,
      message: 'Cupom removido com sucesso',
    };
  }

  @Post('check-expired')
  @Roles(UserRole.ADMIN)
  @HttpCode(HttpStatus.OK)
  async checkExpired() {
    const count = await this.couponsService.checkExpiredCoupons();
    return {
      success: true,
      data: { expiredCount: count },
      message: `${count} cupons expirados atualizados`,
    };
  }
}
