import {
  IsString,
  MinLength,
  MaxLength,
  IsOptional,
  IsDate,
  IsPhoneNumber,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class UpdateProfileDto {
  @ApiPropertyOptional({ example: 'João', description: 'Primeiro nome' })
  @IsOptional()
  @IsString()
  @MinLength(2)
  @MaxLength(100)
  firstName?: string;

  @ApiPropertyOptional({ example: 'Silva', description: 'Sobrenome' })
  @IsOptional()
  @IsString()
  @MinLength(2)
  @MaxLength(100)
  lastName?: string;

  @ApiPropertyOptional({ example: '+5511999999999', description: 'Telefone' })
  @IsOptional()
  @IsPhoneNumber('BR')
  phone?: string;

  @ApiPropertyOptional({ description: 'URL do avatar' })
  @IsOptional()
  @IsString()
  avatar?: string;

  @ApiPropertyOptional({ example: '1990-01-01', description: 'Data de nascimento' })
  @IsOptional()
  @Type(() => Date)
  @IsDate()
  birthDate?: Date;

  // Address
  @ApiPropertyOptional({ example: 'Rua Exemplo', description: 'Endereço' })
  @IsOptional()
  @IsString()
  address?: string;

  @ApiPropertyOptional({ example: '123', description: 'Número' })
  @IsOptional()
  @IsString()
  addressNumber?: string;

  @ApiPropertyOptional({ example: 'Apto 45', description: 'Complemento' })
  @IsOptional()
  @IsString()
  complement?: string;

  @ApiPropertyOptional({ example: 'Centro', description: 'Bairro' })
  @IsOptional()
  @IsString()
  neighborhood?: string;

  @ApiPropertyOptional({ example: 'São Paulo', description: 'Cidade' })
  @IsOptional()
  @IsString()
  city?: string;

  @ApiPropertyOptional({ example: 'SP', description: 'Estado' })
  @IsOptional()
  @IsString()
  @MaxLength(2)
  state?: string;

  @ApiPropertyOptional({ example: '01000-000', description: 'CEP' })
  @IsOptional()
  @IsString()
  zipCode?: string;

  // Bank info
  @ApiPropertyOptional({ example: 'Banco do Brasil', description: 'Nome do banco' })
  @IsOptional()
  @IsString()
  bankName?: string;

  @ApiPropertyOptional({ example: '001', description: 'Código do banco' })
  @IsOptional()
  @IsString()
  bankCode?: string;

  @ApiPropertyOptional({ example: '1234', description: 'Agência' })
  @IsOptional()
  @IsString()
  agency?: string;

  @ApiPropertyOptional({ example: '12345-6', description: 'Número da conta' })
  @IsOptional()
  @IsString()
  accountNumber?: string;

  @ApiPropertyOptional({ example: 'corrente', description: 'Tipo de conta' })
  @IsOptional()
  @IsString()
  accountType?: string;

  @ApiPropertyOptional({ example: '123.456.789-00', description: 'Chave PIX' })
  @IsOptional()
  @IsString()
  pixKey?: string;
}
