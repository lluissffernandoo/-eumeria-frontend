import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ConflictException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like, In } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { ConfigService } from '@nestjs/config';
import { User, UserRole, UserStatus } from '../../entities/user.entity';
import { Log, LogCategory } from '../../entities/log.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { QueryUsersDto } from './dto/query-users.dto';

export interface PaginatedUsersResponse {
  data: User[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @InjectRepository(Log)
    private readonly logRepository: Repository<Log>,
    private readonly configService: ConfigService,
  ) {}

  async findAll(query: QueryUsersDto): Promise<PaginatedUsersResponse> {
    const {
      page = 1,
      limit = 10,
      search,
      role,
      status,
      sortBy = 'createdAt',
      sortOrder = 'DESC',
    } = query;

    const where: any = {};

    if (role) {
      where.role = role;
    }

    if (status) {
      where.status = status;
    }

    if (search) {
      where.fullName = Like(`%${search}%`);
    }

    const [data, total] = await this.userRepository.findAndCount({
      where,
      order: { [sortBy]: sortOrder },
      skip: (page - 1) * limit,
      take: limit,
      select: [
        'id',
        'email',
        'firstName',
        'lastName',
        'fullName',
        'role',
        'status',
        'avatar',
        'emailVerified',
        'createdAt',
        'lastLoginAt',
      ],
    });

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findById(id: string): Promise<User> {
    const user = await this.userRepository.findOne({
      where: { id },
    });

    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    return user;
  }

  async findByEmail(email: string): Promise<User | null> {
    return this.userRepository.findOne({
      where: { email: email.toLowerCase() },
    });
  }

  async create(createUserDto: CreateUserDto, adminId?: string): Promise<User> {
    const { email, password, firstName, lastName, role, phone, document } = createUserDto;

    // Check if email exists
    const existingUser = await this.findByEmail(email);
    if (existingUser) {
      throw new ConflictException('E-mail já cadastrado');
    }

    // Check if document exists
    if (document) {
      const existingDocument = await this.userRepository.findOne({
        where: { document },
      });
      if (existingDocument) {
        throw new ConflictException('Documento já cadastrado');
      }
    }

    // Hash password
    const saltRounds = this.configService.get<number>('app.bcryptRounds', 12);
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    const user = this.userRepository.create({
      email: email.toLowerCase(),
      password: hashedPassword,
      firstName,
      lastName,
      fullName: `${firstName} ${lastName}`,
      role: role || UserRole.CUSTOMER,
      status: UserStatus.ACTIVE,
      phone,
      document,
      emailVerified: true, // Admin-created users are pre-verified
    });

    await this.userRepository.save(user);

    await this.logRepository.save(
      Log.info(LogCategory.USER, 'User created by admin', {
        userId: user.id,
        email: user.email,
        role: user.role,
        createdBy: adminId,
      }),
    );

    return user;
  }

  async update(id: string, updateUserDto: UpdateUserDto, adminId?: string): Promise<User> {
    const user = await this.findById(id);

    // Prevent changing own role (safety measure)
    if (adminId === id && updateUserDto.role && updateUserDto.role !== user.role) {
      throw new ForbiddenException('Não é possível alterar seu próprio papel');
    }

    // Prevent demoting the last master
    if (user.role === UserRole.MASTER && updateUserDto.role && updateUserDto.role !== UserRole.MASTER) {
      const masterCount = await this.userRepository.count({
        where: { role: UserRole.MASTER, status: UserStatus.ACTIVE },
      });
      if (masterCount <= 1) {
        throw new ForbiddenException('Não é possível remover o último administrador master');
      }
    }

    // Update fields
    if (updateUserDto.firstName || updateUserDto.lastName) {
      user.firstName = updateUserDto.firstName || user.firstName;
      user.lastName = updateUserDto.lastName || user.lastName;
      user.fullName = `${user.firstName} ${user.lastName}`;
    }

    if (updateUserDto.phone !== undefined) {
      user.phone = updateUserDto.phone;
    }

    if (updateUserDto.role !== undefined) {
      user.role = updateUserDto.role;
    }

    if (updateUserDto.status !== undefined) {
      user.status = updateUserDto.status;
    }

    if (updateUserDto.avatar !== undefined) {
      user.avatar = updateUserDto.avatar;
    }

    await this.userRepository.save(user);

    await this.logRepository.save(
      Log.info(LogCategory.USER, 'User updated', {
        userId: user.id,
        updatedBy: adminId,
        changes: Object.keys(updateUserDto),
      }),
    );

    return user;
  }

  async updateProfile(userId: string, updateProfileDto: UpdateProfileDto): Promise<User> {
    const user = await this.findById(userId);

    if (updateProfileDto.firstName || updateProfileDto.lastName) {
      user.firstName = updateProfileDto.firstName || user.firstName;
      user.lastName = updateProfileDto.lastName || user.lastName;
      user.fullName = `${user.firstName} ${user.lastName}`;
    }

    if (updateProfileDto.phone !== undefined) {
      user.phone = updateProfileDto.phone;
    }

    if (updateProfileDto.avatar !== undefined) {
      user.avatar = updateProfileDto.avatar;
    }

    if (updateProfileDto.birthDate !== undefined) {
      user.birthDate = updateProfileDto.birthDate;
    }

    // Update address
    if (updateProfileDto.address !== undefined) {
      user.address = updateProfileDto.address;
    }
    if (updateProfileDto.addressNumber !== undefined) {
      user.addressNumber = updateProfileDto.addressNumber;
    }
    if (updateProfileDto.complement !== undefined) {
      user.complement = updateProfileDto.complement;
    }
    if (updateProfileDto.neighborhood !== undefined) {
      user.neighborhood = updateProfileDto.neighborhood;
    }
    if (updateProfileDto.city !== undefined) {
      user.city = updateProfileDto.city;
    }
    if (updateProfileDto.state !== undefined) {
      user.state = updateProfileDto.state;
    }
    if (updateProfileDto.zipCode !== undefined) {
      user.zipCode = updateProfileDto.zipCode;
    }

    // Update bank info
    if (updateProfileDto.bankName !== undefined) {
      user.bankName = updateProfileDto.bankName;
    }
    if (updateProfileDto.bankCode !== undefined) {
      user.bankCode = updateProfileDto.bankCode;
    }
    if (updateProfileDto.agency !== undefined) {
      user.agency = updateProfileDto.agency;
    }
    if (updateProfileDto.accountNumber !== undefined) {
      user.accountNumber = updateProfileDto.accountNumber;
    }
    if (updateProfileDto.accountType !== undefined) {
      user.accountType = updateProfileDto.accountType;
    }
    if (updateProfileDto.pixKey !== undefined) {
      user.pixKey = updateProfileDto.pixKey;
    }

    await this.userRepository.save(user);

    return user;
  }

  async remove(id: string, adminId?: string): Promise<void> {
    const user = await this.findById(id);

    // Prevent self-deletion
    if (adminId === id) {
      throw new ForbiddenException('Não é possível excluir sua própria conta');
    }

    // Prevent deleting the last master
    if (user.role === UserRole.MASTER) {
      const masterCount = await this.userRepository.count({
        where: { role: UserRole.MASTER, status: UserStatus.ACTIVE },
      });
      if (masterCount <= 1) {
        throw new ForbiddenException('Não é possível excluir o último administrador master');
      }
    }

    await this.userRepository.softRemove(user);

    await this.logRepository.save(
      Log.info(LogCategory.USER, 'User deleted', {
        userId: user.id,
        email: user.email,
        deletedBy: adminId,
      }),
    );
  }

  async restore(id: string, adminId?: string): Promise<User> {
    const user = await this.userRepository.findOne({
      where: { id },
      withDeleted: true,
    });

    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    if (!user.deletedAt) {
      throw new BadRequestException('Usuário não está excluído');
    }

    user.deletedAt = null;
    await this.userRepository.save(user);

    await this.logRepository.save(
      Log.info(LogCategory.USER, 'User restored', {
        userId: user.id,
        restoredBy: adminId,
      }),
    );

    return user;
  }

  async getStats(): Promise<any> {
    const [
      totalUsers,
      activeUsers,
      pendingUsers,
      blockedUsers,
      producers,
      affiliates,
      customers,
      newUsersToday,
      newUsersThisWeek,
      newUsersThisMonth,
    ] = await Promise.all([
      this.userRepository.count(),
      this.userRepository.count({ where: { status: UserStatus.ACTIVE } }),
      this.userRepository.count({ where: { status: UserStatus.PENDING } }),
      this.userRepository.count({ where: { status: UserStatus.BLOCKED } }),
      this.userRepository.count({ where: { role: UserRole.PRODUCER } }),
      this.userRepository.count({ where: { role: UserRole.AFFILIATE } }),
      this.userRepository.count({ where: { role: UserRole.CUSTOMER } }),
      this.userRepository.count({
        where: {
          createdAt: new Date(new Date().setHours(0, 0, 0, 0)),
        },
      }),
      this.userRepository.count({
        where: {
          createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        },
      }),
      this.userRepository.count({
        where: {
          createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        },
      }),
    ]);

    return {
      total: totalUsers,
      byStatus: {
        active: activeUsers,
        pending: pendingUsers,
        blocked: blockedUsers,
      },
      byRole: {
        producers,
        affiliates,
        customers,
      },
      newUsers: {
        today: newUsersToday,
        thisWeek: newUsersThisWeek,
        thisMonth: newUsersThisMonth,
      },
    };
  }
}
