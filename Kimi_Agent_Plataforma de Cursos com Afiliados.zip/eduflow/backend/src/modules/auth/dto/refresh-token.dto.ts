import { IsString, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class RefreshTokenDto {
  @ApiProperty({ example: 'eyJhbGciOiJIUzI1NiIs...', description: 'Token de refresh' })
  @IsString({ message: 'Token de refresh deve ser uma string' })
  @MinLength(10, { message: 'Token de refresh inválido' })
  refreshToken: string;
}
