import { IsString, MinLength, MaxLength, Matches } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class ResetPasswordDto {
  @ApiProperty({ example: 'abc123...', description: 'Token de recuperação de senha' })
  @IsString({ message: 'Token deve ser uma string' })
  @MinLength(10, { message: 'Token inválido' })
  token: string;

  @ApiProperty({ example: 'NovaSenha@123', description: 'Nova senha' })
  @IsString({ message: 'Nova senha deve ser uma string' })
  @MinLength(8, { message: 'Nova senha deve ter no mínimo 8 caracteres' })
  @MaxLength(100, { message: 'Nova senha deve ter no máximo 100 caracteres' })
  @Matches(
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/,
    {
      message: 'Nova senha deve conter pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial',
    }
  )
  newPassword: string;

  @ApiProperty({ example: 'NovaSenha@123', description: 'Confirmação da nova senha' })
  @IsString({ message: 'Confirmação de senha deve ser uma string' })
  confirmNewPassword: string;
}
