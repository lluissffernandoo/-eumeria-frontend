import {
  IsEmail,
  IsString,
  MinLength,
  MaxLength,
  IsOptional,
  IsPhoneNumber,
  Matches,
  Validate,
  ValidatorConstraint,
  ValidatorConstraintInterface,
  ValidationArguments,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

@ValidatorConstraint({ name: 'passwordMatch', async: false })
class PasswordMatchConstraint implements ValidatorConstraintInterface {
  validate(confirmPassword: string, args: ValidationArguments) {
    const object = args.object as any;
    return object.password === confirmPassword;
  }

  defaultMessage() {
    return 'As senhas não coincidem';
  }
}

export class RegisterDto {
  @ApiProperty({ example: 'joao@exemplo.com', description: 'E-mail do usuário' })
  @IsEmail({}, { message: 'E-mail inválido' })
  @MaxLength(255, { message: 'E-mail deve ter no máximo 255 caracteres' })
  email: string;

  @ApiProperty({ example: 'João', description: 'Primeiro nome' })
  @IsString({ message: 'Nome deve ser uma string' })
  @MinLength(2, { message: 'Nome deve ter no mínimo 2 caracteres' })
  @MaxLength(100, { message: 'Nome deve ter no máximo 100 caracteres' })
  firstName: string;

  @ApiProperty({ example: 'Silva', description: 'Sobrenome' })
  @IsString({ message: 'Sobrenome deve ser uma string' })
  @MinLength(2, { message: 'Sobrenome deve ter no mínimo 2 caracteres' })
  @MaxLength(100, { message: 'Sobrenome deve ter no máximo 100 caracteres' })
  lastName: string;

  @ApiProperty({ example: 'Senha@123', description: 'Senha (mínimo 8 caracteres, 1 maiúscula, 1 minúscula, 1 número, 1 caractere especial)' })
  @IsString({ message: 'Senha deve ser uma string' })
  @MinLength(8, { message: 'Senha deve ter no mínimo 8 caracteres' })
  @MaxLength(100, { message: 'Senha deve ter no máximo 100 caracteres' })
  @Matches(
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/,
    {
      message: 'Senha deve conter pelo menos uma letra maiúscula, uma minúscula, um número e um caractere especial',
    }
  )
  password: string;

  @ApiProperty({ example: 'Senha@123', description: 'Confirmação da senha' })
  @IsString({ message: 'Confirmação de senha deve ser uma string' })
  @Validate(PasswordMatchConstraint)
  confirmPassword: string;

  @ApiPropertyOptional({ example: '+5511999999999', description: 'Telefone' })
  @IsOptional()
  @IsPhoneNumber('BR', { message: 'Telefone inválido' })
  phone?: string;

  @ApiPropertyOptional({ example: '123.456.789-00', description: 'CPF ou CNPJ' })
  @IsOptional()
  @IsString({ message: 'Documento deve ser uma string' })
  @Matches(/^\d{3}\.\d{3}\.\d{3}-\d{2}$|^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$|^\d{11}$|^\d{14}$/, {
    message: 'Documento deve ser um CPF ou CNPJ válido',
  })
  document?: string;
}
