import { IsEmail } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class RequestPasswordResetDto {
  @ApiProperty({ example: 'joao@exemplo.com', description: 'E-mail para recuperação de senha' })
  @IsEmail({}, { message: 'E-mail inválido' })
  email: string;
}
