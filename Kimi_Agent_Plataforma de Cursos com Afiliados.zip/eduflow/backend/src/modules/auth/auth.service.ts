import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  ConflictException,
  ForbiddenException,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import { User, UserRole, UserStatus } from '../../entities/user.entity';
import { Log, LogCategory } from '../../entities/log.entity';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { ChangePasswordDto } from './dto/change-password.dto';
import { RequestPasswordResetDto } from './dto/request-password-reset.dto';
import { ResetPasswordDto } from './dto/reset-password.dto';
import { VerifyEmailDto } from './dto/verify-email.dto';

export interface TokenPayload {
  sub: string;
  email: string;
  role: UserRole;
  type: 'access' | 'refresh';
}

export interface AuthResponse {
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    fullName: string;
    role: UserRole;
    avatar: string | null;
    emailVerified: boolean;
    twoFactorEnabled: boolean;
  };
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @InjectRepository(Log)
    private readonly logRepository: Repository<Log>,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async register(registerDto: RegisterDto, ip?: string, userAgent?: string): Promise<AuthResponse> {
    const { email, password, firstName, lastName, phone, document } = registerDto;

    // Check if email already exists
    const existingUser = await this.userRepository.findOne({
      where: { email: email.toLowerCase() },
    });

    if (existingUser) {
      throw new ConflictException('Este e-mail já está cadastrado');
    }

    // Check if document already exists
    if (document) {
      const existingDocument = await this.userRepository.findOne({
        where: { document },
      });
      if (existingDocument) {
        throw new ConflictException('Este documento já está cadastrado');
      }
    }

    // Hash password
    const saltRounds = this.configService.get<number>('app.bcryptRounds', 12);
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Create user
    const user = this.userRepository.create({
      email: email.toLowerCase(),
      password: hashedPassword,
      firstName,
      lastName,
      fullName: `${firstName} ${lastName}`,
      phone,
      document,
      role: UserRole.CUSTOMER,
      status: UserStatus.ACTIVE,
      emailVerified: false,
      lastIp: ip,
      userAgent,
    });

    // Generate email verification token
    const verificationToken = crypto.randomBytes(32).toString('hex');
    user.emailVerificationToken = crypto
      .createHash('sha256')
      .update(verificationToken)
      .digest('hex');
    user.emailVerificationExpires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    await this.userRepository.save(user);

    // Log registration
    await this.logRepository.save(
      Log.info(LogCategory.AUTH, 'User registered', {
        userId: user.id,
        email: user.email,
        ip,
        userAgent,
      }),
    );

    // Generate tokens
    const tokens = await this.generateTokens(user);

    return {
      user: this.sanitizeUser(user),
      ...tokens,
    };
  }

  async login(loginDto: LoginDto, ip?: string, userAgent?: string): Promise<AuthResponse> {
    const { email, password, twoFactorCode } = loginDto;

    // Find user
    const user = await this.userRepository.findOne({
      where: { email: email.toLowerCase() },
    });

    if (!user) {
      await this.logFailedLogin(email, ip, userAgent, 'User not found');
      throw new UnauthorizedException('E-mail ou senha incorretos');
    }

    // Check if user is active
    if (user.status !== UserStatus.ACTIVE) {
      await this.logFailedLogin(email, ip, userAgent, `User status: ${user.status}`);
      throw new ForbiddenException('Conta suspensa ou inativa. Entre em contato com o suporte.');
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      await this.logFailedLogin(email, ip, userAgent, 'Invalid password');
      throw new UnauthorizedException('E-mail ou senha incorretos');
    }

    // Check 2FA if enabled
    if (user.twoFactorEnabled) {
      if (!twoFactorCode) {
        throw new BadRequestException('Código de autenticação de dois fatores necessário');
      }
      // Verify 2FA code (implementation depends on 2FA library)
      // const isValid2FA = this.verify2FACode(user.twoFactorSecret, twoFactorCode);
      // if (!isValid2FA) {
      //   throw new UnauthorizedException('Código 2FA inválido');
      // }
    }

    // Update last login info
    user.lastLoginAt = new Date();
    user.lastIp = ip;
    user.userAgent = userAgent;
    await this.userRepository.save(user);

    // Log successful login
    await this.logRepository.save(
      Log.info(LogCategory.AUTH, 'User logged in', {
        userId: user.id,
        email: user.email,
        ip,
        userAgent,
      }),
    );

    // Generate tokens
    const tokens = await this.generateTokens(user);

    return {
      user: this.sanitizeUser(user),
      ...tokens,
    };
  }

  async refreshTokens(refreshTokenDto: RefreshTokenDto): Promise<AuthResponse> {
    const { refreshToken } = refreshTokenDto;

    try {
      // Verify refresh token
      const payload = this.jwtService.verify(refreshToken, {
        secret: this.configService.get<string>('jwt.refreshTokenSecret'),
      });

      if (payload.type !== 'refresh') {
        throw new UnauthorizedException('Token inválido');
      }

      // Find user
      const user = await this.userRepository.findOne({
        where: { id: payload.sub },
      });

      if (!user || user.status !== UserStatus.ACTIVE) {
        throw new UnauthorizedException('Usuário não encontrado ou inativo');
      }

      // Generate new tokens
      const tokens = await this.generateTokens(user);

      return {
        user: this.sanitizeUser(user),
        ...tokens,
      };
    } catch (error) {
      throw new UnauthorizedException('Token de refresh inválido ou expirado');
    }
  }

  async logout(userId: string): Promise<void> {
    // In a more complex implementation, you might want to blacklist the token
    await this.logRepository.save(
      Log.info(LogCategory.AUTH, 'User logged out', { userId }),
    );
  }

  async changePassword(userId: string, changePasswordDto: ChangePasswordDto): Promise<void> {
    const { currentPassword, newPassword } = changePasswordDto;

    const user = await this.userRepository.findOne({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    // Verify current password
    const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isPasswordValid) {
      throw new BadRequestException('Senha atual incorreta');
    }

    // Hash new password
    const saltRounds = this.configService.get<number>('app.bcryptRounds', 12);
    user.password = await bcrypt.hash(newPassword, saltRounds);
    await this.userRepository.save(user);

    await this.logRepository.save(
      Log.info(LogCategory.AUTH, 'Password changed', { userId }),
    );
  }

  async requestPasswordReset(requestDto: RequestPasswordResetDto): Promise<void> {
    const { email } = requestDto;

    const user = await this.userRepository.findOne({
      where: { email: email.toLowerCase() },
    });

    if (!user) {
      // Don't reveal if email exists
      return;
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    user.passwordResetToken = crypto
      .createHash('sha256')
      .update(resetToken)
      .digest('hex');
    user.passwordResetExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await this.userRepository.save(user);

    // TODO: Send email with reset token
    // await this.emailService.sendPasswordResetEmail(user.email, resetToken);

    await this.logRepository.save(
      Log.info(LogCategory.AUTH, 'Password reset requested', {
        userId: user.id,
        email: user.email,
      }),
    );
  }

  async resetPassword(resetDto: ResetPasswordDto): Promise<void> {
    const { token, newPassword } = resetDto;

    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await this.userRepository.findOne({
      where: {
        passwordResetToken: hashedToken,
        passwordResetExpires: new Date(Date.now()),
      },
    });

    if (!user) {
      throw new BadRequestException('Token inválido ou expirado');
    }

    // Hash new password
    const saltRounds = this.configService.get<number>('app.bcryptRounds', 12);
    user.password = await bcrypt.hash(newPassword, saltRounds);
    user.passwordResetToken = null;
    user.passwordResetExpires = null;

    await this.userRepository.save(user);

    await this.logRepository.save(
      Log.info(LogCategory.AUTH, 'Password reset completed', { userId: user.id }),
    );
  }

  async verifyEmail(verifyDto: VerifyEmailDto): Promise<void> {
    const { token } = verifyDto;

    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await this.userRepository.findOne({
      where: {
        emailVerificationToken: hashedToken,
        emailVerificationExpires: new Date(Date.now()),
      },
    });

    if (!user) {
      throw new BadRequestException('Token inválido ou expirado');
    }

    user.emailVerified = true;
    user.emailVerificationToken = null;
    user.emailVerificationExpires = null;

    await this.userRepository.save(user);

    await this.logRepository.save(
      Log.info(LogCategory.AUTH, 'Email verified', { userId: user.id, email: user.email }),
    );
  }

  async validateUser(email: string, password: string): Promise<User | null> {
    const user = await this.userRepository.findOne({
      where: { email: email.toLowerCase() },
    });

    if (user && await bcrypt.compare(password, user.password)) {
      return user;
    }

    return null;
  }

  private async generateTokens(user: User): Promise<{ accessToken: string; refreshToken: string; expiresIn: number }> {
    const accessTokenPayload: TokenPayload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      type: 'access',
    };

    const refreshTokenPayload: TokenPayload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      type: 'refresh',
    };

    const accessToken = this.jwtService.sign(accessTokenPayload, {
      secret: this.configService.get<string>('jwt.accessTokenSecret'),
      expiresIn: this.configService.get<string>('jwt.accessTokenExpiration'),
    });

    const refreshToken = this.jwtService.sign(refreshTokenPayload, {
      secret: this.configService.get<string>('jwt.refreshTokenSecret'),
      expiresIn: this.configService.get<string>('jwt.refreshTokenExpiration'),
    });

    // Parse expiration time
    const expirationStr = this.configService.get<string>('jwt.accessTokenExpiration', '15m');
    const expiresIn = this.parseExpiration(expirationStr);

    return { accessToken, refreshToken, expiresIn };
  }

  private parseExpiration(expiration: string): number {
    const match = expiration.match(/^(\d+)([smhd])$/);
    if (!match) return 900; // Default 15 minutes

    const value = parseInt(match[1], 10);
    const unit = match[2];

    const multipliers: Record<string, number> = {
      s: 1,
      m: 60,
      h: 3600,
      d: 86400,
    };

    return value * (multipliers[unit] || 60);
  }

  private sanitizeUser(user: User) {
    return {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      fullName: user.fullName,
      role: user.role,
      avatar: user.avatar,
      emailVerified: user.emailVerified,
      twoFactorEnabled: user.twoFactorEnabled,
    };
  }

  private async logFailedLogin(email: string, ip: string, userAgent: string, reason: string): Promise<void> {
    await this.logRepository.save(
      Log.warn(LogCategory.AUTH, 'Failed login attempt', {
        email,
        ip,
        userAgent,
        reason,
      }),
    );
  }
}
