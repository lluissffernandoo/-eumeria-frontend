import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Brackets } from 'typeorm';
import {
  Commission,
  CommissionStatus,
  CommissionType,
} from '../../entities/commission.entity';
import { Affiliate } from '../../entities/affiliate.entity';
import { Sale } from '../../entities/sale.entity';
import { Log } from '../../entities/log.entity';
import { User, UserRole } from '../../entities/user.entity';
import { CommissionQueryDto } from './dto/commission-query.dto';

@Injectable()
export class CommissionsService {
  private readonly logger = new Logger(CommissionsService.name);

  constructor(
    @InjectRepository(Commission)
    private commissionRepository: Repository<Commission>,
    @InjectRepository(Affiliate)
    private affiliateRepository: Repository<Affiliate>,
    @InjectRepository(Sale)
    private saleRepository: Repository<Sale>,
    @InjectRepository(Log)
    private logRepository: Repository<Log>,
  ) {}

  async createFromSale(sale: Sale): Promise<Commission[]> {
    const commissions: Commission[] = [];

    // Create affiliate commission if applicable
    if (sale.hasAffiliate && sale.affiliateId && sale.affiliateCommission > 0) {
      const affiliateCommission = this.commissionRepository.create({
        type: CommissionType.AFFILIATE,
        status: CommissionStatus.PENDING,
        amount: sale.affiliateCommission,
        rate: (sale.affiliateCommission / sale.finalPrice) * 100,
        currency: sale.currency,
        saleAmount: sale.finalPrice,
        orderNumber: sale.orderNumber,
        productName: sale.product.name,
        guaranteeDays: sale.guaranteeDays,
        guaranteeExpiresAt: sale.guaranteeExpiresAt,
        affiliateId: sale.affiliateId,
        saleId: sale.id,
        productId: sale.productId,
      });

      commissions.push(await this.commissionRepository.save(affiliateCommission));
    }

    // Create producer commission
    const producerCommission = this.commissionRepository.create({
      type: CommissionType.PRODUCER,
      status: CommissionStatus.PENDING,
      amount: sale.producerRevenue,
      rate: (sale.producerRevenue / sale.finalPrice) * 100,
      currency: sale.currency,
      saleAmount: sale.finalPrice,
      orderNumber: sale.orderNumber,
      productName: sale.product.name,
      guaranteeDays: sale.guaranteeDays,
      guaranteeExpiresAt: sale.guaranteeExpiresAt,
      producerId: sale.product.producerId,
      saleId: sale.id,
      productId: sale.productId,
    });

    commissions.push(await this.commissionRepository.save(producerCommission));

    // Create platform commission
    const platformCommission = this.commissionRepository.create({
      type: CommissionType.PLATFORM,
      status: CommissionStatus.APPROVED,
      amount: sale.platformFee,
      rate: (sale.platformFee / sale.finalPrice) * 100,
      currency: sale.currency,
      saleAmount: sale.finalPrice,
      orderNumber: sale.orderNumber,
      productName: sale.product.name,
      producerId: sale.product.producerId,
      saleId: sale.id,
      productId: sale.productId,
    });

    commissions.push(await this.commissionRepository.save(platformCommission));

    this.logger.log(`Comissões criadas para venda ${sale.orderNumber}: ${commissions.length}`);

    return commissions;
  }

  async findAll(query: CommissionQueryDto, user: User): Promise<{ data: Commission[]; total: number; page: number; limit: number }> {
    const { page = 1, limit = 20 } = query;
    const skip = (page - 1) * limit;

    const queryBuilder = this.commissionRepository.createQueryBuilder('commission')
      .leftJoinAndSelect('commission.affiliate', 'affiliate')
      .leftJoinAndSelect('commission.sale', 'sale')
      .leftJoinAndSelect('commission.product', 'product');

    // Apply role-based filtering
    if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (affiliate) {
        queryBuilder.where('commission.affiliateId = :affiliateId', { affiliateId: affiliate.id });
      }
    } else if (user.role === UserRole.PRODUCER) {
      queryBuilder.where('commission.producerId = :producerId', { producerId: user.id });
    }

    // Apply filters
    if (query.status) {
      queryBuilder.andWhere('commission.status = :status', { status: query.status });
    }

    if (query.type) {
      queryBuilder.andWhere('commission.type = :type', { type: query.type });
    }

    if (query.saleId) {
      queryBuilder.andWhere('commission.saleId = :saleId', { saleId: query.saleId });
    }

    if (query.productId) {
      queryBuilder.andWhere('commission.productId = :productId', { productId: query.productId });
    }

    if (query.startDate) {
      queryBuilder.andWhere('commission.createdAt >= :startDate', { startDate: query.startDate });
    }

    if (query.endDate) {
      queryBuilder.andWhere('commission.createdAt <= :endDate', { endDate: query.endDate });
    }

    // Apply sorting
    const sortBy = query.sortBy || 'createdAt';
    const sortOrder = query.sortOrder || 'DESC';
    queryBuilder.orderBy(`commission.${sortBy}`, sortOrder);

    // Apply pagination
    queryBuilder.skip(skip).take(limit);

    const [data, total] = await queryBuilder.getManyAndCount();

    return { data, total, page, limit };
  }

  async findOne(id: string, user: User): Promise<Commission> {
    const commission = await this.commissionRepository.findOne({
      where: { id },
      relations: ['affiliate', 'affiliate.user', 'sale', 'product'],
    });

    if (!commission) {
      throw new NotFoundException('Comissão não encontrada');
    }

    // Check permissions
    if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (!affiliate || commission.affiliateId !== affiliate.id) {
        throw new ForbiddenException('Você não tem permissão para ver esta comissão');
      }
    }

    if (user.role === UserRole.PRODUCER && commission.producerId !== user.id) {
      throw new ForbiddenException('Você não tem permissão para ver esta comissão');
    }

    return commission;
  }

  async approve(id: string, adminId: string): Promise<Commission> {
    const commission = await this.commissionRepository.findOne({
      where: { id },
      relations: ['affiliate'],
    });

    if (!commission) {
      throw new NotFoundException('Comissão não encontrada');
    }

    if (!commission.canApprove()) {
      throw new BadRequestException('Esta comissão não pode ser aprovada');
    }

    commission.approve(adminId);
    await this.commissionRepository.save(commission);

    // Log approval
    await this.logRepository.save({
      level: 'info',
      message: `Comissão aprovada: ${commission.orderNumber}`,
      context: { commissionId: commission.id, amount: commission.amount },
      userId: adminId,
    });

    return commission;
  }

  async makeAvailable(id: string): Promise<Commission> {
    const commission = await this.commissionRepository.findOne({
      where: { id },
      relations: ['affiliate'],
    });

    if (!commission) {
      throw new NotFoundException('Comissão não encontrada');
    }

    if (!commission.canMakeAvailable()) {
      throw new BadRequestException('Esta comissão não pode ser liberada');
    }

    commission.makeAvailable();
    await this.commissionRepository.save(commission);

    // Update affiliate available balance
    if (commission.affiliateId && commission.type === CommissionType.AFFILIATE) {
      const affiliate = commission.affiliate;
      affiliate.pendingCommission = Math.max(0, affiliate.pendingCommission - commission.amount);
      affiliate.availableCommission += commission.amount;
      await this.affiliateRepository.save(affiliate);
    }

    // Log availability
    await this.logRepository.save({
      level: 'info',
      message: `Comissão liberada: ${commission.orderNumber}`,
      context: { commissionId: commission.id, amount: commission.amount },
    });

    return commission;
  }

  async refund(id: string): Promise<Commission> {
    const commission = await this.commissionRepository.findOne({
      where: { id },
      relations: ['affiliate'],
    });

    if (!commission) {
      throw new NotFoundException('Comissão não encontrada');
    }

    commission.refund();
    await this.commissionRepository.save(commission);

    // Update affiliate balance
    if (commission.affiliateId && commission.type === CommissionType.AFFILIATE) {
      const affiliate = commission.affiliate;
      
      if (commission.status === CommissionStatus.AVAILABLE) {
        affiliate.availableCommission = Math.max(0, affiliate.availableCommission - commission.amount);
      } else if (commission.status === CommissionStatus.PENDING) {
        affiliate.pendingCommission = Math.max(0, affiliate.pendingCommission - commission.amount);
      }
      
      affiliate.totalCommission = Math.max(0, affiliate.totalCommission - commission.amount);
      await this.affiliateRepository.save(affiliate);
    }

    // Log refund
    await this.logRepository.save({
      level: 'info',
      message: `Comissão estornada: ${commission.orderNumber}`,
      context: { commissionId: commission.id, amount: commission.amount },
    });

    return commission;
  }

  async cancel(id: string, reason: string, user: User): Promise<Commission> {
    const commission = await this.commissionRepository.findOne({
      where: { id },
      relations: ['affiliate'],
    });

    if (!commission) {
      throw new NotFoundException('Comissão não encontrada');
    }

    if (commission.status === CommissionStatus.WITHDRAWN) {
      throw new BadRequestException('Não é possível cancelar uma comissão já sacada');
    }

    commission.cancel(reason);
    await this.commissionRepository.save(commission);

    // Update affiliate balance
    if (commission.affiliateId && commission.type === CommissionType.AFFILIATE) {
      const affiliate = commission.affiliate;
      
      if (commission.status === CommissionStatus.AVAILABLE) {
        affiliate.availableCommission = Math.max(0, affiliate.availableCommission - commission.amount);
      } else if (commission.status === CommissionStatus.PENDING) {
        affiliate.pendingCommission = Math.max(0, affiliate.pendingCommission - commission.amount);
      }
      
      await this.affiliateRepository.save(affiliate);
    }

    // Log cancellation
    await this.logRepository.save({
      level: 'info',
      message: `Comissão cancelada: ${commission.orderNumber}`,
      context: { commissionId: commission.id, reason },
      userId: user.id,
    });

    return commission;
  }

  async getStats(user: User): Promise<any> {
    const queryBuilder = this.commissionRepository.createQueryBuilder('commission');

    // Apply role-based filtering
    if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (affiliate) {
        queryBuilder.where('commission.affiliateId = :affiliateId', { affiliateId: affiliate.id });
      }
    } else if (user.role === UserRole.PRODUCER) {
      queryBuilder.where('commission.producerId = :producerId', { producerId: user.id });
    }

    const [
      totalCommissions,
      pendingCommissions,
      availableCommissions,
      withdrawnCommissions,
      totalAmount,
      pendingAmount,
      availableAmount,
      withdrawnAmount,
    ] = await Promise.all([
      queryBuilder.getCount(),
      queryBuilder.clone().andWhere('commission.status = :status', { status: CommissionStatus.PENDING }).getCount(),
      queryBuilder.clone().andWhere('commission.status = :status', { status: CommissionStatus.AVAILABLE }).getCount(),
      queryBuilder.clone().andWhere('commission.status = :status', { status: CommissionStatus.WITHDRAWN }).getCount(),
      queryBuilder.clone().select('COALESCE(SUM(commission.amount), 0)', 'total').getRawOne(),
      queryBuilder.clone().select('COALESCE(SUM(commission.amount), 0)', 'total').andWhere('commission.status = :status', { status: CommissionStatus.PENDING }).getRawOne(),
      queryBuilder.clone().select('COALESCE(SUM(commission.amount), 0)', 'total').andWhere('commission.status = :status', { status: CommissionStatus.AVAILABLE }).getRawOne(),
      queryBuilder.clone().select('COALESCE(SUM(commission.amount), 0)', 'total').andWhere('commission.status = :status', { status: CommissionStatus.WITHDRAWN }).getRawOne(),
    ]);

    return {
      total: {
        count: totalCommissions,
        amount: Number(totalAmount?.total || 0),
      },
      pending: {
        count: pendingCommissions,
        amount: Number(pendingAmount?.total || 0),
      },
      available: {
        count: availableCommissions,
        amount: Number(availableAmount?.total || 0),
      },
      withdrawn: {
        count: withdrawnCommissions,
        amount: Number(withdrawnAmount?.total || 0),
      },
    };
  }

  async processAvailableCommissions(): Promise<number> {
    const now = new Date();

    const pendingCommissions = await this.commissionRepository.find({
      where: {
        status: CommissionStatus.PENDING,
        guaranteeExpiresAt: now,
      },
      relations: ['affiliate'],
    });

    let processedCount = 0;

    for (const commission of pendingCommissions) {
      try {
        await this.makeAvailable(commission.id);
        processedCount++;
      } catch (error) {
        this.logger.error(`Erro ao processar comissão ${commission.id}:`, error);
      }
    }

    this.logger.log(`Processadas ${processedCount} comissões para liberação`);

    return processedCount;
  }
}
