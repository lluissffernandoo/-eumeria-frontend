import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CommissionsService } from './commissions.service';
import { CommissionsController } from './commissions.controller';
import { Commission } from '../../entities/commission.entity';
import { Affiliate } from '../../entities/affiliate.entity';
import { Sale } from '../../entities/sale.entity';
import { Log } from '../../entities/log.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Commission, Affiliate, Sale, Log]),
  ],
  controllers: [CommissionsController],
  providers: [CommissionsService],
  exports: [CommissionsService],
})
export class CommissionsModule {}
