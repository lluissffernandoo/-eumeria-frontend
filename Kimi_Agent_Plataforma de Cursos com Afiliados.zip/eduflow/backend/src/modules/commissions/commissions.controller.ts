import {
  Controller,
  Get,
  Post,
  Param,
  Query,
  Body,
  UseGuards,
  Request,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { CommissionsService } from './commissions.service';
import { CommissionQueryDto } from './dto/commission-query.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../../entities/user.entity';

@Controller('commissions')
@UseGuards(JwtAuthGuard, RolesGuard)
export class CommissionsController {
  constructor(private readonly commissionsService: CommissionsService) {}

  @Get()
  async findAll(@Query() query: CommissionQueryDto, @Request() req) {
    const result = await this.commissionsService.findAll(query, req.user);
    return {
      success: true,
      data: result.data,
      meta: {
        total: result.total,
        page: result.page,
        limit: result.limit,
        totalPages: Math.ceil(result.total / result.limit),
      },
    };
  }

  @Get('stats')
  async getStats(@Request() req) {
    const stats = await this.commissionsService.getStats(req.user);
    return {
      success: true,
      data: stats,
    };
  }

  @Get(':id')
  async findOne(@Param('id') id: string, @Request() req) {
    const commission = await this.commissionsService.findOne(id, req.user);
    return {
      success: true,
      data: commission,
    };
  }

  @Post(':id/approve')
  @Roles(UserRole.ADMIN)
  @HttpCode(HttpStatus.OK)
  async approve(@Param('id') id: string, @Request() req) {
    const commission = await this.commissionsService.approve(id, req.user.id);
    return {
      success: true,
      data: commission,
      message: 'Comissão aprovada com sucesso',
    };
  }

  @Post(':id/make-available')
  @Roles(UserRole.ADMIN)
  @HttpCode(HttpStatus.OK)
  async makeAvailable(@Param('id') id: string) {
    const commission = await this.commissionsService.makeAvailable(id);
    return {
      success: true,
      data: commission,
      message: 'Comissão liberada com sucesso',
    };
  }

  @Post(':id/cancel')
  @Roles(UserRole.ADMIN)
  @HttpCode(HttpStatus.OK)
  async cancel(
    @Param('id') id: string,
    @Body('reason') reason: string,
    @Request() req,
  ) {
    const commission = await this.commissionsService.cancel(id, reason, req.user);
    return {
      success: true,
      data: commission,
      message: 'Comissão cancelada com sucesso',
    };
  }

  @Post('process-available')
  @Roles(UserRole.ADMIN)
  @HttpCode(HttpStatus.OK)
  async processAvailable() {
    const count = await this.commissionsService.processAvailableCommissions();
    return {
      success: true,
      data: { processedCount: count },
      message: `${count} comissões processadas para liberação`,
    };
  }
}
