import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { WithdrawalsService } from './withdrawals.service';
import { WithdrawalsController } from './withdrawals.controller';
import { Withdrawal } from '../../entities/withdrawal.entity';
import { Affiliate } from '../../entities/affiliate.entity';
import { Commission } from '../../entities/commission.entity';
import { Log } from '../../entities/log.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Withdrawal, Affiliate, Commission, Log]),
  ],
  controllers: [WithdrawalsController],
  providers: [WithdrawalsService],
  exports: [WithdrawalsService],
})
export class WithdrawalsModule {}
