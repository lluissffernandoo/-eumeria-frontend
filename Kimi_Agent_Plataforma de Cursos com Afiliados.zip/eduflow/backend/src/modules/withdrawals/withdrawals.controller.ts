import {
  Controller,
  Get,
  Post,
  Param,
  Query,
  Body,
  UseGuards,
  Request,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { WithdrawalsService } from './withdrawals.service';
import { CreateWithdrawalDto } from './dto/create-withdrawal.dto';
import { WithdrawalQueryDto } from './dto/withdrawal-query.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../../entities/user.entity';

@Controller('withdrawals')
@UseGuards(JwtAuthGuard, RolesGuard)
export class WithdrawalsController {
  constructor(private readonly withdrawalsService: WithdrawalsService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  @Roles(UserRole.AFFILIATE)
  async create(@Body() createWithdrawalDto: CreateWithdrawalDto, @Request() req) {
    const withdrawal = await this.withdrawalsService.create(createWithdrawalDto, req.user);
    return {
      success: true,
      data: withdrawal,
      message: 'Solicitação de saque criada com sucesso',
    };
  }

  @Get()
  async findAll(@Query() query: WithdrawalQueryDto, @Request() req) {
    const result = await this.withdrawalsService.findAll(query, req.user);
    return {
      success: true,
      data: result.data,
      meta: {
        total: result.total,
        page: result.page,
        limit: result.limit,
        totalPages: Math.ceil(result.total / result.limit),
      },
    };
  }

  @Get('stats')
  async getStats(@Request() req) {
    const stats = await this.withdrawalsService.getStats(req.user);
    return {
      success: true,
      data: stats,
    };
  }

  @Get(':id')
  async findOne(@Param('id') id: string, @Request() req) {
    const withdrawal = await this.withdrawalsService.findOne(id, req.user);
    return {
      success: true,
      data: withdrawal,
    };
  }

  @Post(':id/approve')
  @Roles(UserRole.ADMIN)
  @HttpCode(HttpStatus.OK)
  async approve(
    @Param('id') id: string,
    @Body('notes') notes: string,
    @Request() req,
  ) {
    const withdrawal = await this.withdrawalsService.approve(id, req.user.id, notes);
    return {
      success: true,
      data: withdrawal,
      message: 'Saque aprovado com sucesso',
    };
  }

  @Post(':id/complete')
  @Roles(UserRole.ADMIN)
  @HttpCode(HttpStatus.OK)
  async complete(
    @Param('id') id: string,
    @Body('transactionId') transactionId: string,
    @Body('notes') notes: string,
    @Request() req,
  ) {
    const withdrawal = await this.withdrawalsService.complete(id, req.user.id, transactionId, notes);
    return {
      success: true,
      data: withdrawal,
      message: 'Saque completado com sucesso',
    };
  }

  @Post(':id/reject')
  @Roles(UserRole.ADMIN)
  @HttpCode(HttpStatus.OK)
  async reject(
    @Param('id') id: string,
    @Body('reason') reason: string,
    @Request() req,
  ) {
    const withdrawal = await this.withdrawalsService.reject(id, req.user.id, reason);
    return {
      success: true,
      data: withdrawal,
      message: 'Saque rejeitado',
    };
  }

  @Post(':id/cancel')
  @HttpCode(HttpStatus.OK)
  async cancel(@Param('id') id: string, @Request() req) {
    const withdrawal = await this.withdrawalsService.cancel(id, req.user);
    return {
      success: true,
      data: withdrawal,
      message: 'Saque cancelado com sucesso',
    };
  }
}
