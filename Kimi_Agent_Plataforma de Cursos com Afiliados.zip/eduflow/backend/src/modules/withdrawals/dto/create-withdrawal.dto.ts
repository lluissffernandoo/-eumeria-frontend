import {
  IsNumber,
  IsEnum,
  IsString,
  IsOptional,
  Min,
  Length,
  ValidateIf,
} from 'class-validator';
import { Type } from 'class-transformer';
import { WithdrawalMethod, AccountType, PixKeyType } from '../../entities/withdrawal.entity';

export class CreateWithdrawalDto {
  @IsNumber()
  @Min(50)
  @Type(() => Number)
  amount: number;

  @IsEnum(WithdrawalMethod)
  method: WithdrawalMethod;

  @IsString()
  @Length(2, 200)
  recipientName: string;

  @IsString()
  @Length(11, 14)
  recipientDocument: string;

  // Bank transfer fields
  @ValidateIf((o) => o.method === WithdrawalMethod.BANK_TRANSFER)
  @IsString()
  @Length(3, 10)
  bankCode?: string;

  @ValidateIf((o) => o.method === WithdrawalMethod.BANK_TRANSFER)
  @IsString()
  @Length(2, 100)
  bankName?: string;

  @ValidateIf((o) => o.method === WithdrawalMethod.BANK_TRANSFER)
  @IsString()
  @Length(4, 10)
  agency?: string;

  @ValidateIf((o) => o.method === WithdrawalMethod.BANK_TRANSFER)
  @IsString()
  @Length(5, 20)
  account?: string;

  @ValidateIf((o) => o.method === WithdrawalMethod.BANK_TRANSFER)
  @IsEnum(AccountType)
  accountType?: AccountType;

  // PIX fields
  @ValidateIf((o) => o.method === WithdrawalMethod.PIX)
  @IsString()
  @Length(1, 100)
  pixKey?: string;

  @ValidateIf((o) => o.method === WithdrawalMethod.PIX)
  @IsEnum(PixKeyType)
  pixKeyType?: PixKeyType;

  // PayPal/Payoneer fields
  @ValidateIf((o) => [WithdrawalMethod.PAYPAL, WithdrawalMethod.PAYONEER].includes(o.method))
  @IsString()
  @Length(5, 255)
  email?: string;

  @IsOptional()
  @IsString()
  @Length(0, 500)
  notes?: string;
}
