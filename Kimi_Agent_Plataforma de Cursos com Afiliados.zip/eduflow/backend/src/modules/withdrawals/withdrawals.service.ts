import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Brackets } from 'typeorm';
import {
  Withdrawal,
  WithdrawalStatus,
  WithdrawalMethod,
} from '../../entities/withdrawal.entity';
import { Affiliate } from '../../entities/affiliate.entity';
import { Commission, CommissionStatus } from '../../entities/commission.entity';
import { Log } from '../../entities/log.entity';
import { User, UserRole } from '../../entities/user.entity';
import { CreateWithdrawalDto } from './dto/create-withdrawal.dto';
import { WithdrawalQueryDto } from './dto/withdrawal-query.dto';

@Injectable()
export class WithdrawalsService {
  private readonly logger = new Logger(WithdrawalsService.name);
  private readonly MIN_WITHDRAWAL_AMOUNT = 50; // R$ 50,00

  constructor(
    @InjectRepository(Withdrawal)
    private withdrawalRepository: Repository<Withdrawal>,
    @InjectRepository(Affiliate)
    private affiliateRepository: Repository<Affiliate>,
    @InjectRepository(Commission)
    private commissionRepository: Repository<Commission>,
    @InjectRepository(Log)
    private logRepository: Repository<Log>,
  ) {}

  async create(createWithdrawalDto: CreateWithdrawalDto, user: User): Promise<Withdrawal> {
    // Get affiliate
    const affiliate = await this.affiliateRepository.findOne({
      where: { userId: user.id },
    });

    if (!affiliate) {
      throw new NotFoundException('Perfil de afiliado não encontrado');
    }

    // Validate minimum amount
    if (createWithdrawalDto.amount < this.MIN_WITHDRAWAL_AMOUNT) {
      throw new BadRequestException(`Valor mínimo para saque é R$ ${this.MIN_WITHDRAWAL_AMOUNT}`);
    }

    // Check available balance
    if (createWithdrawalDto.amount > affiliate.availableCommission) {
      throw new BadRequestException('Saldo disponível insuficiente');
    }

    // Get available commissions
    const availableCommissions = await this.commissionRepository.find({
      where: {
        affiliateId: affiliate.id,
        status: CommissionStatus.AVAILABLE,
      },
      order: { createdAt: 'ASC' },
    });

    // Calculate total available
    const totalAvailable = availableCommissions.reduce((sum, c) => sum + Number(c.amount), 0);

    if (createWithdrawalDto.amount > totalAvailable) {
      throw new BadRequestException('Saldo disponível insuficiente');
    }

    // Select commissions to withdraw
    let amountToWithdraw = createWithdrawalDto.amount;
    const selectedCommissions: Commission[] = [];

    for (const commission of availableCommissions) {
      if (amountToWithdraw <= 0) break;
      selectedCommissions.push(commission);
      amountToWithdraw -= Number(commission.amount);
    }

    // Calculate fee
    const fee = this.calculateFee(createWithdrawalDto.amount, createWithdrawalDto.method);
    const netAmount = createWithdrawalDto.amount - fee;

    // Create withdrawal
    const withdrawal = this.withdrawalRepository.create({
      amount: createWithdrawalDto.amount,
      fee,
      netAmount,
      currency: 'BRL',
      method: createWithdrawalDto.method,
      status: WithdrawalStatus.PENDING,
      recipientName: createWithdrawalDto.recipientName,
      recipientDocument: createWithdrawalDto.recipientDocument,
      bankCode: createWithdrawalDto.bankCode,
      bankName: createWithdrawalDto.bankName,
      agency: createWithdrawalDto.agency,
      account: createWithdrawalDto.account,
      accountType: createWithdrawalDto.accountType,
      pixKey: createWithdrawalDto.pixKey,
      pixKeyType: createWithdrawalDto.pixKeyType,
      notes: createWithdrawalDto.notes,
      affiliateId: affiliate.id,
      commissions: selectedCommissions,
    });

    const savedWithdrawal = await this.withdrawalRepository.save(withdrawal);

    // Update commissions
    for (const commission of selectedCommissions) {
      commission.withdraw(savedWithdrawal.id);
      await this.commissionRepository.save(commission);
    }

    // Update affiliate balance
    affiliate.availableCommission -= createWithdrawalDto.amount;
    affiliate.totalWithdrawn += createWithdrawalDto.amount;
    await this.affiliateRepository.save(affiliate);

    // Log withdrawal
    await this.logRepository.save({
      level: 'info',
      message: `Solicitação de saque criada: R$ ${createWithdrawalDto.amount}`,
      context: { withdrawalId: savedWithdrawal.id, affiliateId: affiliate.id },
      userId: user.id,
    });

    return savedWithdrawal;
  }

  async findAll(query: WithdrawalQueryDto, user: User): Promise<{ data: Withdrawal[]; total: number; page: number; limit: number }> {
    const { page = 1, limit = 20 } = query;
    const skip = (page - 1) * limit;

    const queryBuilder = this.withdrawalRepository.createQueryBuilder('withdrawal')
      .leftJoinAndSelect('withdrawal.affiliate', 'affiliate')
      .leftJoinAndSelect('withdrawal.commissions', 'commissions');

    // Apply role-based filtering
    if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (affiliate) {
        queryBuilder.where('withdrawal.affiliateId = :affiliateId', { affiliateId: affiliate.id });
      }
    }

    // Apply filters
    if (query.status) {
      queryBuilder.andWhere('withdrawal.status = :status', { status: query.status });
    }

    if (query.method) {
      queryBuilder.andWhere('withdrawal.method = :method', { method: query.method });
    }

    if (query.affiliateId && [UserRole.ADMIN].includes(user.role)) {
      queryBuilder.andWhere('withdrawal.affiliateId = :affiliateId', { affiliateId: query.affiliateId });
    }

    if (query.startDate) {
      queryBuilder.andWhere('withdrawal.createdAt >= :startDate', { startDate: query.startDate });
    }

    if (query.endDate) {
      queryBuilder.andWhere('withdrawal.createdAt <= :endDate', { endDate: query.endDate });
    }

    // Apply sorting
    const sortBy = query.sortBy || 'createdAt';
    const sortOrder = query.sortOrder || 'DESC';
    queryBuilder.orderBy(`withdrawal.${sortBy}`, sortOrder);

    // Apply pagination
    queryBuilder.skip(skip).take(limit);

    const [data, total] = await queryBuilder.getManyAndCount();

    return { data, total, page, limit };
  }

  async findOne(id: string, user: User): Promise<Withdrawal> {
    const withdrawal = await this.withdrawalRepository.findOne({
      where: { id },
      relations: ['affiliate', 'affiliate.user', 'commissions'],
    });

    if (!withdrawal) {
      throw new NotFoundException('Saque não encontrado');
    }

    // Check permissions
    if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (!affiliate || withdrawal.affiliateId !== affiliate.id) {
        throw new ForbiddenException('Você não tem permissão para ver este saque');
      }
    }

    return withdrawal;
  }

  async approve(id: string, adminId: string, notes?: string): Promise<Withdrawal> {
    const withdrawal = await this.withdrawalRepository.findOne({
      where: { id },
      relations: ['affiliate', 'commissions'],
    });

    if (!withdrawal) {
      throw new NotFoundException('Saque não encontrado');
    }

    if (withdrawal.status !== WithdrawalStatus.PENDING) {
      throw new BadRequestException('Este saque não pode ser aprovado');
    }

    withdrawal.status = WithdrawalStatus.APPROVED;
    withdrawal.approvedAt = new Date();
    withdrawal.approvedBy = adminId;
    withdrawal.notes = notes || withdrawal.notes;

    await this.withdrawalRepository.save(withdrawal);

    // Log approval
    await this.logRepository.save({
      level: 'info',
      message: `Saque aprovado: R$ ${withdrawal.amount}`,
      context: { withdrawalId: withdrawal.id, affiliateId: withdrawal.affiliateId },
      userId: adminId,
    });

    return withdrawal;
  }

  async complete(id: string, adminId: string, transactionId?: string, notes?: string): Promise<Withdrawal> {
    const withdrawal = await this.withdrawalRepository.findOne({
      where: { id },
      relations: ['affiliate'],
    });

    if (!withdrawal) {
      throw new NotFoundException('Saque não encontrado');
    }

    if (withdrawal.status !== WithdrawalStatus.APPROVED) {
      throw new BadRequestException('Este saque não pode ser completado');
    }

    withdrawal.status = WithdrawalStatus.COMPLETED;
    withdrawal.completedAt = new Date();
    withdrawal.processedBy = adminId;
    withdrawal.transactionId = transactionId || null;
    withdrawal.notes = notes || withdrawal.notes;

    await this.withdrawalRepository.save(withdrawal);

    // Update affiliate total paid
    const affiliate = withdrawal.affiliate;
    affiliate.totalPaid += withdrawal.netAmount;
    await this.affiliateRepository.save(affiliate);

    // Log completion
    await this.logRepository.save({
      level: 'info',
      message: `Saque completado: R$ ${withdrawal.amount}`,
      context: { withdrawalId: withdrawal.id, transactionId },
      userId: adminId,
    });

    return withdrawal;
  }

  async reject(id: string, adminId: string, reason: string): Promise<Withdrawal> {
    const withdrawal = await this.withdrawalRepository.findOne({
      where: { id },
      relations: ['affiliate', 'commissions'],
    });

    if (!withdrawal) {
      throw new NotFoundException('Saque não encontrado');
    }

    if (![WithdrawalStatus.PENDING, WithdrawalStatus.APPROVED].includes(withdrawal.status)) {
      throw new BadRequestException('Este saque não pode ser rejeitado');
    }

    withdrawal.status = WithdrawalStatus.REJECTED;
    withdrawal.rejectedAt = new Date();
    withdrawal.rejectedBy = adminId;
    withdrawal.rejectionReason = reason;

    await this.withdrawalRepository.save(withdrawal);

    // Restore commissions
    for (const commission of withdrawal.commissions) {
      commission.status = CommissionStatus.AVAILABLE;
      commission.withdrawalId = null;
      commission.withdrawnAt = null;
      await this.commissionRepository.save(commission);
    }

    // Restore affiliate balance
    const affiliate = withdrawal.affiliate;
    affiliate.availableCommission += withdrawal.amount;
    affiliate.totalWithdrawn -= withdrawal.amount;
    await this.affiliateRepository.save(affiliate);

    // Log rejection
    await this.logRepository.save({
      level: 'warn',
      message: `Saque rejeitado: R$ ${withdrawal.amount}`,
      context: { withdrawalId: withdrawal.id, reason },
      userId: adminId,
    });

    return withdrawal;
  }

  async cancel(id: string, user: User): Promise<Withdrawal> {
    const withdrawal = await this.withdrawalRepository.findOne({
      where: { id },
      relations: ['affiliate', 'commissions'],
    });

    if (!withdrawal) {
      throw new NotFoundException('Saque não encontrado');
    }

    // Check permissions
    if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (!affiliate || withdrawal.affiliateId !== affiliate.id) {
        throw new ForbiddenException('Você não tem permissão para cancelar este saque');
      }
    }

    if (withdrawal.status !== WithdrawalStatus.PENDING) {
      throw new BadRequestException('Apenas saques pendentes podem ser cancelados');
    }

    withdrawal.status = WithdrawalStatus.CANCELLED;
    withdrawal.cancelledAt = new Date();

    await this.withdrawalRepository.save(withdrawal);

    // Restore commissions
    for (const commission of withdrawal.commissions) {
      commission.status = CommissionStatus.AVAILABLE;
      commission.withdrawalId = null;
      commission.withdrawnAt = null;
      await this.commissionRepository.save(commission);
    }

    // Restore affiliate balance
    const affiliate = withdrawal.affiliate;
    affiliate.availableCommission += withdrawal.amount;
    affiliate.totalWithdrawn -= withdrawal.amount;
    await this.affiliateRepository.save(affiliate);

    // Log cancellation
    await this.logRepository.save({
      level: 'info',
      message: `Saque cancelado: R$ ${withdrawal.amount}`,
      context: { withdrawalId: withdrawal.id },
      userId: user.id,
    });

    return withdrawal;
  }

  async getStats(user: User): Promise<any> {
    const queryBuilder = this.withdrawalRepository.createQueryBuilder('withdrawal');

    // Apply role-based filtering
    if (user.role === UserRole.AFFILIATE) {
      const affiliate = await this.affiliateRepository.findOne({
        where: { userId: user.id },
      });
      if (affiliate) {
        queryBuilder.where('withdrawal.affiliateId = :affiliateId', { affiliateId: affiliate.id });
      }
    }

    const [
      totalWithdrawals,
      pendingWithdrawals,
      approvedWithdrawals,
      completedWithdrawals,
      rejectedWithdrawals,
      totalAmount,
      pendingAmount,
      completedAmount,
      rejectedAmount,
    ] = await Promise.all([
      queryBuilder.getCount(),
      queryBuilder.clone().andWhere('withdrawal.status = :status', { status: WithdrawalStatus.PENDING }).getCount(),
      queryBuilder.clone().andWhere('withdrawal.status = :status', { status: WithdrawalStatus.APPROVED }).getCount(),
      queryBuilder.clone().andWhere('withdrawal.status = :status', { status: WithdrawalStatus.COMPLETED }).getCount(),
      queryBuilder.clone().andWhere('withdrawal.status = :status', { status: WithdrawalStatus.REJECTED }).getCount(),
      queryBuilder.clone().select('COALESCE(SUM(withdrawal.amount), 0)', 'total').getRawOne(),
      queryBuilder.clone().select('COALESCE(SUM(withdrawal.amount), 0)', 'total').andWhere('withdrawal.status = :status', { status: WithdrawalStatus.PENDING }).getRawOne(),
      queryBuilder.clone().select('COALESCE(SUM(withdrawal.netAmount), 0)', 'total').andWhere('withdrawal.status = :status', { status: WithdrawalStatus.COMPLETED }).getRawOne(),
      queryBuilder.clone().select('COALESCE(SUM(withdrawal.amount), 0)', 'total').andWhere('withdrawal.status = :status', { status: WithdrawalStatus.REJECTED }).getRawOne(),
    ]);

    return {
      total: {
        count: totalWithdrawals,
        amount: Number(totalAmount?.total || 0),
      },
      pending: {
        count: pendingWithdrawals,
        amount: Number(pendingAmount?.total || 0),
      },
      approved: {
        count: approvedWithdrawals,
      },
      completed: {
        count: completedWithdrawals,
        amount: Number(completedAmount?.total || 0),
      },
      rejected: {
        count: rejectedWithdrawals,
        amount: Number(rejectedAmount?.total || 0),
      },
    };
  }

  private calculateFee(amount: number, method: WithdrawalMethod): number {
    const fees: Record<WithdrawalMethod, number> = {
      [WithdrawalMethod.BANK_TRANSFER]: 0, // Free
      [WithdrawalMethod.PIX]: 0, // Free
      [WithdrawalMethod.PAYPAL]: amount * 0.05, // 5%
      [WithdrawalMethod.PAYONEER]: amount * 0.02, // 2%
    };

    return fees[method] || 0;
  }
}
