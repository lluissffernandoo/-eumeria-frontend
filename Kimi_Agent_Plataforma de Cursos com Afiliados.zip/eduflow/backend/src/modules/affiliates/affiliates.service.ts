import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as crypto from 'crypto';
import { Affiliate, AffiliateStatus } from '../../entities/affiliate.entity';
import { AffiliateLink } from '../../entities/affiliate-link.entity';
import { User, UserRole } from '../../entities/user.entity';
import { Product } from '../../entities/product.entity';
import { Log, LogCategory } from '../../entities/log.entity';
import { RegisterAffiliateDto } from './dto/register-affiliate.dto';
import { CreateAffiliateLinkDto } from './dto/create-affiliate-link.dto';
import { UpdateAffiliateDto } from './dto/update-affiliate.dto';

@Injectable()
export class AffiliatesService {
  constructor(
    @InjectRepository(Affiliate)
    private readonly affiliateRepository: Repository<Affiliate>,
    @InjectRepository(AffiliateLink)
    private readonly affiliateLinkRepository: Repository<AffiliateLink>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
    @InjectRepository(Log)
    private readonly logRepository: Repository<Log>,
  ) {}

  async register(userId: string, registerDto: RegisterAffiliateDto): Promise<Affiliate> {
    // Check if user already has an affiliate account
    const existingAffiliate = await this.affiliateRepository.findOne({
      where: { userId },
    });

    if (existingAffiliate) {
      throw new BadRequestException('Você já possui uma conta de afiliado');
    }

    // Generate unique affiliate code
    const code = await this.generateUniqueCode();

    const affiliate = this.affiliateRepository.create({
      userId,
      code,
      status: AffiliateStatus.PENDING,
      bio: registerDto.bio,
      website: registerDto.website,
      socialMedia: registerDto.socialMedia,
      trafficSource: registerDto.trafficSource,
      marketingStrategy: registerDto.marketingStrategy,
    });

    await this.affiliateRepository.save(affiliate);

    // Update user role to affiliate if not already
    const user = await this.userRepository.findOne({ where: { id: userId } });
    if (user && user.role === UserRole.CUSTOMER) {
      user.role = UserRole.AFFILIATE;
      await this.userRepository.save(user);
    }

    await this.logRepository.save(
      Log.info(LogCategory.AFFILIATE, 'Affiliate registered', {
        affiliateId: affiliate.id,
        userId,
        code,
      }),
    );

    return affiliate;
  }

  async findByUserId(userId: string): Promise<Affiliate> {
    const affiliate = await this.affiliateRepository.findOne({
      where: { userId },
      relations: ['user', 'links'],
    });

    if (!affiliate) {
      throw new NotFoundException('Afiliado não encontrado');
    }

    return affiliate;
  }

  async findByCode(code: string): Promise<Affiliate> {
    const affiliate = await this.affiliateRepository.findOne({
      where: { code },
      relations: ['user'],
    });

    if (!affiliate) {
      throw new NotFoundException('Afiliado não encontrado');
    }

    return affiliate;
  }

  async getDashboard(userId: string): Promise<any> {
    const affiliate = await this.findByUserId(userId);

    const links = await this.affiliateLinkRepository.find({
      where: { affiliateId: affiliate.id },
    });

    return {
      affiliate,
      stats: {
        totalClicks: affiliate.totalClicks,
        totalConversions: affiliate.totalConversions,
        conversionRate: affiliate.conversionRate,
        totalCommission: affiliate.totalCommission,
        pendingCommission: affiliate.pendingCommission,
        availableCommission: affiliate.availableCommission,
        withdrawnCommission: affiliate.withdrawnCommission,
      },
      links,
    };
  }

  async createLink(
    userId: string,
    createLinkDto: CreateAffiliateLinkDto,
  ): Promise<AffiliateLink> {
    const affiliate = await this.findByUserId(userId);

    if (affiliate.status !== AffiliateStatus.APPROVED) {
      throw new ForbiddenException('Sua conta de afiliado ainda não foi aprovada');
    }

    // Verify product exists and allows affiliates
    if (createLinkDto.productId) {
      const product = await this.productRepository.findOne({
        where: { id: createLinkDto.productId },
      });

      if (!product) {
        throw new NotFoundException('Produto não encontrado');
      }

      if (!product.allowAffiliates) {
        throw new BadRequestException('Este produto não permite afiliados');
      }
    }

    // Generate unique link code
    const code = await this.generateUniqueLinkCode();

    const link = this.affiliateLinkRepository.create({
      affiliateId: affiliate.id,
      code,
      type: createLinkDto.type,
      productId: createLinkDto.productId,
      customUrl: createLinkDto.customUrl,
      title: createLinkDto.title,
      description: createLinkDto.description,
      utmSource: createLinkDto.utmSource,
      utmMedium: createLinkDto.utmMedium,
      utmCampaign: createLinkDto.utmCampaign,
      utmContent: createLinkDto.utmContent,
    });

    await this.affiliateLinkRepository.save(link);

    return link;
  }

  async getLinks(userId: string): Promise<AffiliateLink[]> {
    const affiliate = await this.findByUserId(userId);

    return this.affiliateLinkRepository.find({
      where: { affiliateId: affiliate.id },
      relations: ['product'],
      order: { createdAt: 'DESC' },
    });
  }

  async trackClick(code: string, ip: string, userAgent: string): Promise<AffiliateLink> {
    const link = await this.affiliateLinkRepository.findOne({
      where: { code },
      relations: ['affiliate'],
    });

    if (!link || !link.isActive) {
      throw new NotFoundException('Link não encontrado');
    }

    // Update link stats
    link.totalClicks++;
    link.lastClickedAt = new Date();
    await this.affiliateLinkRepository.save(link);

    // Update affiliate stats
    const affiliate = link.affiliate;
    affiliate.totalClicks++;
    await this.affiliateRepository.save(affiliate);

    await this.logRepository.save(
      Log.info(LogCategory.AFFILIATE, 'Affiliate link clicked', {
        linkId: link.id,
        affiliateId: affiliate.id,
        ip,
        userAgent,
      }),
    );

    return link;
  }

  // Admin methods
  async findAll(query: any): Promise<any> {
    const { page = 1, limit = 10, status } = query;

    const where: any = {};
    if (status) {
      where.status = status;
    }

    const [data, total] = await this.affiliateRepository.findAndCount({
      where,
      relations: ['user'],
      order: { createdAt: 'DESC' },
      skip: (page - 1) * limit,
      take: limit,
    });

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async approve(id: string, adminId: string): Promise<Affiliate> {
    const affiliate = await this.affiliateRepository.findOne({
      where: { id },
    });

    if (!affiliate) {
      throw new NotFoundException('Afiliado não encontrado');
    }

    affiliate.status = AffiliateStatus.APPROVED;
    affiliate.approvedAt = new Date();
    affiliate.approvedBy = adminId;

    await this.affiliateRepository.save(affiliate);

    await this.logRepository.save(
      Log.info(LogCategory.AFFILIATE, 'Affiliate approved', {
        affiliateId: affiliate.id,
        approvedBy: adminId,
      }),
    );

    return affiliate;
  }

  async reject(id: string, reason: string, adminId: string): Promise<Affiliate> {
    const affiliate = await this.affiliateRepository.findOne({
      where: { id },
    });

    if (!affiliate) {
      throw new NotFoundException('Afiliado não encontrado');
    }

    affiliate.status = AffiliateStatus.REJECTED;
    affiliate.rejectionReason = reason;

    await this.affiliateRepository.save(affiliate);

    await this.logRepository.save(
      Log.info(LogCategory.AFFILIATE, 'Affiliate rejected', {
        affiliateId: affiliate.id,
        rejectedBy: adminId,
        reason,
      }),
    );

    return affiliate;
  }

  async update(
    id: string,
    updateDto: UpdateAffiliateDto,
    adminId: string,
  ): Promise<Affiliate> {
    const affiliate = await this.affiliateRepository.findOne({
      where: { id },
    });

    if (!affiliate) {
      throw new NotFoundException('Afiliado não encontrado');
    }

    if (updateDto.customCommissionRate !== undefined) {
      affiliate.customCommissionRate = updateDto.customCommissionRate;
      affiliate.hasCustomCommission = true;
    }

    if (updateDto.tier !== undefined) {
      affiliate.tier = updateDto.tier;
    }

    await this.affiliateRepository.save(affiliate);

    return affiliate;
  }

  private async generateUniqueCode(): Promise<string> {
    let code: string;
    let exists = true;

    do {
      code = crypto.randomBytes(4).toString('hex').toUpperCase();
      const affiliate = await this.affiliateRepository.findOne({
        where: { code },
      });
      exists = !!affiliate;
    } while (exists);

    return code;
  }

  private async generateUniqueLinkCode(): Promise<string> {
    let code: string;
    let exists = true;

    do {
      code = crypto.randomBytes(6).toString('hex');
      const link = await this.affiliateLinkRepository.findOne({
        where: { code },
      });
      exists = !!link;
    } while (exists);

    return code;
  }
}
