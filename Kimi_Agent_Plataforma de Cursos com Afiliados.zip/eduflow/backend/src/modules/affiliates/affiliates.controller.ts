import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
  ParseUUIDPipe,
  Ip,
  Req,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { Request } from 'express';
import { AffiliatesService } from './affiliates.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { Public } from '../auth/decorators/public.decorator';
import { User, UserRole } from '../../entities/user.entity';
import { Affiliate } from '../../entities/affiliate.entity';
import { AffiliateLink } from '../../entities/affiliate-link.entity';
import { RegisterAffiliateDto, CreateAffiliateLinkDto, UpdateAffiliateDto } from './dto';

@ApiTags('Affiliates')
@Controller('affiliates')
export class AffiliatesController {
  constructor(private readonly affiliatesService: AffiliatesService) {}

  @Post('register')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Registrar como afiliado' })
  @ApiResponse({ status: 201, description: 'Afiliado registrado' })
  async register(
    @Body() registerDto: RegisterAffiliateDto,
    @CurrentUser() user: User,
  ): Promise<Affiliate> {
    return this.affiliatesService.register(user.id, registerDto);
  }

  @Get('me')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Dados do afiliado logado' })
  @ApiResponse({ status: 200, description: 'Dados retornados' })
  async getMe(@CurrentUser() user: User): Promise<Affiliate> {
    return this.affiliatesService.findByUserId(user.id);
  }

  @Get('dashboard')
  @UseGuards(JwtAuthGuard)
  @Roles(UserRole.AFFILIATE, UserRole.PRODUCER, UserRole.MASTER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Dashboard do afiliado' })
  @ApiResponse({ status: 200, description: 'Dashboard retornado' })
  async getDashboard(@CurrentUser() user: User): Promise<any> {
    return this.affiliatesService.getDashboard(user.id);
  }

  @Post('links')
  @UseGuards(JwtAuthGuard)
  @Roles(UserRole.AFFILIATE, UserRole.PRODUCER, UserRole.MASTER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Criar link de afiliado' })
  @ApiResponse({ status: 201, description: 'Link criado' })
  async createLink(
    @Body() createLinkDto: CreateAffiliateLinkDto,
    @CurrentUser() user: User,
  ): Promise<AffiliateLink> {
    return this.affiliatesService.createLink(user.id, createLinkDto);
  }

  @Get('links')
  @UseGuards(JwtAuthGuard)
  @Roles(UserRole.AFFILIATE, UserRole.PRODUCER, UserRole.MASTER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Listar links do afiliado' })
  @ApiResponse({ status: 200, description: 'Links retornados' })
  async getLinks(@CurrentUser() user: User): Promise<AffiliateLink[]> {
    return this.affiliatesService.getLinks(user.id);
  }

  @Get('track/:code')
  @Public()
  @ApiOperation({ summary: 'Rastrear clique em link' })
  @ApiResponse({ status: 200, description: 'Clique registrado' })
  async trackClick(
    @Param('code') code: string,
    @Ip() ip: string,
    @Req() req: Request,
  ): Promise<AffiliateLink> {
    return this.affiliatesService.trackClick(code, ip, req.headers['user-agent']);
  }

  // Admin routes
  @Get()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Listar todos os afiliados (admin)' })
  @ApiResponse({ status: 200, description: 'Lista retornada' })
  async findAll(@Query() query: any): Promise<any> {
    return this.affiliatesService.findAll(query);
  }

  @Post(':id/approve')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Aprovar afiliado' })
  @ApiResponse({ status: 200, description: 'Afiliado aprovado' })
  async approve(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() admin: User,
  ): Promise<Affiliate> {
    return this.affiliatesService.approve(id, admin.id);
  }

  @Post(':id/reject')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Rejeitar afiliado' })
  @ApiResponse({ status: 200, description: 'Afiliado rejeitado' })
  async reject(
    @Param('id', ParseUUIDPipe) id: string,
    @Body('reason') reason: string,
    @CurrentUser() admin: User,
  ): Promise<Affiliate> {
    return this.affiliatesService.reject(id, reason, admin.id);
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Atualizar afiliado' })
  @ApiResponse({ status: 200, description: 'Afiliado atualizado' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() updateDto: UpdateAffiliateDto,
    @CurrentUser() admin: User,
  ): Promise<Affiliate> {
    return this.affiliatesService.update(id, updateDto, admin.id);
  }
}
