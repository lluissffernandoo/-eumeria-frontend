import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AffiliatesController } from './affiliates.controller';
import { AffiliatesService } from './affiliates.service';
import { Affiliate } from '../../entities/affiliate.entity';
import { AffiliateLink } from '../../entities/affiliate-link.entity';
import { User } from '../../entities/user.entity';
import { Product } from '../../entities/product.entity';
import { Log } from '../../entities/log.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Affiliate, AffiliateLink, User, Product, Log]),
  ],
  controllers: [AffiliatesController],
  providers: [AffiliatesService],
  exports: [AffiliatesService],
})
export class AffiliatesModule {}
