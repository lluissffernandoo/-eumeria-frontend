import { IsNumber, IsOptional, IsEnum, Min, Max } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { AffiliateTier } from '../../../entities/affiliate.entity';

export class UpdateAffiliateDto {
  @ApiPropertyOptional({ example: 40, description: 'Taxa de comissão customizada' })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  customCommissionRate?: number;

  @ApiPropertyOptional({ enum: AffiliateTier, description: 'Tier do afiliado' })
  @IsOptional()
  @IsEnum(AffiliateTier)
  tier?: AffiliateTier;
}
