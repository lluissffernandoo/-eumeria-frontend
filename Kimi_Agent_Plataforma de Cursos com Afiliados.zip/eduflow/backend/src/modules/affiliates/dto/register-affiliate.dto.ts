import { IsString, IsOptional, IsUrl, IsArray } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class RegisterAffiliateDto {
  @ApiPropertyOptional({ example: 'Sou um afiliado experiente...', description: 'Biografia' })
  @IsOptional()
  @IsString()
  bio?: string;

  @ApiPropertyOptional({ example: 'https://meusite.com', description: 'Website' })
  @IsOptional()
  @IsUrl()
  website?: string;

  @ApiPropertyOptional({ example: ['https://instagram.com/user'], description: 'Redes sociais', type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  socialMedia?: string[];

  @ApiPropertyOptional({ example: 'Instagram, YouTube', description: 'Fonte de tráfego' })
  @IsOptional()
  @IsString()
  trafficSource?: string;

  @ApiPropertyOptional({ example: 'Estratégia de marketing...', description: 'Estratégia de marketing' })
  @IsOptional()
  @IsString()
  marketingStrategy?: string;
}
