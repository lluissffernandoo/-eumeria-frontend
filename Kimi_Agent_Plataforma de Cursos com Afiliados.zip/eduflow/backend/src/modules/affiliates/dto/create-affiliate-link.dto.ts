import { IsString, IsOptional, IsEnum, IsUUID } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { LinkType } from '../../../entities/affiliate-link.entity';

export class CreateAffiliateLinkDto {
  @ApiProperty({ enum: LinkType, default: LinkType.PRODUCT, description: 'Tipo do link' })
  @IsEnum(LinkType)
  type: LinkType;

  @ApiPropertyOptional({ example: 'uuid-do-produto', description: 'ID do produto' })
  @IsOptional()
  @IsUUID()
  productId?: string;

  @ApiPropertyOptional({ example: 'https://...', description: 'URL customizada' })
  @IsOptional()
  @IsString()
  customUrl?: string;

  @ApiPropertyOptional({ example: 'Meu Link', description: 'Título do link' })
  @IsOptional()
  @IsString()
  title?: string;

  @ApiPropertyOptional({ example: 'Descrição...', description: 'Descrição' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ example: 'instagram', description: 'UTM Source' })
  @IsOptional()
  @IsString()
  utmSource?: string;

  @ApiPropertyOptional({ example: 'social', description: 'UTM Medium' })
  @IsOptional()
  @IsString()
  utmMedium?: string;

  @ApiPropertyOptional({ example: 'promo-jan', description: 'UTM Campaign' })
  @IsOptional()
  @IsString()
  utmCampaign?: string;

  @ApiPropertyOptional({ example: 'banner-1', description: 'UTM Content' })
  @IsOptional()
  @IsString()
  utmContent?: string;
}
