import { Injectable, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

export interface UploadResult {
  filename: string;
  originalName: string;
  size: number;
  mimetype: string;
  url: string;
  path: string;
}

@Injectable()
export class UploadService {
  private readonly uploadDir: string;
  private readonly baseUrl: string;

  constructor(private readonly configService: ConfigService) {
    this.uploadDir = this.configService.get<string>('app.uploadDir', 'uploads');
    this.baseUrl = this.configService.get<string>('app.apiUrl', 'http://localhost:3001');
    this.ensureUploadDirExists();
  }

  private ensureUploadDirExists(): void {
    const dirs = ['images', 'videos', 'documents', 'temp'];
    dirs.forEach((dir) => {
      const fullPath = path.join(this.uploadDir, dir);
      if (!fs.existsSync(fullPath)) {
        fs.mkdirSync(fullPath, { recursive: true });
      }
    });
  }

  async uploadFile(
    file: Express.Multer.File,
    folder: 'images' | 'videos' | 'documents' | 'temp' = 'temp',
  ): Promise<UploadResult> {
    if (!file) {
      throw new BadRequestException('Nenhum arquivo enviado');
    }

    // Validate file size
    const maxFileSize = this.configService.get<number>('app.maxFileSize', 100 * 1024 * 1024);
    if (file.size > maxFileSize) {
      throw new BadRequestException(`Arquivo muito grande. Máximo: ${maxFileSize / 1024 / 1024}MB`);
    }

    // Generate unique filename
    const timestamp = Date.now();
    const random = crypto.randomBytes(8).toString('hex');
    const extension = path.extname(file.originalname);
    const filename = `${timestamp}-${random}${extension}`;

    // Determine subfolder based on mimetype
    const targetFolder = this.getFolderByMimetype(file.mimetype, folder);
    const targetPath = path.join(this.uploadDir, targetFolder);

    // Ensure directory exists
    if (!fs.existsSync(targetPath)) {
      fs.mkdirSync(targetPath, { recursive: true });
    }

    // Save file
    const filePath = path.join(targetPath, filename);
    fs.writeFileSync(filePath, file.buffer);

    // Generate URL
    const url = `${this.baseUrl}/uploads/${targetFolder}/${filename}`;

    return {
      filename,
      originalName: file.originalname,
      size: file.size,
      mimetype: file.mimetype,
      url,
      path: filePath,
    };
  }

  async uploadImage(file: Express.Multer.File): Promise<UploadResult> {
    // Validate image mimetype
    const allowedMimetypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedMimetypes.includes(file.mimetype)) {
      throw new BadRequestException('Tipo de arquivo não suportado. Use: JPG, PNG, GIF, WEBP');
    }

    return this.uploadFile(file, 'images');
  }

  async uploadVideo(file: Express.Multer.File): Promise<UploadResult> {
    // Validate video mimetype
    const allowedMimetypes = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'];
    if (!allowedMimetypes.includes(file.mimetype)) {
      throw new BadRequestException('Tipo de arquivo não suportado. Use: MP4, WEBM, OGG, MOV');
    }

    // Validate video size
    const maxVideoSize = this.configService.get<number>('app.maxVideoSize', 500 * 1024 * 1024);
    if (file.size > maxVideoSize) {
      throw new BadRequestException(`Vídeo muito grande. Máximo: ${maxVideoSize / 1024 / 1024}MB`);
    }

    return this.uploadFile(file, 'videos');
  }

  async uploadDocument(file: Express.Multer.File): Promise<UploadResult> {
    // Validate document mimetype
    const allowedMimetypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/plain',
    ];
    if (!allowedMimetypes.includes(file.mimetype)) {
      throw new BadRequestException('Tipo de arquivo não suportado. Use: PDF, DOC, DOCX, XLS, XLSX, TXT');
    }

    return this.uploadFile(file, 'documents');
  }

  async deleteFile(filePath: string): Promise<void> {
    try {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch (error) {
      console.error('Error deleting file:', error);
    }
  }

  private getFolderByMimetype(
    mimetype: string,
    defaultFolder: string,
  ): 'images' | 'videos' | 'documents' | 'temp' {
    if (mimetype.startsWith('image/')) return 'images';
    if (mimetype.startsWith('video/')) return 'videos';
    if (
      mimetype === 'application/pdf' ||
      mimetype.includes('word') ||
      mimetype.includes('excel') ||
      mimetype === 'text/plain'
    ) {
      return 'documents';
    }
    return defaultFolder;
  }
}
