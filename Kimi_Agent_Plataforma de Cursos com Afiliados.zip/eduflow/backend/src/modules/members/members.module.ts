import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MembersService } from './members.service';
import { MembersController } from './members.controller';
import { Enrollment } from '../../entities/enrollment.entity';
import { Course } from '../../entities/course.entity';
import { Module as CourseModule } from '../../entities/module.entity';
import { Lesson } from '../../entities/lesson.entity';
import { LessonProgress } from '../../entities/lesson-progress.entity';
import { Product } from '../../entities/product.entity';
import { Sale } from '../../entities/sale.entity';
import { Log } from '../../entities/log.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Enrollment,
      Course,
      CourseModule,
      Lesson,
      LessonProgress,
      Product,
      Sale,
      Log,
    ]),
  ],
  controllers: [MembersController],
  providers: [MembersService],
  exports: [MembersService],
})
export class MembersModule {}
