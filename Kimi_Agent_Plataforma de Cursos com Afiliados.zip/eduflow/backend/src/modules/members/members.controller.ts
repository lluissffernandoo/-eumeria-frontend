import {
  Controller,
  Get,
  Post,
  Patch,
  Param,
  Query,
  Body,
  UseGuards,
  Request,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { MembersService } from './members.service';
import { UpdateProgressDto } from './dto/update-progress.dto';
import { MemberQueryDto } from './dto/member-query.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../../entities/user.entity';

@Controller('members')
@UseGuards(JwtAuthGuard, RolesGuard)
export class MembersController {
  constructor(private readonly membersService: MembersService) {}

  // Student endpoints
  @Get('my-courses')
  async getMyCourses(@Request() req) {
    const courses = await this.membersService.getMyCourses(req.user);
    return {
      success: true,
      data: courses,
    };
  }

  @Get('my-courses/:courseId')
  async getCourseContent(@Param('courseId') courseId: string, @Request() req) {
    const content = await this.membersService.getCourseContent(courseId, req.user);
    return {
      success: true,
      data: content,
    };
  }

  @Get('lessons/:lessonId')
  async getLesson(@Param('lessonId') lessonId: string, @Request() req) {
    const lesson = await this.membersService.getLesson(lessonId, req.user);
    return {
      success: true,
      data: lesson,
    };
  }

  @Patch('lessons/:lessonId/progress')
  async updateProgress(
    @Param('lessonId') lessonId: string,
    @Body() updateProgressDto: UpdateProgressDto,
    @Request() req,
  ) {
    const progress = await this.membersService.updateProgress(
      lessonId,
      updateProgressDto,
      req.user,
    );
    return {
      success: true,
      data: progress,
      message: 'Progresso atualizado com sucesso',
    };
  }

  @Get('my-products')
  async getMyProducts(@Request() req) {
    const products = await this.membersService.getMyProducts(req.user);
    return {
      success: true,
      data: products,
    };
  }

  @Get('my-products/:productId/download')
  async getProductDownload(@Param('productId') productId: string, @Request() req) {
    const download = await this.membersService.getProductDownload(productId, req.user);
    return {
      success: true,
      data: download,
    };
  }

  @Get('stats')
  async getStats(@Request() req) {
    const stats = await this.membersService.getStats(req.user);
    return {
      success: true,
      data: stats,
    };
  }

  // Admin/Producer endpoints
  @Get()
  @Roles(UserRole.ADMIN, UserRole.PRODUCER)
  async findAll(@Query() query: MemberQueryDto, @Request() req) {
    const result = await this.membersService.findAll(query, req.user);
    return {
      success: true,
      data: result.data,
      meta: {
        total: result.total,
        page: result.page,
        limit: result.limit,
        totalPages: Math.ceil(result.total / result.limit),
      },
    };
  }

  @Post('enroll/:courseId/:userId')
  @Roles(UserRole.ADMIN, UserRole.PRODUCER)
  @HttpCode(HttpStatus.CREATED)
  async createEnrollment(
    @Param('courseId') courseId: string,
    @Param('userId') userId: string,
  ) {
    const enrollment = await this.membersService.createEnrollment(courseId, userId);
    return {
      success: true,
      data: enrollment,
      message: 'Matrícula criada com sucesso',
    };
  }
}
