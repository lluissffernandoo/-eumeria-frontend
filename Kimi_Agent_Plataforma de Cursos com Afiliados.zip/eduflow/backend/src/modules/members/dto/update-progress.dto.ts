import {
  IsOptional,
  IsNumber,
  IsBoolean,
  IsString,
  Min,
  Max,
} from 'class-validator';
import { Type } from 'class-transformer';

export class UpdateProgressDto {
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  watchTime?: number;

  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  @Type(() => Number)
  progressPercentage?: number;

  @IsOptional()
  @IsBoolean()
  @Type(() => Boolean)
  isCompleted?: boolean;

  @IsOptional()
  @IsString()
  notes?: string;
}
