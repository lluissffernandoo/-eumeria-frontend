import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Brackets } from 'typeorm';
import { Enrollment, EnrollmentStatus } from '../../entities/enrollment.entity';
import { Course } from '../../entities/course.entity';
import { Module as CourseModule } from '../../entities/module.entity';
import { Lesson, LessonType } from '../../entities/lesson.entity';
import { LessonProgress, ProgressStatus } from '../../entities/lesson-progress.entity';
import { Product } from '../../entities/product.entity';
import { Sale, SaleStatus } from '../../entities/sale.entity';
import { Log } from '../../entities/log.entity';
import { User, UserRole } from '../../entities/user.entity';
import { UpdateProgressDto } from './dto/update-progress.dto';
import { MemberQueryDto } from './dto/member-query.dto';

@Injectable()
export class MembersService {
  private readonly logger = new Logger(MembersService.name);

  constructor(
    @InjectRepository(Enrollment)
    private enrollmentRepository: Repository<Enrollment>,
    @InjectRepository(Course)
    private courseRepository: Repository<Course>,
    @InjectRepository(CourseModule)
    private moduleRepository: Repository<CourseModule>,
    @InjectRepository(Lesson)
    private lessonRepository: Repository<Lesson>,
    @InjectRepository(LessonProgress)
    private lessonProgressRepository: Repository<LessonProgress>,
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    @InjectRepository(Sale)
    private saleRepository: Repository<Sale>,
    @InjectRepository(Log)
    private logRepository: Repository<Log>,
  ) {}

  async getMyCourses(user: User): Promise<Enrollment[]> {
    const enrollments = await this.enrollmentRepository.find({
      where: { userId: user.id },
      relations: ['course', 'course.modules', 'course.modules.lessons'],
      order: { createdAt: 'DESC' },
    });

    return enrollments;
  }

  async getCourseContent(courseId: string, user: User): Promise<any> {
    // Check enrollment
    const enrollment = await this.enrollmentRepository.findOne({
      where: { courseId, userId: user.id },
      relations: ['course', 'course.modules', 'course.modules.lessons'],
    });

    if (!enrollment) {
      throw new ForbiddenException('Você não está matriculado neste curso');
    }

    if (enrollment.status !== EnrollmentStatus.ACTIVE) {
      throw new ForbiddenException('Sua matrícula não está ativa');
    }

    const course = enrollment.course;

    // Get progress for all lessons
    const lessonIds = course.modules.flatMap((m) => m.lessons.map((l) => l.id));
    const progress = await this.lessonProgressRepository.find({
      where: {
        userId: user.id,
        lessonId: lessonIds as any,
      },
    });

    const progressMap = new Map(progress.map((p) => [p.lessonId, p]));

    // Build course content with progress
    const modulesWithProgress = course.modules.map((module) => ({
      ...module,
      lessons: module.lessons.map((lesson) => ({
        ...lesson,
        progress: progressMap.get(lesson.id) || null,
      })),
    }));

    return {
      enrollment,
      course: {
        ...course,
        modules: modulesWithProgress,
      },
      overallProgress: enrollment.progressPercentage,
    };
  }

  async getLesson(lessonId: string, user: User): Promise<any> {
    const lesson = await this.lessonRepository.findOne({
      where: { id: lessonId },
      relations: ['module', 'module.course'],
    });

    if (!lesson) {
      throw new NotFoundException('Aula não encontrada');
    }

    // Check enrollment
    const enrollment = await this.enrollmentRepository.findOne({
      where: {
        courseId: lesson.module.courseId,
        userId: user.id,
      },
    });

    if (!enrollment) {
      throw new ForbiddenException('Você não está matriculado neste curso');
    }

    if (enrollment.status !== EnrollmentStatus.ACTIVE) {
      throw new ForbiddenException('Sua matrícula não está ativa');
    }

    // Get or create progress
    let progress = await this.lessonProgressRepository.findOne({
      where: { lessonId, userId: user.id },
    });

    if (!progress) {
      progress = this.lessonProgressRepository.create({
        lessonId,
        userId: user.id,
        status: ProgressStatus.IN_PROGRESS,
        startedAt: new Date(),
      });
      await this.lessonProgressRepository.save(progress);
    }

    // Get previous and next lessons
    const siblings = await this.lessonRepository.find({
      where: { moduleId: lesson.moduleId },
      order: { order: 'ASC' },
    });

    const currentIndex = siblings.findIndex((l) => l.id === lessonId);
    const previousLesson = siblings[currentIndex - 1] || null;
    const nextLesson = siblings[currentIndex + 1] || null;

    return {
      lesson,
      progress,
      previousLesson,
      nextLesson,
      module: lesson.module,
      course: lesson.module.course,
    };
  }

  async updateProgress(
    lessonId: string,
    updateProgressDto: UpdateProgressDto,
    user: User,
  ): Promise<LessonProgress> {
    const lesson = await this.lessonRepository.findOne({
      where: { id: lessonId },
      relations: ['module', 'module.course'],
    });

    if (!lesson) {
      throw new NotFoundException('Aula não encontrada');
    }

    // Check enrollment
    const enrollment = await this.enrollmentRepository.findOne({
      where: {
        courseId: lesson.module.courseId,
        userId: user.id,
      },
    });

    if (!enrollment) {
      throw new ForbiddenException('Você não está matriculado neste curso');
    }

    let progress = await this.lessonProgressRepository.findOne({
      where: { lessonId, userId: user.id },
    });

    if (!progress) {
      progress = this.lessonProgressRepository.create({
        lessonId,
        userId: user.id,
        startedAt: new Date(),
      });
    }

    // Update progress
    if (updateProgressDto.watchTime !== undefined) {
      progress.watchTime = updateProgressDto.watchTime;
    }

    if (updateProgressDto.progressPercentage !== undefined) {
      progress.progressPercentage = updateProgressDto.progressPercentage;
    }

    if (updateProgressDto.isCompleted) {
      progress.status = ProgressStatus.COMPLETED;
      progress.completedAt = new Date();

      // Update enrollment progress
      await this.updateEnrollmentProgress(enrollment);
    }

    if (updateProgressDto.notes) {
      progress.notes = updateProgressDto.notes;
    }

    await this.lessonProgressRepository.save(progress);

    return progress;
  }

  async getMyProducts(user: User): Promise<any[]> {
    const sales = await this.saleRepository.find({
      where: {
        customerId: user.id,
        status: SaleStatus.COMPLETED,
      },
      relations: ['product'],
      order: { createdAt: 'DESC' },
    });

    return sales.map((sale) => ({
      ...sale.product,
      purchaseDate: sale.createdAt,
      orderNumber: sale.orderNumber,
    }));
  }

  async getProductDownload(productId: string, user: User): Promise<any> {
    const sale = await this.saleRepository.findOne({
      where: {
        productId,
        customerId: user.id,
        status: SaleStatus.COMPLETED,
      },
      relations: ['product'],
    });

    if (!sale) {
      throw new ForbiddenException('Você não comprou este produto');
    }

    const product = sale.product;

    if (product.type !== 'digital') {
      throw new BadRequestException('Este produto não possui download');
    }

    // Increment download count
    product.downloadCount += 1;
    await this.productRepository.save(product);

    return {
      product,
      downloadUrl: product.fileUrl,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
    };
  }

  async getStats(user: User): Promise<any> {
    const enrollments = await this.enrollmentRepository.find({
      where: { userId: user.id },
    });

    const totalCourses = enrollments.length;
    const completedCourses = enrollments.filter((e) => e.isCompleted).length;
    const inProgressCourses = enrollments.filter((e) => e.isInProgress).length;

    const totalLessons = await this.lessonProgressRepository.count({
      where: { userId: user.id },
    });

    const completedLessons = await this.lessonProgressRepository.count({
      where: { userId: user.id, status: ProgressStatus.COMPLETED },
    });

    const totalWatchTime = enrollments.reduce((sum, e) => sum + e.totalWatchTime, 0);

    const products = await this.saleRepository.count({
      where: {
        customerId: user.id,
        status: SaleStatus.COMPLETED,
      },
    });

    return {
      courses: {
        total: totalCourses,
        completed: completedCourses,
        inProgress: inProgressCourses,
        completionRate: totalCourses > 0 ? (completedCourses / totalCourses) * 100 : 0,
      },
      lessons: {
        total: totalLessons,
        completed: completedLessons,
        completionRate: totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0,
      },
      totalWatchTime,
      products,
    };
  }

  async findAll(query: MemberQueryDto, user: User): Promise<{ data: Enrollment[]; total: number; page: number; limit: number }> {
    const { page = 1, limit = 20 } = query;
    const skip = (page - 1) * limit;

    const queryBuilder = this.enrollmentRepository.createQueryBuilder('enrollment')
      .leftJoinAndSelect('enrollment.course', 'course')
      .leftJoinAndSelect('enrollment.user', 'user');

    // Apply role-based filtering
    if (user.role === UserRole.PRODUCER) {
      queryBuilder.where('course.producerId = :producerId', { producerId: user.id });
    } else if (user.role === UserRole.CUSTOMER) {
      queryBuilder.where('enrollment.userId = :userId', { userId: user.id });
    }

    // Apply filters
    if (query.status) {
      queryBuilder.andWhere('enrollment.status = :status', { status: query.status });
    }

    if (query.courseId) {
      queryBuilder.andWhere('enrollment.courseId = :courseId', { courseId: query.courseId });
    }

    if (query.search) {
      queryBuilder.andWhere(
        new Brackets((qb) => {
          qb.where('user.name ILIKE :search', { search: `%${query.search}%` })
            .orWhere('user.email ILIKE :search', { search: `%${query.search}%` })
            .orWhere('course.name ILIKE :search', { search: `%${query.search}%` });
        }),
      );
    }

    // Apply sorting
    const sortBy = query.sortBy || 'createdAt';
    const sortOrder = query.sortOrder || 'DESC';
    queryBuilder.orderBy(`enrollment.${sortBy}`, sortOrder);

    // Apply pagination
    queryBuilder.skip(skip).take(limit);

    const [data, total] = await queryBuilder.getManyAndCount();

    return { data, total, page, limit };
  }

  async createEnrollment(courseId: string, userId: string, saleId?: string): Promise<Enrollment> {
    // Check if course exists
    const course = await this.courseRepository.findOne({
      where: { id: courseId },
    });

    if (!course) {
      throw new NotFoundException('Curso não encontrado');
    }

    // Check if enrollment already exists
    const existingEnrollment = await this.enrollmentRepository.findOne({
      where: { courseId, userId },
    });

    if (existingEnrollment) {
      return existingEnrollment;
    }

    const enrollment = this.enrollmentRepository.create({
      courseId,
      userId,
      saleId,
      status: EnrollmentStatus.ACTIVE,
      progressPercentage: 0,
      completedLessons: 0,
      totalLessons: course.lessonCount,
      totalWatchTime: 0,
      expiresAt: null, // No expiration by default
    });

    const savedEnrollment = await this.enrollmentRepository.save(enrollment);

    // Update course enrollments count
    course.enrollmentsCount += 1;
    await this.courseRepository.save(course);

    this.logger.log(`Matrícula criada: usuário ${userId} no curso ${courseId}`);

    return savedEnrollment;
  }

  private async updateEnrollmentProgress(enrollment: Enrollment): Promise<void> {
    const course = await this.courseRepository.findOne({
      where: { id: enrollment.courseId },
      relations: ['modules', 'modules.lessons'],
    });

    if (!course) return;

    const lessonIds = course.modules.flatMap((m) => m.lessons.map((l) => l.id));

    const completedLessons = await this.lessonProgressRepository.count({
      where: {
        userId: enrollment.userId,
        lessonId: lessonIds as any,
        status: ProgressStatus.COMPLETED,
      },
    });

    const totalWatchTime = await this.lessonProgressRepository
      .createQueryBuilder('progress')
      .select('COALESCE(SUM(progress.watchTime), 0)', 'total')
      .where('progress.userId = :userId', { userId: enrollment.userId })
      .andWhere('progress.lessonId IN (:...lessonIds)', { lessonIds })
      .getRawOne();

    enrollment.completedLessons = completedLessons;
    enrollment.totalLessons = lessonIds.length;
    enrollment.progressPercentage = lessonIds.length > 0
      ? Math.round((completedLessons / lessonIds.length) * 100)
      : 0;
    enrollment.totalWatchTime = Number(totalWatchTime?.total || 0);

    if (enrollment.progressPercentage === 100) {
      enrollment.status = EnrollmentStatus.COMPLETED;
      enrollment.completedAt = new Date();
    }

    await this.enrollmentRepository.save(enrollment);
  }
}
