import {
  Controller,
  Post,
  Get,
  Body,
  Headers,
  Req,
  Res,
  HttpCode,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { PaymentsService } from './payments.service';

@Controller('payments')
export class PaymentsController {
  private readonly logger = new Logger(PaymentsController.name);

  constructor(private readonly paymentsService: PaymentsService) {}

  @Post('webhooks/:provider')
  @HttpCode(HttpStatus.OK)
  async handleWebhook(
    @Req() req: Request,
    @Res() res: Response,
    @Headers('stripe-signature') stripeSignature?: string,
  ) {
    const provider = req.params.provider;
    const payload = req.body;

    this.logger.log(`Webhook recebido de ${provider}`);

    try {
      // Verify signature for Stripe
      if (provider === 'stripe' && stripeSignature) {
        const rawBody = JSON.stringify(payload);
        const isValid = await this.paymentsService.verifyWebhookSignature(
          provider,
          rawBody,
          stripeSignature,
        );

        if (!isValid) {
          this.logger.warn('Assinatura do webhook inválida');
          return res.status(400).json({ error: 'Invalid signature' });
        }
      }

      // Process webhook
      const result = await this.paymentsService.processWebhook(provider, payload);

      if (result) {
        this.logger.log(`Webhook processado com sucesso: ${result.saleId}`);
      }

      return res.status(200).json({ received: true });
    } catch (error) {
      this.logger.error('Erro ao processar webhook:', error);
      return res.status(400).json({ error: 'Webhook processing failed' });
    }
  }

  @Get('methods')
  async getPaymentMethods() {
    return {
      success: true,
      data: [
        {
          id: 'credit_card',
          name: 'Cartão de Crédito',
          icon: 'credit-card',
          installments: true,
          maxInstallments: 12,
        },
        {
          id: 'debit_card',
          name: 'Cartão de Débito',
          icon: 'credit-card',
          installments: false,
        },
        {
          id: 'pix',
          name: 'PIX',
          icon: 'pix',
          installments: false,
        },
        {
          id: 'boleto',
          name: 'Boleto Bancário',
          icon: 'barcode',
          installments: false,
        },
      ],
    };
  }
}
