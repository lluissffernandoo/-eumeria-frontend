import {
  IsNumber,
  IsString,
  IsOptional,
  IsObject,
  Min,
} from 'class-validator';
import { Type } from 'class-transformer';

export class CreatePaymentIntentDto {
  @IsNumber()
  @Min(0.01)
  @Type(() => Number)
  amount: number;

  @IsString()
  currency: string = 'BRL';

  @IsString()
  paymentMethod: string;

  @IsOptional()
  @IsNumber()
  @Min(1)
  @Type(() => Number)
  installments?: number;

  @IsString()
  customerEmail: string;

  @IsString()
  customerName: string;

  @IsOptional()
  @IsString()
  customerDocument?: string;

  @IsString()
  description: string;

  @IsOptional()
  @IsObject()
  metadata?: Record<string, any>;
}
