import {
  Injectable,
  Logger,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Stripe from 'stripe';
import { MercadoPagoConfig, Payment, Preference } from 'mercadopago';

interface PaymentIntentOptions {
  amount: number;
  currency: string;
  paymentMethod: string;
  installments?: number;
  customerEmail: string;
  customerName: string;
  customerDocument?: string;
  description: string;
  metadata?: Record<string, any>;
}

interface PaymentIntent {
  id: string;
  clientSecret?: string;
  paymentUrl?: string;
  status: string;
}

interface WebhookResult {
  saleId: string;
  paymentIntentId: string;
  status: string;
  transactionId?: string;
  rawData: any;
}

@Injectable()
export class PaymentsService {
  private readonly logger = new Logger(PaymentsService.name);
  private stripe: Stripe | null = null;
  private mpClient: MercadoPagoConfig | null = null;

  constructor(private configService: ConfigService) {
    // Initialize Stripe
    const stripeKey = this.configService.get<string>('STRIPE_SECRET_KEY');
    if (stripeKey) {
      this.stripe = new Stripe(stripeKey, {
        apiVersion: '2024-12-18.acacia',
      });
    }

    // Initialize Mercado Pago
    const mpAccessToken = this.configService.get<string>('MERCADO_PAGO_ACCESS_TOKEN');
    if (mpAccessToken) {
      this.mpClient = new MercadoPagoConfig({
        accessToken: mpAccessToken,
      });
    }
  }

  async createPaymentIntent(options: PaymentIntentOptions): Promise<PaymentIntent> {
    const provider = this.determineProvider(options.paymentMethod);

    switch (provider) {
      case 'stripe':
        return this.createStripePaymentIntent(options);
      case 'mercado_pago':
        return this.createMercadoPagoPreference(options);
      default:
        throw new BadRequestException('Método de pagamento não suportado');
    }
  }

  async createStripePaymentIntent(options: PaymentIntentOptions): Promise<PaymentIntent> {
    if (!this.stripe) {
      throw new BadRequestException('Stripe não configurado');
    }

    try {
      const amountInCents = Math.round(options.amount * 100);

      const paymentIntent = await this.stripe.paymentIntents.create({
        amount: amountInCents,
        currency: options.currency.toLowerCase(),
        payment_method_types: this.getStripePaymentMethods(options.paymentMethod),
        description: options.description,
        metadata: options.metadata,
        receipt_email: options.customerEmail,
      });

      return {
        id: paymentIntent.id,
        clientSecret: paymentIntent.client_secret,
        status: paymentIntent.status,
      };
    } catch (error) {
      this.logger.error('Erro ao criar PaymentIntent no Stripe:', error);
      throw new BadRequestException('Erro ao criar intenção de pagamento');
    }
  }

  async createMercadoPagoPreference(options: PaymentIntentOptions): Promise<PaymentIntent> {
    if (!this.mpClient) {
      throw new BadRequestException('Mercado Pago não configurado');
    }

    try {
      const preference = new Preference(this.mpClient);

      const result = await preference.create({
        body: {
          items: [
            {
              title: options.description,
              quantity: 1,
              unit_price: options.amount,
              currency_id: options.currency,
            },
          ],
          payer: {
            email: options.customerEmail,
            name: options.customerName,
            identification: options.customerDocument
              ? {
                  type: 'CPF',
                  number: options.customerDocument,
                }
              : undefined,
          },
          payment_methods: {
            installments: options.installments || 1,
          },
          external_reference: options.metadata?.saleId,
          notification_url: this.configService.get('MERCADO_PAGO_WEBHOOK_URL'),
          back_urls: {
            success: `${this.configService.get('FRONTEND_URL')}/checkout/success`,
            failure: `${this.configService.get('FRONTEND_URL')}/checkout/failure`,
            pending: `${this.configService.get('FRONTEND_URL')}/checkout/pending`,
          },
          auto_return: 'approved',
        },
      });

      return {
        id: result.id,
        paymentUrl: result.init_point,
        status: 'pending',
      };
    } catch (error) {
      this.logger.error('Erro ao criar preferência no Mercado Pago:', error);
      throw new BadRequestException('Erro ao criar preferência de pagamento');
    }
  }

  async refundPayment(paymentIntentId: string, amount?: number): Promise<void> {
    const provider = this.determineProviderById(paymentIntentId);

    switch (provider) {
      case 'stripe':
        return this.refundStripePayment(paymentIntentId, amount);
      case 'mercado_pago':
        return this.refundMercadoPagoPayment(paymentIntentId, amount);
      default:
        throw new BadRequestException('Provedor de pagamento não suportado');
    }
  }

  async refundStripePayment(paymentIntentId: string, amount?: number): Promise<void> {
    if (!this.stripe) {
      throw new BadRequestException('Stripe não configurado');
    }

    try {
      const refundData: Stripe.RefundCreateParams = {
        payment_intent: paymentIntentId,
      };

      if (amount) {
        refundData.amount = Math.round(amount * 100);
      }

      await this.stripe.refunds.create(refundData);
    } catch (error) {
      this.logger.error('Erro ao processar reembolso no Stripe:', error);
      throw new BadRequestException('Erro ao processar reembolso');
    }
  }

  async refundMercadoPagoPayment(paymentId: string, amount?: number): Promise<void> {
    if (!this.mpClient) {
      throw new BadRequestException('Mercado Pago não configurado');
    }

    try {
      const payment = new Payment(this.mpClient);
      await payment.refund({
        payment_id: paymentId,
        amount: amount ? String(amount) : undefined,
      });
    } catch (error) {
      this.logger.error('Erro ao processar reembolso no Mercado Pago:', error);
      throw new BadRequestException('Erro ao processar reembolso');
    }
  }

  async processWebhook(provider: string, payload: any): Promise<WebhookResult> {
    switch (provider.toLowerCase()) {
      case 'stripe':
        return this.processStripeWebhook(payload);
      case 'mercado_pago':
      case 'mercadopago':
        return this.processMercadoPagoWebhook(payload);
      default:
        throw new BadRequestException('Provedor de webhook não suportado');
    }
  }

  async processStripeWebhook(payload: any): Promise<WebhookResult> {
    const event = payload;

    this.logger.log(`Processando webhook do Stripe: ${event.type}`);

    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object;
        return {
          saleId: paymentIntent.metadata?.saleId,
          paymentIntentId: paymentIntent.id,
          status: 'paid',
          transactionId: paymentIntent.charges?.data[0]?.id,
          rawData: event,
        };

      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object;
        return {
          saleId: failedPayment.metadata?.saleId,
          paymentIntentId: failedPayment.id,
          status: 'failed',
          rawData: event,
        };

      case 'charge.refunded':
        const refund = event.data.object;
        return {
          saleId: refund.metadata?.saleId,
          paymentIntentId: refund.payment_intent,
          status: 'refunded',
          transactionId: refund.id,
          rawData: event,
        };

      default:
        this.logger.log(`Evento não tratado: ${event.type}`);
        return null;
    }
  }

  async processMercadoPagoWebhook(payload: any): Promise<WebhookResult> {
    this.logger.log('Processando webhook do Mercado Pago');

    const { data, type } = payload;

    if (type === 'payment' && data && data.id) {
      try {
        const payment = new Payment(this.mpClient);
        const paymentData = await payment.get({ id: data.id });

        const status = this.mapMercadoPagoStatus(paymentData.status);

        return {
          saleId: paymentData.external_reference,
          paymentIntentId: String(paymentData.id),
          status,
          transactionId: String(paymentData.id),
          rawData: paymentData,
        };
      } catch (error) {
        this.logger.error('Erro ao buscar dados do pagamento:', error);
        throw new BadRequestException('Erro ao processar webhook');
      }
    }

    return null;
  }

  async verifyWebhookSignature(
    provider: string,
    payload: string,
    signature: string,
  ): Promise<boolean> {
    switch (provider.toLowerCase()) {
      case 'stripe':
        return this.verifyStripeSignature(payload, signature);
      case 'mercado_pago':
      case 'mercadopago':
        // Mercado Pago doesn't use signature verification in the same way
        return true;
      default:
        return false;
    }
  }

  async verifyStripeSignature(payload: string, signature: string): Promise<boolean> {
    if (!this.stripe) {
      return false;
    }

    const webhookSecret = this.configService.get<string>('STRIPE_WEBHOOK_SECRET');
    if (!webhookSecret) {
      this.logger.warn('STRIPE_WEBHOOK_SECRET não configurado');
      return false;
    }

    try {
      this.stripe.webhooks.constructEvent(payload, signature, webhookSecret);
      return true;
    } catch (error) {
      this.logger.error('Erro ao verificar assinatura do Stripe:', error);
      return false;
    }
  }

  private determineProvider(paymentMethod: string): string {
    const mpMethods = ['pix', 'boleto'];
    
    if (mpMethods.includes(paymentMethod.toLowerCase())) {
      return 'mercado_pago';
    }
    
    return 'stripe';
  }

  private determineProviderById(paymentId: string): string {
    if (paymentId.startsWith('pi_')) {
      return 'stripe';
    }
    if (/^\d+$/.test(paymentId)) {
      return 'mercado_pago';
    }
    return 'stripe'; // default
  }

  private getStripePaymentMethods(paymentMethod: string): string[] {
    const methodMap: Record<string, string[]> = {
      credit_card: ['card'],
      debit_card: ['card'],
      pix: ['pix'],
      boleto: ['boleto'],
    };

    return methodMap[paymentMethod.toLowerCase()] || ['card'];
  }

  private mapMercadoPagoStatus(mpStatus: string): string {
    const statusMap: Record<string, string> = {
      approved: 'paid',
      pending: 'pending',
      in_process: 'processing',
      rejected: 'failed',
      cancelled: 'cancelled',
      refunded: 'refunded',
      charged_back: 'chargeback',
    };

    return statusMap[mpStatus] || 'pending';
  }
}
