import {
  Injectable,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between } from 'typeorm';
import { User, UserRole, UserStatus } from '../../entities/user.entity';
import { Product, ProductStatus } from '../../entities/product.entity';
import { Course } from '../../entities/course.entity';
import { Sale, SaleStatus, PaymentStatus } from '../../entities/sale.entity';
import { Commission, CommissionStatus } from '../../entities/commission.entity';
import { Affiliate, AffiliateStatus } from '../../entities/affiliate.entity';
import { Enrollment } from '../../entities/enrollment.entity';
import { Withdrawal, WithdrawalStatus } from '../../entities/withdrawal.entity';
import { Log } from '../../entities/log.entity';

@Injectable()
export class AdminService {
  private readonly logger = new Logger(AdminService.name);

  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
    @InjectRepository(Product)
    private productRepository: Repository<Product>,
    @InjectRepository(Course)
    private courseRepository: Repository<Course>,
    @InjectRepository(Sale)
    private saleRepository: Repository<Sale>,
    @InjectRepository(Commission)
    private commissionRepository: Repository<Commission>,
    @InjectRepository(Affiliate)
    private affiliateRepository: Repository<Affiliate>,
    @InjectRepository(Enrollment)
    private enrollmentRepository: Repository<Enrollment>,
    @InjectRepository(Withdrawal)
    private withdrawalRepository: Repository<Withdrawal>,
    @InjectRepository(Log)
    private logRepository: Repository<Log>,
  ) {}

  async getDashboardStats(): Promise<any> {
    const today = new Date();
    const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sevenDaysAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);

    // User stats
    const [
      totalUsers,
      newUsers30Days,
      newUsers7Days,
      activeUsers,
      inactiveUsers,
    ] = await Promise.all([
      this.userRepository.count(),
      this.userRepository.count({
        where: { createdAt: Between(thirtyDaysAgo, today) },
      }),
      this.userRepository.count({
        where: { createdAt: Between(sevenDaysAgo, today) },
      }),
      this.userRepository.count({ where: { status: UserStatus.ACTIVE } }),
      this.userRepository.count({ where: { status: UserStatus.INACTIVE } }),
    ]);

    // Product stats
    const [
      totalProducts,
      publishedProducts,
      draftProducts,
    ] = await Promise.all([
      this.productRepository.count(),
      this.productRepository.count({ where: { status: ProductStatus.PUBLISHED } }),
      this.productRepository.count({ where: { status: ProductStatus.DRAFT } }),
    ]);

    // Sales stats
    const [
      totalSales,
      sales30Days,
      sales7Days,
      totalRevenue,
      revenue30Days,
      revenue7Days,
    ] = await Promise.all([
      this.saleRepository.count(),
      this.saleRepository.count({
        where: { createdAt: Between(thirtyDaysAgo, today) },
      }),
      this.saleRepository.count({
        where: { createdAt: Between(sevenDaysAgo, today) },
      }),
      this.saleRepository
        .createQueryBuilder('sale')
        .select('COALESCE(SUM(sale.finalPrice), 0)', 'total')
        .where('sale.paymentStatus = :status', { status: PaymentStatus.PAID })
        .getRawOne(),
      this.saleRepository
        .createQueryBuilder('sale')
        .select('COALESCE(SUM(sale.finalPrice), 0)', 'total')
        .where('sale.paymentStatus = :status', { status: PaymentStatus.PAID })
        .andWhere('sale.createdAt BETWEEN :start AND :end', {
          start: thirtyDaysAgo,
          end: today,
        })
        .getRawOne(),
      this.saleRepository
        .createQueryBuilder('sale')
        .select('COALESCE(SUM(sale.finalPrice), 0)', 'total')
        .where('sale.paymentStatus = :status', { status: PaymentStatus.PAID })
        .andWhere('sale.createdAt BETWEEN :start AND :end', {
          start: sevenDaysAgo,
          end: today,
        })
        .getRawOne(),
    ]);

    // Affiliate stats
    const [
      totalAffiliates,
      pendingAffiliates,
      approvedAffiliates,
    ] = await Promise.all([
      this.affiliateRepository.count(),
      this.affiliateRepository.count({ where: { status: AffiliateStatus.PENDING } }),
      this.affiliateRepository.count({ where: { status: AffiliateStatus.APPROVED } }),
    ]);

    // Commission stats
    const [
      totalCommissions,
      pendingCommissions,
      availableCommissions,
    ] = await Promise.all([
      this.commissionRepository.count(),
      this.commissionRepository.count({ where: { status: CommissionStatus.PENDING } }),
      this.commissionRepository.count({ where: { status: CommissionStatus.AVAILABLE } }),
    ]);

    // Withdrawal stats
    const [
      totalWithdrawals,
      pendingWithdrawals,
      completedWithdrawals,
    ] = await Promise.all([
      this.withdrawalRepository.count(),
      this.withdrawalRepository.count({ where: { status: WithdrawalStatus.PENDING } }),
      this.withdrawalRepository.count({ where: { status: WithdrawalStatus.COMPLETED } }),
    ]);

    // Enrollment stats
    const [
      totalEnrollments,
      enrollments30Days,
    ] = await Promise.all([
      this.enrollmentRepository.count(),
      this.enrollmentRepository.count({
        where: { createdAt: Between(thirtyDaysAgo, today) },
      }),
    ]);

    return {
      users: {
        total: totalUsers,
        new30Days: newUsers30Days,
        new7Days: newUsers7Days,
        active: activeUsers,
        inactive: inactiveUsers,
      },
      products: {
        total: totalProducts,
        published: publishedProducts,
        draft: draftProducts,
      },
      sales: {
        total: totalSales,
        last30Days: sales30Days,
        last7Days: sales7Days,
        revenue: {
          total: Number(totalRevenue?.total || 0),
          last30Days: Number(revenue30Days?.total || 0),
          last7Days: Number(revenue7Days?.total || 0),
        },
      },
      affiliates: {
        total: totalAffiliates,
        pending: pendingAffiliates,
        approved: approvedAffiliates,
      },
      commissions: {
        total: totalCommissions,
        pending: pendingCommissions,
        available: availableCommissions,
      },
      withdrawals: {
        total: totalWithdrawals,
        pending: pendingWithdrawals,
        completed: completedWithdrawals,
      },
      enrollments: {
        total: totalEnrollments,
        last30Days: enrollments30Days,
      },
    };
  }

  async getSalesReport(period: { startDate: Date; endDate: Date }): Promise<any> {
    const sales = await this.saleRepository.find({
      where: {
        createdAt: Between(period.startDate, period.endDate),
        paymentStatus: PaymentStatus.PAID,
      },
      relations: ['product', 'affiliate'],
    });

    const totalRevenue = sales.reduce((sum, s) => sum + Number(s.finalPrice), 0);
    const totalPlatformFee = sales.reduce((sum, s) => sum + Number(s.platformFee), 0);
    const totalAffiliateCommission = sales.reduce((sum, s) => sum + Number(s.affiliateCommission), 0);
    const totalProducerRevenue = sales.reduce((sum, s) => sum + Number(s.producerRevenue), 0);

    // Sales by payment method
    const salesByMethod = sales.reduce((acc, sale) => {
      acc[sale.paymentMethod] = (acc[sale.paymentMethod] || 0) + Number(sale.finalPrice);
      return acc;
    }, {});

    // Sales by product
    const salesByProduct = sales.reduce((acc, sale) => {
      const productName = sale.product?.name || 'Unknown';
      if (!acc[productName]) {
        acc[productName] = { count: 0, revenue: 0 };
      }
      acc[productName].count += 1;
      acc[productName].revenue += Number(sale.finalPrice);
      return acc;
    }, {});

    // Daily sales
    const dailySales = sales.reduce((acc, sale) => {
      const date = sale.createdAt.toISOString().split('T')[0];
      if (!acc[date]) {
        acc[date] = { count: 0, revenue: 0 };
      }
      acc[date].count += 1;
      acc[date].revenue += Number(sale.finalPrice);
      return acc;
    }, {});

    return {
      period,
      summary: {
        totalSales: sales.length,
        totalRevenue,
        totalPlatformFee,
        totalAffiliateCommission,
        totalProducerRevenue,
      },
      salesByMethod,
      salesByProduct,
      dailySales,
    };
  }

  async getAffiliateReport(period: { startDate: Date; endDate: Date }): Promise<any> {
    const affiliates = await this.affiliateRepository.find({
      relations: ['user'],
    });

    const commissions = await this.commissionRepository.find({
      where: {
        createdAt: Between(period.startDate, period.endDate),
      },
    });

    const affiliateStats = affiliates.map((affiliate) => {
      const affiliateCommissions = commissions.filter(
        (c) => c.affiliateId === affiliate.id,
      );

      return {
        affiliate: {
          id: affiliate.id,
          code: affiliate.code,
          user: affiliate.user,
        },
        totalCommissions: affiliateCommissions.length,
        totalAmount: affiliateCommissions.reduce((sum, c) => sum + Number(c.amount), 0),
        pendingAmount: affiliateCommissions
          .filter((c) => c.status === CommissionStatus.PENDING)
          .reduce((sum, c) => sum + Number(c.amount), 0),
        availableAmount: affiliateCommissions
          .filter((c) => c.status === CommissionStatus.AVAILABLE)
          .reduce((sum, c) => sum + Number(c.amount), 0),
      };
    });

    return {
      period,
      totalAffiliates: affiliates.length,
      totalCommissions: commissions.length,
      totalAmount: commissions.reduce((sum, c) => sum + Number(c.amount), 0),
      affiliates: affiliateStats.sort((a, b) => b.totalAmount - a.totalAmount),
    };
  }

  async getRecentActivity(limit: number = 10): Promise<any> {
    const [recentSales, recentUsers, recentWithdrawals, recentLogs] = await Promise.all([
      this.saleRepository.find({
        relations: ['product', 'customer'],
        order: { createdAt: 'DESC' },
        take: limit,
      }),
      this.userRepository.find({
        order: { createdAt: 'DESC' },
        take: limit,
      }),
      this.withdrawalRepository.find({
        relations: ['affiliate', 'affiliate.user'],
        order: { createdAt: 'DESC' },
        take: limit,
      }),
      this.logRepository.find({
        order: { createdAt: 'DESC' },
        take: limit,
      }),
    ]);

    return {
      recentSales,
      recentUsers,
      recentWithdrawals,
      recentLogs,
    };
  }

  async getSystemHealth(): Promise<any> {
    // This would typically check various system metrics
    // For now, we'll return basic stats
    const [
      userCount,
      productCount,
      saleCount,
      errorLogs,
    ] = await Promise.all([
      this.userRepository.count(),
      this.productRepository.count(),
      this.saleRepository.count(),
      this.logRepository.count({ where: { level: 'error' } }),
    ]);

    return {
      status: 'healthy',
      timestamp: new Date(),
      database: {
        users: userCount,
        products: productCount,
        sales: saleCount,
      },
      errors: {
        total: errorLogs,
        last24Hours: 0, // Would need to filter by date
      },
    };
  }
}
