import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { User } from '../../entities/user.entity';
import { Product } from '../../entities/product.entity';
import { Course } from '../../entities/course.entity';
import { Sale } from '../../entities/sale.entity';
import { Commission } from '../../entities/commission.entity';
import { Affiliate } from '../../entities/affiliate.entity';
import { Enrollment } from '../../entities/enrollment.entity';
import { Withdrawal } from '../../entities/withdrawal.entity';
import { Log } from '../../entities/log.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      User,
      Product,
      Course,
      Sale,
      Commission,
      Affiliate,
      Enrollment,
      Withdrawal,
      Log,
    ]),
  ],
  controllers: [AdminController],
  providers: [AdminService],
  exports: [AdminService],
})
export class AdminModule {}
