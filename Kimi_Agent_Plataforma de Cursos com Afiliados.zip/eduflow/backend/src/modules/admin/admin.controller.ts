import {
  Controller,
  Get,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../../entities/user.entity';

@Controller('admin')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.ADMIN)
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('dashboard')
  async getDashboardStats() {
    const stats = await this.adminService.getDashboardStats();
    return {
      success: true,
      data: stats,
    };
  }

  @Get('reports/sales')
  async getSalesReport(
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    const report = await this.adminService.getSalesReport({
      startDate: new Date(startDate),
      endDate: new Date(endDate),
    });
    return {
      success: true,
      data: report,
    };
  }

  @Get('reports/affiliates')
  async getAffiliateReport(
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    const report = await this.adminService.getAffiliateReport({
      startDate: new Date(startDate),
      endDate: new Date(endDate),
    });
    return {
      success: true,
      data: report,
    };
  }

  @Get('activity')
  async getRecentActivity(@Query('limit') limit: string) {
    const activity = await this.adminService.getRecentActivity(
      limit ? parseInt(limit, 10) : 10,
    );
    return {
      success: true,
      data: activity,
    };
  }

  @Get('health')
  async getSystemHealth() {
    const health = await this.adminService.getSystemHealth();
    return {
      success: true,
      data: health,
    };
  }
}
