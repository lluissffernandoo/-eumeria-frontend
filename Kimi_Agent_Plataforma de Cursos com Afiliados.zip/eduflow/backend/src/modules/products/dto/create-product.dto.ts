import {
  IsString,
  IsNumber,
  IsOptional,
  IsEnum,
  IsUUID,
  Min,
  Max,
  MinLength,
  MaxLength,
  IsArray,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ProductStatus, ProductType } from '../../../entities/product.entity';

export class CreateProductDto {
  @ApiProperty({ example: 'Curso de React Completo', description: 'Nome do produto' })
  @IsString()
  @MinLength(3)
  @MaxLength(200)
  name: string;

  @ApiPropertyOptional({ example: 'Descrição detalhada do curso...', description: 'Descrição do produto' })
  @IsOptional()
  @IsString()
  @MaxLength(5000)
  description?: string;

  @ApiPropertyOptional({ example: 'Aprenda React do zero', description: 'Descrição curta' })
  @IsOptional()
  @IsString()
  @MaxLength(500)
  shortDescription?: string;

  @ApiPropertyOptional({ enum: ProductType, default: ProductType.DIGITAL })
  @IsOptional()
  @IsEnum(ProductType)
  type?: ProductType;

  @ApiPropertyOptional({ enum: ProductStatus, default: ProductStatus.DRAFT })
  @IsOptional()
  @IsEnum(ProductStatus)
  status?: ProductStatus;

  @ApiProperty({ example: 297.0, description: 'Preço do produto' })
  @IsNumber()
  @Min(0)
  price: number;

  @ApiPropertyOptional({ example: 497.0, description: 'Preço de comparação' })
  @IsOptional()
  @IsNumber()
  @Min(0)
  comparePrice?: number;

  @ApiPropertyOptional({ example: 'uuid-da-categoria', description: 'ID da categoria' })
  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @ApiPropertyOptional({ description: 'URL da imagem de capa' })
  @IsOptional()
  @IsString()
  coverImage?: string;

  @ApiPropertyOptional({ description: 'URLs das imagens da galeria', type: [String] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  galleryImages?: string[];

  @ApiPropertyOptional({ example: 30, description: 'Taxa de comissão para afiliados' })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  commissionRate?: number;

  @ApiPropertyOptional({ example: true, description: 'Permitir afiliados' })
  @IsOptional()
  allowAffiliates?: boolean;

  @ApiPropertyOptional({ example: 7, description: 'Dias de garantia' })
  @IsOptional()
  @IsNumber()
  @Min(0)
  guaranteeDays?: number;

  @ApiPropertyOptional({ example: 'Título para SEO', description: 'Meta title' })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  metaTitle?: string;

  @ApiPropertyOptional({ example: 'Descrição para SEO', description: 'Meta description' })
  @IsOptional()
  @IsString()
  @MaxLength(500)
  metaDescription?: string;
}
