import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like, In } from 'typeorm';
import { Product, ProductStatus } from '../../entities/product.entity';
import { Category } from '../../entities/category.entity';
import { User, UserRole } from '../../entities/user.entity';
import { Log, LogCategory } from '../../entities/log.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { QueryProductsDto } from './dto/query-products.dto';

export interface PaginatedProductsResponse {
  data: Product[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
}

@Injectable()
export class ProductsService {
  constructor(
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
    @InjectRepository(Category)
    private readonly categoryRepository: Repository<Category>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    @InjectRepository(Log)
    private readonly logRepository: Repository<Log>,
  ) {}

  async findAll(query: QueryProductsDto, user?: User): Promise<PaginatedProductsResponse> {
    const {
      page = 1,
      limit = 10,
      search,
      categoryId,
      status,
      minPrice,
      maxPrice,
      sortBy = 'createdAt',
      sortOrder = 'DESC',
      producerId,
      featured,
    } = query;

    const where: any = {};

    // Filter by status - customers only see published products
    if (!user || user.role === UserRole.CUSTOMER) {
      where.status = ProductStatus.PUBLISHED;
    } else if (status) {
      where.status = status;
    }

    if (categoryId) {
      where.categoryId = categoryId;
    }

    if (producerId) {
      where.producerId = producerId;
    }

    if (featured !== undefined) {
      where.isFeatured = featured;
    }

    if (minPrice !== undefined) {
      where.price = { ...where.price, $gte: minPrice };
    }

    if (maxPrice !== undefined) {
      where.price = { ...where.price, $lte: maxPrice };
    }

    if (search) {
      where.name = Like(`%${search}%`);
    }

    // Producers can only see their own products (unless admin)
    if (user?.role === UserRole.PRODUCER) {
      where.producerId = user.id;
    }

    const [data, total] = await this.productRepository.findAndCount({
      where,
      order: { [sortBy]: sortOrder },
      skip: (page - 1) * limit,
      take: limit,
      relations: ['producer', 'category'],
      select: {
        producer: {
          id: true,
          firstName: true,
          lastName: true,
          fullName: true,
          avatar: true,
        },
        category: {
          id: true,
          name: true,
          slug: true,
        },
      },
    });

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findById(id: string, user?: User): Promise<Product> {
    const product = await this.productRepository.findOne({
      where: { id },
      relations: ['producer', 'category'],
    });

    if (!product) {
      throw new NotFoundException('Produto não encontrado');
    }

    // Check visibility
    if (
      product.status !== ProductStatus.PUBLISHED &&
      (!user ||
        (user.role !== UserRole.MASTER &&
          user.id !== product.producerId))
    ) {
      throw new NotFoundException('Produto não encontrado');
    }

    // Increment view count
    if (!user || user.id !== product.producerId) {
      product.viewCount++;
      await this.productRepository.save(product);
    }

    return product;
  }

  async findBySlug(slug: string, user?: User): Promise<Product> {
    const product = await this.productRepository.findOne({
      where: { slug },
      relations: ['producer', 'category'],
    });

    if (!product) {
      throw new NotFoundException('Produto não encontrado');
    }

    // Check visibility
    if (
      product.status !== ProductStatus.PUBLISHED &&
      (!user ||
        (user.role !== UserRole.MASTER &&
          user.id !== product.producerId))
    ) {
      throw new NotFoundException('Produto não encontrado');
    }

    // Increment view count
    if (!user || user.id !== product.producerId) {
      product.viewCount++;
      await this.productRepository.save(product);
    }

    return product;
  }

  async create(createProductDto: CreateProductDto, user: User): Promise<Product> {
    // Verify category exists
    if (createProductDto.categoryId) {
      const category = await this.categoryRepository.findOne({
        where: { id: createProductDto.categoryId },
      });
      if (!category) {
        throw new NotFoundException('Categoria não encontrada');
      }
    }

    // Generate slug
    const slug = this.generateSlug(createProductDto.name);

    // Check if slug already exists
    const existingProduct = await this.productRepository.findOne({
      where: { slug },
    });
    if (existingProduct) {
      throw new BadRequestException('Já existe um produto com este nome');
    }

    const product = this.productRepository.create({
      ...createProductDto,
      slug,
      producerId: user.id,
      status: createProductDto.status || ProductStatus.DRAFT,
    });

    await this.productRepository.save(product);

    await this.logRepository.save(
      Log.info(LogCategory.PRODUCT, 'Product created', {
        productId: product.id,
        producerId: user.id,
        productName: product.name,
      }),
    );

    return product;
  }

  async update(
    id: string,
    updateProductDto: UpdateProductDto,
    user: User,
  ): Promise<Product> {
    const product = await this.findById(id, user);

    // Check permissions
    if (
      user.role !== UserRole.MASTER &&
      product.producerId !== user.id
    ) {
      throw new ForbiddenException(
        'Você não tem permissão para editar este produto',
      );
    }

    // Update fields
    if (updateProductDto.name && updateProductDto.name !== product.name) {
      product.name = updateProductDto.name;
      product.slug = this.generateSlug(updateProductDto.name);
    }

    if (updateProductDto.description !== undefined) {
      product.description = updateProductDto.description;
    }

    if (updateProductDto.shortDescription !== undefined) {
      product.shortDescription = updateProductDto.shortDescription;
    }

    if (updateProductDto.price !== undefined) {
      product.price = updateProductDto.price;
    }

    if (updateProductDto.comparePrice !== undefined) {
      product.comparePrice = updateProductDto.comparePrice;
    }

    if (updateProductDto.categoryId !== undefined) {
      product.categoryId = updateProductDto.categoryId;
    }

    if (updateProductDto.coverImage !== undefined) {
      product.coverImage = updateProductDto.coverImage;
    }

    if (updateProductDto.galleryImages !== undefined) {
      product.galleryImages = updateProductDto.galleryImages;
    }

    if (updateProductDto.commissionRate !== undefined) {
      product.commissionRate = updateProductDto.commissionRate;
    }

    if (updateProductDto.allowAffiliates !== undefined) {
      product.allowAffiliates = updateProductDto.allowAffiliates;
    }

    if (updateProductDto.guaranteeDays !== undefined) {
      product.guaranteeDays = updateProductDto.guaranteeDays;
    }

    if (updateProductDto.status !== undefined) {
      product.status = updateProductDto.status;
      if (updateProductDto.status === ProductStatus.PUBLISHED && !product.publishedAt) {
        product.publishedAt = new Date();
      }
    }

    if (updateProductDto.metaTitle !== undefined) {
      product.metaTitle = updateProductDto.metaTitle;
    }

    if (updateProductDto.metaDescription !== undefined) {
      product.metaDescription = updateProductDto.metaDescription;
    }

    await this.productRepository.save(product);

    await this.logRepository.save(
      Log.info(LogCategory.PRODUCT, 'Product updated', {
        productId: product.id,
        updatedBy: user.id,
        changes: Object.keys(updateProductDto),
      }),
    );

    return product;
  }

  async remove(id: string, user: User): Promise<void> {
    const product = await this.findById(id, user);

    // Check permissions
    if (
      user.role !== UserRole.MASTER &&
      product.producerId !== user.id
    ) {
      throw new ForbiddenException(
        'Você não tem permissão para excluir este produto',
      );
    }

    await this.productRepository.softRemove(product);

    await this.logRepository.save(
      Log.info(LogCategory.PRODUCT, 'Product deleted', {
        productId: product.id,
        deletedBy: user.id,
      }),
    );
  }

  async getFeatured(): Promise<Product[]> {
    return this.productRepository.find({
      where: {
        isFeatured: true,
        status: ProductStatus.PUBLISHED,
      },
      order: { sortOrder: 'ASC' },
      take: 10,
      relations: ['producer', 'category'],
    });
  }

  async getByProducer(producerId: string): Promise<Product[]> {
    return this.productRepository.find({
      where: {
        producerId,
        status: ProductStatus.PUBLISHED,
      },
      order: { createdAt: 'DESC' },
    });
  }

  async getStats(user?: User): Promise<any> {
    const where: any = {};

    if (user?.role === UserRole.PRODUCER) {
      where.producerId = user.id;
    }

    const [
      totalProducts,
      publishedProducts,
      draftProducts,
      pendingProducts,
      totalRevenue,
      totalSales,
    ] = await Promise.all([
      this.productRepository.count({ where }),
      this.productRepository.count({
        where: { ...where, status: ProductStatus.PUBLISHED },
      }),
      this.productRepository.count({
        where: { ...where, status: ProductStatus.DRAFT },
      }),
      this.productRepository.count({
        where: { ...where, status: ProductStatus.PENDING },
      }),
      this.productRepository
        .createQueryBuilder('product')
        .where(where)
        .select('SUM(product.totalRevenue)', 'total')
        .getRawOne()
        .then((result) => result?.total || 0),
      this.productRepository
        .createQueryBuilder('product')
        .where(where)
        .select('SUM(product.salesCount)', 'total')
        .getRawOne()
        .then((result) => result?.total || 0),
    ]);

    return {
      total: totalProducts,
      byStatus: {
        published: publishedProducts,
        draft: draftProducts,
        pending: pendingProducts,
      },
      totalRevenue: parseFloat(totalRevenue) || 0,
      totalSales: parseInt(totalSales) || 0,
    };
  }

  private generateSlug(name: string): string {
    return name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  }
}
