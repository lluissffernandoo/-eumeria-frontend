import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CoursesController } from './courses.controller';
import { CoursesService } from './courses.service';
import { Course } from '../../entities/course.entity';
import { Module as CourseModule } from '../../entities/module.entity';
import { Lesson } from '../../entities/lesson.entity';
import { Product } from '../../entities/product.entity';
import { Category } from '../../entities/category.entity';
import { Log } from '../../entities/log.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Course, CourseModule, Lesson, Product, Category, Log]),
  ],
  controllers: [CoursesController],
  providers: [CoursesService],
  exports: [CoursesService],
})
export class CoursesModule {}
