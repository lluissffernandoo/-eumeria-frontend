import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like } from 'typeorm';
import { Course, CourseStatus } from '../../entities/course.entity';
import { Module as CourseModule } from '../../entities/module.entity';
import { Lesson } from '../../entities/lesson.entity';
import { Product } from '../../entities/product.entity';
import { Category } from '../../entities/category.entity';
import { User, UserRole } from '../../entities/user.entity';
import { Log, LogCategory } from '../../entities/log.entity';
import { CreateCourseDto } from './dto/create-course.dto';
import { UpdateCourseDto } from './dto/update-course.dto';
import { CreateModuleDto } from './dto/create-module.dto';
import { CreateLessonDto } from './dto/create-lesson.dto';
import { QueryCoursesDto } from './dto/query-courses.dto';

@Injectable()
export class CoursesService {
  constructor(
    @InjectRepository(Course)
    private readonly courseRepository: Repository<Course>,
    @InjectRepository(CourseModule)
    private readonly moduleRepository: Repository<CourseModule>,
    @InjectRepository(Lesson)
    private readonly lessonRepository: Repository<Lesson>,
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
    @InjectRepository(Category)
    private readonly categoryRepository: Repository<Category>,
    @InjectRepository(Log)
    private readonly logRepository: Repository<Log>,
  ) {}

  async findAll(query: QueryCoursesDto, user?: User): Promise<any> {
    const {
      page = 1,
      limit = 10,
      search,
      categoryId,
      level,
      status,
      sortBy = 'createdAt',
      sortOrder = 'DESC',
    } = query;

    const where: any = {};

    // Filter by status - customers only see published courses
    if (!user || user.role === UserRole.CUSTOMER) {
      where.status = CourseStatus.PUBLISHED;
    } else if (status) {
      where.status = status;
    }

    if (categoryId) {
      where.categoryId = categoryId;
    }

    if (level) {
      where.level = level;
    }

    if (search) {
      where.title = Like(`%${search}%`);
    }

    const [data, total] = await this.courseRepository.findAndCount({
      where,
      order: { [sortBy]: sortOrder },
      skip: (page - 1) * limit,
      take: limit,
      relations: ['category'],
    });

    return {
      data,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async findById(id: string, user?: User): Promise<Course> {
    const course = await this.courseRepository.findOne({
      where: { id },
      relations: ['category', 'modules', 'modules.lessons'],
    });

    if (!course) {
      throw new NotFoundException('Curso não encontrado');
    }

    // Check visibility
    if (
      course.status !== CourseStatus.PUBLISHED &&
      (!user || user.role !== UserRole.MASTER)
    ) {
      throw new NotFoundException('Curso não encontrado');
    }

    return course;
  }

  async findBySlug(slug: string, user?: User): Promise<Course> {
    const course = await this.courseRepository.findOne({
      where: { slug },
      relations: ['category', 'modules', 'modules.lessons'],
    });

    if (!course) {
      throw new NotFoundException('Curso não encontrado');
    }

    // Check visibility
    if (
      course.status !== CourseStatus.PUBLISHED &&
      (!user || user.role !== UserRole.MASTER)
    ) {
      throw new NotFoundException('Curso não encontrado');
    }

    return course;
  }

  async create(createCourseDto: CreateCourseDto, user: User): Promise<Course> {
    // Verify category exists
    if (createCourseDto.categoryId) {
      const category = await this.categoryRepository.findOne({
        where: { id: createCourseDto.categoryId },
      });
      if (!category) {
        throw new NotFoundException('Categoria não encontrada');
      }
    }

    // Verify product exists if provided
    if (createCourseDto.productId) {
      const product = await this.productRepository.findOne({
        where: { id: createCourseDto.productId, producerId: user.id },
      });
      if (!product) {
        throw new NotFoundException('Produto não encontrado');
      }
    }

    // Generate slug
    const slug = this.generateSlug(createCourseDto.title);

    // Check if slug already exists
    const existingCourse = await this.courseRepository.findOne({
      where: { slug },
    });
    if (existingCourse) {
      throw new BadRequestException('Já existe um curso com este título');
    }

    const course = this.courseRepository.create({
      ...createCourseDto,
      slug,
      status: createCourseDto.status || CourseStatus.DRAFT,
    });

    await this.courseRepository.save(course);

    await this.logRepository.save(
      Log.info(LogCategory.PRODUCT, 'Course created', {
        courseId: course.id,
        createdBy: user.id,
        courseTitle: course.title,
      }),
    );

    return course;
  }

  async update(
    id: string,
    updateCourseDto: UpdateCourseDto,
    user: User,
  ): Promise<Course> {
    const course = await this.findById(id, user);

    // Update fields
    if (updateCourseDto.title && updateCourseDto.title !== course.title) {
      course.title = updateCourseDto.title;
      course.slug = this.generateSlug(updateCourseDto.title);
    }

    if (updateCourseDto.description !== undefined) {
      course.description = updateCourseDto.description;
    }

    if (updateCourseDto.categoryId !== undefined) {
      course.categoryId = updateCourseDto.categoryId;
    }

    if (updateCourseDto.coverImage !== undefined) {
      course.coverImage = updateCourseDto.coverImage;
    }

    if (updateCourseDto.status !== undefined) {
      course.status = updateCourseDto.status;
      if (updateCourseDto.status === CourseStatus.PUBLISHED && !course.publishedAt) {
        course.publishedAt = new Date();
      }
    }

    await this.courseRepository.save(course);

    await this.logRepository.save(
      Log.info(LogCategory.PRODUCT, 'Course updated', {
        courseId: course.id,
        updatedBy: user.id,
      }),
    );

    return course;
  }

  async remove(id: string, user: User): Promise<void> {
    const course = await this.findById(id, user);
    await this.courseRepository.softRemove(course);

    await this.logRepository.save(
      Log.info(LogCategory.PRODUCT, 'Course deleted', {
        courseId: course.id,
        deletedBy: user.id,
      }),
    );
  }

  // Modules
  async createModule(courseId: string, createModuleDto: CreateModuleDto, user: User): Promise<CourseModule> {
    const course = await this.findById(courseId, user);

    const module = this.moduleRepository.create({
      ...createModuleDto,
      courseId,
    });

    await this.moduleRepository.save(module);

    // Update course module count
    course.moduleCount = await this.moduleRepository.count({ where: { courseId } });
    await this.courseRepository.save(course);

    return module;
  }

  async updateModule(moduleId: string, updateData: Partial<CreateModuleDto>, user: User): Promise<CourseModule> {
    const module = await this.moduleRepository.findOne({
      where: { id: moduleId },
      relations: ['course'],
    });

    if (!module) {
      throw new NotFoundException('Módulo não encontrado');
    }

    Object.assign(module, updateData);
    await this.moduleRepository.save(module);

    return module;
  }

  async deleteModule(moduleId: string, user: User): Promise<void> {
    const module = await this.moduleRepository.findOne({
      where: { id: moduleId },
      relations: ['course'],
    });

    if (!module) {
      throw new NotFoundException('Módulo não encontrado');
    }

    await this.moduleRepository.softRemove(module);

    // Update course module count
    const course = module.course;
    course.moduleCount = await this.moduleRepository.count({ where: { courseId: course.id } });
    await this.courseRepository.save(course);
  }

  // Lessons
  async createLesson(moduleId: string, createLessonDto: CreateLessonDto, user: User): Promise<Lesson> {
    const module = await this.moduleRepository.findOne({
      where: { id: moduleId },
      relations: ['course'],
    });

    if (!module) {
      throw new NotFoundException('Módulo não encontrado');
    }

    const lesson = this.lessonRepository.create({
      ...createLessonDto,
      moduleId,
    });

    await this.lessonRepository.save(lesson);

    // Update module and course lesson counts
    module.lessonCount = await this.lessonRepository.count({ where: { moduleId } });
    await this.moduleRepository.save(module);

    const course = module.course;
    course.lessonCount = await this.lessonRepository.count({
      where: { module: { courseId: course.id } },
    });
    await this.courseRepository.save(course);

    return lesson;
  }

  async updateLesson(lessonId: string, updateData: Partial<CreateLessonDto>, user: User): Promise<Lesson> {
    const lesson = await this.lessonRepository.findOne({
      where: { id: lessonId },
    });

    if (!lesson) {
      throw new NotFoundException('Aula não encontrada');
    }

    Object.assign(lesson, updateData);
    await this.lessonRepository.save(lesson);

    return lesson;
  }

  async deleteLesson(lessonId: string, user: User): Promise<void> {
    const lesson = await this.lessonRepository.findOne({
      where: { id: lessonId },
      relations: ['module', 'module.course'],
    });

    if (!lesson) {
      throw new NotFoundException('Aula não encontrada');
    }

    await this.lessonRepository.softRemove(lesson);

    // Update counts
    const module = lesson.module;
    module.lessonCount = await this.lessonRepository.count({ where: { moduleId: module.id } });
    await this.moduleRepository.save(module);

    const course = module.course;
    course.lessonCount = await this.lessonRepository.count({
      where: { module: { courseId: course.id } },
    });
    await this.courseRepository.save(course);
  }

  private generateSlug(title: string): string {
    return title
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  }
}
