import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
  ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBearerAuth } from '@nestjs/swagger';
import { CoursesService } from './courses.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../auth/guards/roles.guard';
import { Roles } from '../auth/decorators/roles.decorator';
import { CurrentUser } from '../auth/decorators/current-user.decorator';
import { Public } from '../auth/decorators/public.decorator';
import { User, UserRole } from '../../entities/user.entity';
import { Course } from '../../entities/course.entity';
import { Module as CourseModule } from '../../entities/module.entity';
import { Lesson } from '../../entities/lesson.entity';
import {
  CreateCourseDto,
  UpdateCourseDto,
  CreateModuleDto,
  CreateLessonDto,
  QueryCoursesDto,
} from './dto';

@ApiTags('Courses')
@Controller('courses')
export class CoursesController {
  constructor(private readonly coursesService: CoursesService) {}

  @Get()
  @Public()
  @ApiOperation({ summary: 'Listar cursos' })
  @ApiResponse({ status: 200, description: 'Lista de cursos retornada' })
  async findAll(
    @Query() query: QueryCoursesDto,
    @CurrentUser() user?: User,
  ): Promise<any> {
    return this.coursesService.findAll(query, user);
  }

  @Get(':id')
  @Public()
  @ApiOperation({ summary: 'Obter curso por ID' })
  @ApiResponse({ status: 200, description: 'Curso encontrado' })
  @ApiResponse({ status: 404, description: 'Curso não encontrado' })
  async findById(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user?: User,
  ): Promise<Course> {
    return this.coursesService.findById(id, user);
  }

  @Get('slug/:slug')
  @Public()
  @ApiOperation({ summary: 'Obter curso por slug' })
  @ApiResponse({ status: 200, description: 'Curso encontrado' })
  async findBySlug(
    @Param('slug') slug: string,
    @CurrentUser() user?: User,
  ): Promise<Course> {
    return this.coursesService.findBySlug(slug, user);
  }

  @Post()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Criar curso' })
  @ApiResponse({ status: 201, description: 'Curso criado' })
  async create(
    @Body() createCourseDto: CreateCourseDto,
    @CurrentUser() user: User,
  ): Promise<Course> {
    return this.coursesService.create(createCourseDto, user);
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Atualizar curso' })
  @ApiResponse({ status: 200, description: 'Curso atualizado' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() updateCourseDto: UpdateCourseDto,
    @CurrentUser() user: User,
  ): Promise<Course> {
    return this.coursesService.update(id, updateCourseDto, user);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Excluir curso' })
  @ApiResponse({ status: 204, description: 'Curso excluído' })
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: User,
  ): Promise<void> {
    return this.coursesService.remove(id, user);
  }

  // Modules
  @Post(':id/modules')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Criar módulo' })
  async createModule(
    @Param('id', ParseUUIDPipe) courseId: string,
    @Body() createModuleDto: CreateModuleDto,
    @CurrentUser() user: User,
  ): Promise<CourseModule> {
    return this.coursesService.createModule(courseId, createModuleDto, user);
  }

  @Put('modules/:moduleId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Atualizar módulo' })
  async updateModule(
    @Param('moduleId', ParseUUIDPipe) moduleId: string,
    @Body() updateData: Partial<CreateModuleDto>,
    @CurrentUser() user: User,
  ): Promise<CourseModule> {
    return this.coursesService.updateModule(moduleId, updateData, user);
  }

  @Delete('modules/:moduleId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Excluir módulo' })
  async deleteModule(
    @Param('moduleId', ParseUUIDPipe) moduleId: string,
    @CurrentUser() user: User,
  ): Promise<void> {
    return this.coursesService.deleteModule(moduleId, user);
  }

  // Lessons
  @Post('modules/:moduleId/lessons')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Criar aula' })
  async createLesson(
    @Param('moduleId', ParseUUIDPipe) moduleId: string,
    @Body() createLessonDto: CreateLessonDto,
    @CurrentUser() user: User,
  ): Promise<Lesson> {
    return this.coursesService.createLesson(moduleId, createLessonDto, user);
  }

  @Put('lessons/:lessonId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Atualizar aula' })
  async updateLesson(
    @Param('lessonId', ParseUUIDPipe) lessonId: string,
    @Body() updateData: Partial<CreateLessonDto>,
    @CurrentUser() user: User,
  ): Promise<Lesson> {
    return this.coursesService.updateLesson(lessonId, updateData, user);
  }

  @Delete('lessons/:lessonId')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.MASTER, UserRole.PRODUCER)
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiBearerAuth('JWT-auth')
  @ApiOperation({ summary: 'Excluir aula' })
  async deleteLesson(
    @Param('lessonId', ParseUUIDPipe) lessonId: string,
    @CurrentUser() user: User,
  ): Promise<void> {
    return this.coursesService.deleteLesson(lessonId, user);
  }
}
