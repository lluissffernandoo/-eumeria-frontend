import {
  IsString,
  IsOptional,
  IsEnum,
  IsUUID,
  MinLength,
  MaxLength,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { CourseStatus, CourseLevel } from '../../../entities/course.entity';

export class CreateCourseDto {
  @ApiProperty({ example: 'Curso de React Completo', description: 'Título do curso' })
  @IsString()
  @MinLength(3)
  @MaxLength(200)
  title: string;

  @ApiPropertyOptional({ example: 'Descrição detalhada...', description: 'Descrição do curso' })
  @IsOptional()
  @IsString()
  @MaxLength(5000)
  description?: string;

  @ApiPropertyOptional({ example: 'Aprenda React do zero', description: 'Descrição curta' })
  @IsOptional()
  @IsString()
  @MaxLength(500)
  shortDescription?: string;

  @ApiPropertyOptional({ example: 'O que você vai aprender...', description: 'Conteúdo do curso' })
  @IsOptional()
  @IsString()
  whatYouWillLearn?: string;

  @ApiPropertyOptional({ example: 'Requisitos...', description: 'Requisitos do curso' })
  @IsOptional()
  @IsString()
  requirements?: string;

  @ApiPropertyOptional({ example: 'Público-alvo...', description: 'Para quem é o curso' })
  @IsOptional()
  @IsString()
  targetAudience?: string;

  @ApiPropertyOptional({ enum: CourseStatus, default: CourseStatus.DRAFT })
  @IsOptional()
  @IsEnum(CourseStatus)
  status?: CourseStatus;

  @ApiPropertyOptional({ enum: CourseLevel, default: CourseLevel.ALL_LEVELS })
  @IsOptional()
  @IsEnum(CourseLevel)
  level?: CourseLevel;

  @ApiPropertyOptional({ example: 'uuid-da-categoria', description: 'ID da categoria' })
  @IsOptional()
  @IsUUID()
  categoryId?: string;

  @ApiPropertyOptional({ example: 'uuid-do-produto', description: 'ID do produto associado' })
  @IsOptional()
  @IsUUID()
  productId?: string;

  @ApiPropertyOptional({ description: 'URL da imagem de capa' })
  @IsOptional()
  @IsString()
  coverImage?: string;

  @ApiPropertyOptional({ description: 'URL do vídeo trailer' })
  @IsOptional()
  @IsString()
  trailerVideo?: string;

  @ApiPropertyOptional({ example: true, description: 'Tem certificado' })
  @IsOptional()
  hasCertificate?: boolean;

  @ApiPropertyOptional({ example: true, description: 'Acesso vitalício' })
  @IsOptional()
  hasLifetimeAccess?: boolean;
}
