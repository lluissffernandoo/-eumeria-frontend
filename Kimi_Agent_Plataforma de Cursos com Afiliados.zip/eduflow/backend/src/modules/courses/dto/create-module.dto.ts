import { IsString, IsOptional, IsInt, Min, MaxLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateModuleDto {
  @ApiProperty({ example: 'Módulo 1: Introdução', description: 'Título do módulo' })
  @IsString()
  @MaxLength(200)
  title: string;

  @ApiPropertyOptional({ example: 'Descrição do módulo...', description: 'Descrição' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ example: 1, description: 'Ordem de exibição' })
  @IsOptional()
  @IsInt()
  @Min(0)
  sortOrder?: number;

  @ApiPropertyOptional({ example: true, description: 'Está publicado' })
  @IsOptional()
  isPublished?: boolean;

  @ApiPropertyOptional({ example: false, description: 'É gratuito' })
  @IsOptional()
  isFree?: boolean;
}
