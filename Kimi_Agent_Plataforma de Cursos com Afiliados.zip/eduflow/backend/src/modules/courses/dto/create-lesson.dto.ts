import { IsString, IsOptional, IsInt, Min, MaxLength, IsEnum, IsJSON } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { LessonType, VideoProvider } from '../../../entities/lesson.entity';

export class CreateLessonDto {
  @ApiProperty({ example: 'Aula 1: Introdução', description: 'Título da aula' })
  @IsString()
  @MaxLength(200)
  title: string;

  @ApiPropertyOptional({ example: 'Descrição da aula...', description: 'Descrição' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional({ enum: LessonType, default: LessonType.VIDEO })
  @IsOptional()
  @IsEnum(LessonType)
  type?: LessonType;

  @ApiPropertyOptional({ example: 1, description: 'Ordem de exibição' })
  @IsOptional()
  @IsInt()
  @Min(0)
  sortOrder?: number;

  @ApiPropertyOptional({ example: true, description: 'Está publicado' })
  @IsOptional()
  isPublished?: boolean;

  @ApiPropertyOptional({ example: false, description: 'É gratuito' })
  @IsOptional()
  isFree?: boolean;

  @ApiPropertyOptional({ enum: VideoProvider, default: VideoProvider.LOCAL })
  @IsOptional()
  @IsEnum(VideoProvider)
  videoProvider?: VideoProvider;

  @ApiPropertyOptional({ example: 'https://...', description: 'URL do vídeo' })
  @IsOptional()
  @IsString()
  videoUrl?: string;

  @ApiPropertyOptional({ description: 'Arquivo do vídeo' })
  @IsOptional()
  @IsString()
  videoFile?: string;

  @ApiPropertyOptional({ example: 600, description: 'Duração em segundos' })
  @IsOptional()
  @IsInt()
  @Min(0)
  duration?: number;

  @ApiPropertyOptional({ description: 'Conteúdo em texto' })
  @IsOptional()
  @IsString()
  content?: string;

  @ApiPropertyOptional({ example: true, description: 'Permitir comentários' })
  @IsOptional()
  allowComments?: boolean;

  @ApiPropertyOptional({ example: false, description: 'É preview' })
  @IsOptional()
  isPreview?: boolean;
}
