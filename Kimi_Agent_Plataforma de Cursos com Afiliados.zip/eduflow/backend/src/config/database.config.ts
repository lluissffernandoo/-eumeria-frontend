import { registerAs } from '@nestjs/config';

export const databaseConfig = registerAs('database', () => ({
  type: 'postgres',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT, 10) || 5432,
  username: process.env.DB_USERNAME || 'eumeria',
  password: process.env.DB_PASSWORD || 'eumeria123',
  database: process.env.DB_NAME || 'eumeria',
  
  // Connection pool
  poolSize: parseInt(process.env.DB_POOL_SIZE, 10) || 20,
  connectionTimeoutMillis: parseInt(process.env.DB_CONNECTION_TIMEOUT, 10) || 5000,
  idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT, 10) || 30000,
  
  // SSL
  ssl: process.env.DB_SSL === 'true',
  sslRejectUnauthorized: process.env.DB_SSL_REJECT_UNAUTHORIZED !== 'false',
  
  // Logging
  logging: process.env.DB_LOGGING === 'true',
  
  // Migrations
  migrationsRun: process.env.DB_MIGRATIONS_RUN === 'true',
  migrationsTableName: 'migrations',
}));
