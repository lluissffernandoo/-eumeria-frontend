import { registerAs } from '@nestjs/config';

export const emailConfig = registerAs('email', () => ({
  // SMTP Configuration
  smtp: {
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT, 10) || 587,
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER || '',
      pass: process.env.SMTP_PASS || '',
    },
    tls: {
      rejectUnauthorized: process.env.SMTP_TLS_REJECT_UNAUTHORIZED !== 'false',
    },
  },
  
  // From settings
  from: {
    name: process.env.EMAIL_FROM_NAME || 'Eumería',
    address: process.env.EMAIL_FROM_ADDRESS || 'noreply@eumeria.com.br',
  },
  
  // Reply to
  replyTo: process.env.EMAIL_REPLY_TO || 'suporte@eumeria.com.br',
  
  // Templates
  templates: {
    welcome: 'welcome',
    emailVerification: 'email-verification',
    passwordReset: 'password-reset',
    purchaseConfirmation: 'purchase-confirmation',
    courseAccess: 'course-access',
    commissionReceived: 'commission-received',
    withdrawalApproved: 'withdrawal-approved',
    withdrawalRequested: 'withdrawal-requested',
    affiliateApproved: 'affiliate-approved',
    productApproved: 'product-approved',
    newLesson: 'new-lesson',
    marketing: 'marketing',
  },
  
  // Sending limits
  rateLimit: parseInt(process.env.EMAIL_RATE_LIMIT, 10) || 100,
  rateLimitWindow: parseInt(process.env.EMAIL_RATE_LIMIT_WINDOW, 10) || 3600000, // 1 hour
}));
