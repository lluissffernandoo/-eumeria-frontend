import { registerAs } from '@nestjs/config';

export const redisConfig = registerAs('redis', () => ({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT, 10) || 6379,
  password: process.env.REDIS_PASSWORD || undefined,
  db: parseInt(process.env.REDIS_DB, 10) || 0,
  
  // Connection
  connectTimeout: parseInt(process.env.REDIS_CONNECT_TIMEOUT, 10) || 10000,
  maxRetriesPerRequest: parseInt(process.env.REDIS_MAX_RETRIES, 10) || 3,
  enableReadyCheck: true,
  enableOfflineQueue: true,
  
  // Key prefixes
  keyPrefix: {
    session: 'eumeria:session:',
    cache: 'eumeria:cache:',
    rateLimit: 'eumeria:ratelimit:',
    affiliate: 'eumeria:affiliate:',
    analytics: 'eumeria:analytics:',
    temp: 'eumeria:temp:',
  },
  
  // TTL
  defaultTTL: parseInt(process.env.REDIS_DEFAULT_TTL, 10) || 3600,
  sessionTTL: parseInt(process.env.REDIS_SESSION_TTL, 10) || 86400,
  cacheTTL: parseInt(process.env.REDIS_CACHE_TTL, 10) || 3600,
}));
