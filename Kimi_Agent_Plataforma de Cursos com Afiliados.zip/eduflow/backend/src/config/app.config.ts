import { registerAs } from '@nestjs/config';

export const appConfig = registerAs('app', () => ({
  nodeEnv: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT, 10) || 3001,
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:3000',
  apiUrl: process.env.API_URL || 'http://localhost:3001',
  
  // Security
  cookieSecret: process.env.COOKIE_SECRET || 'eumeria-secret-key',
  bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS, 10) || 12,
  
  // Upload
  maxFileSize: parseInt(process.env.MAX_FILE_SIZE, 10) || 100 * 1024 * 1024, // 100MB
  maxVideoSize: parseInt(process.env.MAX_VIDEO_SIZE, 10) || 500 * 1024 * 1024, // 500MB
  uploadDir: process.env.UPLOAD_DIR || 'uploads',
  
  // Affiliate tracking
  affiliateCookieName: process.env.AFFILIATE_COOKIE_NAME || 'eumeria_aff',
  affiliateCookieMaxAge: parseInt(process.env.AFFILIATE_COOKIE_MAX_AGE, 10) || 30 * 24 * 60 * 60 * 1000, // 30 days
  
  // Commission settings
  defaultPlatformFee: parseFloat(process.env.DEFAULT_PLATFORM_FEE) || 10, // 10%
  defaultCommissionRate: parseFloat(process.env.DEFAULT_COMMISSION_RATE) || 30, // 30%
  guaranteePeriod: parseInt(process.env.GUARANTEE_PERIOD, 10) || 7, // 7 days
  minWithdrawalAmount: parseFloat(process.env.MIN_WITHDRAWAL_AMOUNT) || 50, // R$ 50
  
  // Rate limiting
  throttleTtl: parseInt(process.env.THROTTLE_TTL, 10) || 60000,
  throttleLimit: parseInt(process.env.THROTTLE_LIMIT, 10) || 100,
  
  // Features
  enable2FA: process.env.ENABLE_2FA === 'true',
  enableEmailVerification: process.env.ENABLE_EMAIL_VERIFICATION !== 'false',
  enableRegistration: process.env.ENABLE_REGISTRATION !== 'false',
}));
