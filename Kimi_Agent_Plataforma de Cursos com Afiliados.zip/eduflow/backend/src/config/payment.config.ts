import { registerAs } from '@nestjs/config';

export const paymentConfig = registerAs('payment', () => ({
  // Stripe
  stripe: {
    secretKey: process.env.STRIPE_SECRET_KEY || '',
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || '',
    webhookSecret: process.env.STRIPE_WEBHOOK_SECRET || '',
    apiVersion: '2023-10-16',
    
    // Split payment settings
    applicationFeePercent: parseFloat(process.env.STRIPE_APPLICATION_FEE_PERCENT) || 10,
    transferGroupPrefix: 'eumeria_order_',
    
    // Payment methods
    paymentMethods: ['card', 'boleto', 'pix'],
    
    // Webhook events
    webhookEvents: [
      'payment_intent.succeeded',
      'payment_intent.payment_failed',
      'charge.refunded',
      'transfer.created',
      'transfer.failed',
      'account.updated',
    ],
  },
  
  // Mercado Pago
  mercadoPago: {
    accessToken: process.env.MP_ACCESS_TOKEN || '',
    publicKey: process.env.MP_PUBLIC_KEY || '',
    clientId: process.env.MP_CLIENT_ID || '',
    clientSecret: process.env.MP_CLIENT_SECRET || '',
    
    // Split payment (Marketplace)
    marketplaceFee: parseFloat(process.env.MP_MARKETPLACE_FEE) || 10,
    
    // Payment methods
    paymentMethods: ['credit_card', 'debit_card', 'ticket', 'bank_transfer', 'pix'],
    
    // Notification URL
    notificationUrl: process.env.MP_NOTIFICATION_URL || '',
  },
  
  // General settings
  currency: process.env.PAYMENT_CURRENCY || 'BRL',
  defaultPaymentGateway: process.env.DEFAULT_PAYMENT_GATEWAY || 'stripe', // 'stripe' or 'mercadopago'
  
  // Installments
  maxInstallments: parseInt(process.env.PAYMENT_MAX_INSTALLMENTS, 10) || 12,
  minInstallmentAmount: parseFloat(process.env.PAYMENT_MIN_INSTALLMENT_AMOUNT) || 10,
  
  // Retry settings
  maxRetries: parseInt(process.env.PAYMENT_MAX_RETRIES, 10) || 3,
  retryDelay: parseInt(process.env.PAYMENT_RETRY_DELAY, 10) || 5000,
}));
