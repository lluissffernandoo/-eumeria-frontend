import { registerAs } from '@nestjs/config';

export const jwtConfig = registerAs('jwt', () => ({
  // Access token
  accessTokenSecret: process.env.JWT_ACCESS_SECRET || 'eumeria-access-secret-key-change-in-production',
  accessTokenExpiration: process.env.JWT_ACCESS_EXPIRATION || '15m',
  
  // Refresh token
  refreshTokenSecret: process.env.JWT_REFRESH_SECRET || 'eumeria-refresh-secret-key-change-in-production',
  refreshTokenExpiration: process.env.JWT_REFRESH_EXPIRATION || '7d',
  
  // Token issuer and audience
  issuer: process.env.JWT_ISSUER || 'eumeria-api',
  audience: process.env.JWT_AUDIENCE || 'eumeria-client',
  
  // 2FA
  twoFactorSecret: process.env.JWT_2FA_SECRET || 'eumeria-2fa-secret',
  
  // Password reset
  passwordResetExpiration: parseInt(process.env.PASSWORD_RESET_EXPIRATION, 10) || 3600000, // 1 hour
  
  // Email verification
  emailVerificationExpiration: parseInt(process.env.EMAIL_VERIFICATION_EXPIRATION, 10) || 86400000, // 24 hours
}));
