import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Index,
} from 'typeorm';
import { Product } from './product.entity';
import { User } from './user.entity';
import { Sale } from './sale.entity';

export enum CouponType {
  PERCENTAGE = 'percentage',
  FIXED = 'fixed',
  FREE_SHIPPING = 'free_shipping',
  BUY_X_GET_Y = 'buy_x_get_y',
}

export enum CouponStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  EXPIRED = 'expired',
  DEPLETED = 'depleted',
  SCHEDULED = 'scheduled',
}

export enum CouponScope {
  GLOBAL = 'global',
  PRODUCT = 'product',
  CATEGORY = 'category',
  USER = 'user',
}

@Entity('coupons')
@Index(['code'], { unique: true })
@Index(['status'])
@Index(['type'])
@Index(['scope'])
@Index(['product'])
@Index(['startDate', 'endDate'])
export class Coupon {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 50, unique: true })
  code: string;

  @Column({ type: 'varchar', length: 100 })
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'enum', enum: CouponType, default: CouponType.PERCENTAGE })
  type: CouponType;

  @Column({ type: 'enum', enum: CouponStatus, default: CouponStatus.ACTIVE })
  status: CouponStatus;

  @Column({ type: 'enum', enum: CouponScope, default: CouponScope.GLOBAL })
  scope: CouponScope;

  // Discount values
  @Column({ type: 'decimal', precision: 5, scale: 2, nullable: true })
  discountPercentage: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  discountFixed: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  maxDiscountAmount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  minOrderAmount: number;

  // Usage limits
  @Column({ type: 'int', nullable: true })
  maxUses: number;

  @Column({ type: 'int', default: 0 })
  usedCount: number;

  @Column({ type: 'int', nullable: true })
  maxUsesPerUser: number;

  @Column({ type: 'int', nullable: true })
  maxUsesPerProduct: number;

  // Validity period
  @Column({ type: 'timestamp', nullable: true })
  startDate: Date;

  @Column({ type: 'timestamp', nullable: true })
  endDate: Date;

  // Applicable products (if scope is PRODUCT)
  @Column({ type: 'simple-array', nullable: true })
  applicableProductIds: string[];

  @Column({ type: 'simple-array', nullable: true })
  excludedProductIds: string[];

  // Applicable categories (if scope is CATEGORY)
  @Column({ type: 'simple-array', nullable: true })
  applicableCategoryIds: string[];

  // Applicable users (if scope is USER)
  @Column({ type: 'simple-array', nullable: true })
  applicableUserIds: string[];

  // First purchase only
  @Column({ type: 'boolean', default: false })
  firstPurchaseOnly: boolean;

  // Affiliate coupon
  @Column({ type: 'boolean', default: false })
  isAffiliateCoupon: boolean;

  @Column({ type: 'uuid', nullable: true })
  affiliateId: string;

  // Commission adjustment
  @Column({ type: 'decimal', precision: 5, scale: 2, nullable: true })
  affiliateCommissionOverride: number;

  // Statistics
  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  totalDiscountGiven: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  totalRevenue: number;

  // Metadata
  @Column({ type: 'simple-json', nullable: true })
  metadata: Record<string, any>;

  // Relationships
  @ManyToOne(() => Product, (product) => product.coupons, { nullable: true })
  @JoinColumn({ name: 'productId' })
  product: Product;

  @Column({ type: 'uuid', nullable: true })
  productId: string;

  @ManyToOne(() => User, (user) => user.id, { nullable: true })
  @JoinColumn({ name: 'createdBy' })
  createdByUser: User;

  @Column({ type: 'uuid', nullable: true })
  createdBy: string;

  @OneToMany(() => Sale, (sale) => sale.coupon)
  sales: Sale[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get isActive(): boolean {
    if (this.status !== CouponStatus.ACTIVE) return false;
    
    const now = new Date();
    if (this.startDate && now < this.startDate) return false;
    if (this.endDate && now > this.endDate) return false;
    if (this.maxUses && this.usedCount >= this.maxUses) return false;
    
    return true;
  }

  get isExpired(): boolean {
    if (this.endDate && new Date() > this.endDate) return true;
    if (this.maxUses && this.usedCount >= this.maxUses) return true;
    return false;
  }

  get isDepleted(): boolean {
    return this.maxUses !== null && this.usedCount >= this.maxUses;
  }

  calculateDiscount(amount: number): number {
    if (!this.isActive) return 0;

    let discount = 0;

    if (this.type === CouponType.PERCENTAGE) {
      discount = (amount * (this.discountPercentage || 0)) / 100;
    } else if (this.type === CouponType.FIXED) {
      discount = this.discountFixed || 0;
    }

    // Apply max discount limit
    if (this.maxDiscountAmount && discount > this.maxDiscountAmount) {
      discount = this.maxDiscountAmount;
    }

    // Don't discount more than the amount
    if (discount > amount) {
      discount = amount;
    }

    return Math.round(discount * 100) / 100;
  }

  canUse(userId?: string, productId?: string, userOrderCount: number = 0): boolean {
    if (!this.isActive) return false;

    // Check minimum order amount
    // if (this.minOrderAmount && orderAmount < this.minOrderAmount) return false;

    // Check first purchase only
    if (this.firstPurchaseOnly && userOrderCount > 0) return false;

    // Check applicable products
    if (this.applicableProductIds?.length > 0) {
      if (!productId || !this.applicableProductIds.includes(productId)) return false;
    }

    // Check excluded products
    if (this.excludedProductIds?.includes(productId)) return false;

    // Check applicable users
    if (this.applicableUserIds?.length > 0) {
      if (!userId || !this.applicableUserIds.includes(userId)) return false;
    }

    return true;
  }

  recordUse(): void {
    this.usedCount++;
    if (this.isDepleted) {
      this.status = CouponStatus.DEPLETED;
    }
  }

  updateStatus(): void {
    if (this.isDepleted) {
      this.status = CouponStatus.DEPLETED;
    } else if (this.isExpired) {
      this.status = CouponStatus.EXPIRED;
    }
  }
}
