import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { Affiliate } from './affiliate.entity';
import { Sale } from './sale.entity';
import { Product } from './product.entity';
import { User } from './user.entity';

export enum CommissionStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  AVAILABLE = 'available',
  WITHDRAWN = 'withdrawn',
  CANCELLED = 'cancelled',
  REFUNDED = 'refunded',
}

export enum CommissionType {
  AFFILIATE = 'affiliate',
  PRODUCER = 'producer',
  PLATFORM = 'platform',
  BONUS = 'bonus',
  TIER_UPGRADE = 'tier_upgrade',
}

@Entity('commissions')
@Index(['status'])
@Index(['type'])
@Index(['affiliate'])
@Index(['sale'])
@Index(['createdAt'])
@Index(['availableAt'])
export class Commission {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: CommissionType, default: CommissionType.AFFILIATE })
  type: CommissionType;

  @Column({ type: 'enum', enum: CommissionStatus, default: CommissionStatus.PENDING })
  status: CommissionStatus;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: number;

  @Column({ type: 'decimal', precision: 5, scale: 2 })
  rate: number;

  @Column({ type: 'varchar', length: 3, default: 'BRL' })
  currency: string;

  // Sale info
  @Column({ type: 'decimal', precision: 10, scale: 2 })
  saleAmount: number;

  @Column({ type: 'varchar', length: 50 })
  orderNumber: string;

  // Product info
  @Column({ type: 'varchar', length: 200 })
  productName: string;

  // Timelines
  @Column({ type: 'timestamp', nullable: true })
  approvedAt: Date;

  @Column({ type: 'uuid', nullable: true })
  approvedBy: string;

  @Column({ type: 'timestamp', nullable: true })
  availableAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  withdrawnAt: Date;

  @Column({ type: 'uuid', nullable: true })
  withdrawalId: string;

  @Column({ type: 'timestamp', nullable: true })
  cancelledAt: Date;

  @Column({ type: 'text', nullable: true })
  cancellationReason: string;

  @Column({ type: 'timestamp', nullable: true })
  refundedAt: Date;

  // Guarantee period
  @Column({ type: 'int', default: 7 })
  guaranteeDays: number;

  @Column({ type: 'timestamp', nullable: true })
  guaranteeExpiresAt: Date;

  @Column({ type: 'boolean', default: false })
  guaranteeClaimed: boolean;

  // Metadata
  @Column({ type: 'simple-json', nullable: true })
  metadata: Record<string, any>;

  @Column({ type: 'text', nullable: true })
  notes: string;

  // Relationships
  @ManyToOne(() => Affiliate, (affiliate) => affiliate.commissions, { nullable: true })
  @JoinColumn({ name: 'affiliateId' })
  affiliate: Affiliate;

  @Column({ type: 'uuid', nullable: true })
  affiliateId: string;

  @ManyToOne(() => User, (user) => user.id, { nullable: true })
  @JoinColumn({ name: 'producerId' })
  producer: User;

  @Column({ type: 'uuid', nullable: true })
  producerId: string;

  @ManyToOne(() => Sale, (sale) => sale.commissions)
  @JoinColumn({ name: 'saleId' })
  sale: Sale;

  @Column({ type: 'uuid' })
  saleId: string;

  @ManyToOne(() => Product, (product) => product.id, { nullable: true })
  @JoinColumn({ name: 'productId' })
  product: Product;

  @Column({ type: 'uuid', nullable: true })
  productId: string;

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get isPending(): boolean {
    return this.status === CommissionStatus.PENDING;
  }

  get isApproved(): boolean {
    return this.status === CommissionStatus.APPROVED;
  }

  get isAvailable(): boolean {
    return this.status === CommissionStatus.AVAILABLE;
  }

  get isWithdrawn(): boolean {
    return this.status === CommissionStatus.WITHDRAWN;
  }

  get isCancelled(): boolean {
    return this.status === CommissionStatus.CANCELLED;
  }

  get isRefunded(): boolean {
    return this.status === CommissionStatus.REFUNDED;
  }

  get isInGuaranteePeriod(): boolean {
    if (!this.guaranteeExpiresAt) return false;
    return new Date() < this.guaranteeExpiresAt;
  }

  canApprove(): boolean {
    return this.isPending && !this.isInGuaranteePeriod;
  }

  canMakeAvailable(): boolean {
    return this.isApproved && !this.isInGuaranteePeriod;
  }

  approve(adminId: string): void {
    this.status = CommissionStatus.APPROVED;
    this.approvedAt = new Date();
    this.approvedBy = adminId;
  }

  makeAvailable(): void {
    if (this.canMakeAvailable()) {
      this.status = CommissionStatus.AVAILABLE;
      this.availableAt = new Date();
    }
  }

  cancel(reason: string): void {
    this.status = CommissionStatus.CANCELLED;
    this.cancelledAt = new Date();
    this.cancellationReason = reason;
  }

  refund(): void {
    this.status = CommissionStatus.REFUNDED;
    this.refundedAt = new Date();
  }

  withdraw(withdrawalId: string): void {
    this.status = CommissionStatus.WITHDRAWN;
    this.withdrawnAt = new Date();
    this.withdrawalId = withdrawalId;
  }
}
