import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from './user.entity';
import { Affiliate } from './affiliate.entity';

export enum WithdrawalStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  COMPLETED = 'completed',
  FAILED = 'failed',
  CANCELLED = 'cancelled',
}

export enum WithdrawalMethod {
  BANK_TRANSFER = 'bank_transfer',
  PIX = 'pix',
  PAYPAL = 'paypal',
  STRIPE = 'stripe',
  MERCADO_PAGO = 'mercado_pago',
}

@Entity('withdrawals')
@Index(['status'])
@Index(['user'])
@Index(['affiliate'])
@Index(['createdAt'])
@Index(['processedAt'])
export class Withdrawal {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 50, unique: true })
  referenceNumber: string;

  @Column({ type: 'enum', enum: WithdrawalStatus, default: WithdrawalStatus.PENDING })
  status: WithdrawalStatus;

  @Column({ type: 'enum', enum: WithdrawalMethod })
  method: WithdrawalMethod;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  fee: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  netAmount: number;

  @Column({ type: 'varchar', length: 3, default: 'BRL' })
  currency: string;

  // Bank info (snapshot)
  @Column({ type: 'varchar', length: 100, nullable: true })
  bankName: string;

  @Column({ type: 'varchar', length: 10, nullable: true })
  bankCode: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  agency: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  accountNumber: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  accountType: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  pixKey: string;

  @Column({ type: 'varchar', length: 50, nullable: true })
  pixKeyType: string;

  // Processing info
  @Column({ type: 'timestamp', nullable: true })
  processedAt: Date;

  @Column({ type: 'uuid', nullable: true })
  processedBy: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  transactionId: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  receiptUrl: string;

  // Rejection info
  @Column({ type: 'text', nullable: true })
  rejectionReason: string;

  @Column({ type: 'timestamp', nullable: true })
  rejectedAt: Date;

  // Failure info
  @Column({ type: 'text', nullable: true })
  failureReason: string;

  @Column({ type: 'timestamp', nullable: true })
  failedAt: Date;

  // Commission IDs (JSON array)
  @Column({ type: 'simple-json' })
  commissionIds: string[];

  @Column({ type: 'int' })
  commissionCount: number;

  // Notes
  @Column({ type: 'text', nullable: true })
  notes: string;

  @Column({ type: 'text', nullable: true })
  adminNotes: string;

  // Relationships
  @ManyToOne(() => User, (user) => user.withdrawals)
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column({ type: 'uuid' })
  userId: string;

  @ManyToOne(() => Affiliate, (affiliate) => affiliate.id, { nullable: true })
  @JoinColumn({ name: 'affiliateId' })
  affiliate: Affiliate;

  @Column({ type: 'uuid', nullable: true })
  affiliateId: string;

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get isPending(): boolean {
    return this.status === WithdrawalStatus.PENDING;
  }

  get isProcessing(): boolean {
    return this.status === WithdrawalStatus.PROCESSING;
  }

  get isApproved(): boolean {
    return this.status === WithdrawalStatus.APPROVED;
  }

  get isCompleted(): boolean {
    return this.status === WithdrawalStatus.COMPLETED;
  }

  get isRejected(): boolean {
    return this.status === WithdrawalStatus.REJECTED;
  }

  get isFailed(): boolean {
    return this.status === WithdrawalStatus.FAILED;
  }

  canCancel(): boolean {
    return this.isPending || this.isProcessing;
  }

  process(adminId: string): void {
    this.status = WithdrawalStatus.PROCESSING;
    this.processedAt = new Date();
    this.processedBy = adminId;
  }

  complete(transactionId: string, receiptUrl?: string): void {
    this.status = WithdrawalStatus.COMPLETED;
    this.transactionId = transactionId;
    if (receiptUrl) {
      this.receiptUrl = receiptUrl;
    }
  }

  reject(reason: string): void {
    this.status = WithdrawalStatus.REJECTED;
    this.rejectionReason = reason;
    this.rejectedAt = new Date();
  }

  fail(reason: string): void {
    this.status = WithdrawalStatus.FAILED;
    this.failureReason = reason;
    this.failedAt = new Date();
  }

  cancel(): void {
    if (this.canCancel()) {
      this.status = WithdrawalStatus.CANCELLED;
    }
  }
}
