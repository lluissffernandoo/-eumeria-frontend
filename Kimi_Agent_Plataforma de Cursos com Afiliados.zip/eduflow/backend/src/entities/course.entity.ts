import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Index,
} from 'typeorm';
import { Product } from './product.entity';
import { Category } from './category.entity';
import { Module } from './module.entity';
import { Enrollment } from './enrollment.entity';

export enum CourseLevel {
  BEGINNER = 'beginner',
  INTERMEDIATE = 'intermediate',
  ADVANCED = 'advanced',
  ALL_LEVELS = 'all_levels',
}

export enum CourseStatus {
  DRAFT = 'draft',
  PENDING = 'pending',
  APPROVED = 'approved',
  PUBLISHED = 'published',
  UNPUBLISHED = 'unpublished',
}

@Entity('courses')
@Index(['slug'], { unique: true })
@Index(['status'])
@Index(['level'])
@Index(['category'])
export class Course {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 200 })
  title: string;

  @Column({ type: 'varchar', length: 200, unique: true })
  slug: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'text', nullable: true })
  shortDescription: string;

  @Column({ type: 'text', nullable: true })
  whatYouWillLearn: string;

  @Column({ type: 'text', nullable: true })
  requirements: string;

  @Column({ type: 'text', nullable: true })
  targetAudience: string;

  @Column({ type: 'enum', enum: CourseStatus, default: CourseStatus.DRAFT })
  status: CourseStatus;

  @Column({ type: 'enum', enum: CourseLevel, default: CourseLevel.ALL_LEVELS })
  level: CourseLevel;

  @Column({ type: 'varchar', length: 3, default: 'BRL' })
  currency: string;

  // Media
  @Column({ type: 'varchar', length: 255, nullable: true })
  coverImage: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  trailerVideo: string;

  // Associated product (for sales)
  @Column({ type: 'uuid', nullable: true })
  productId: string;

  @ManyToOne(() => Product, (product) => product.id, { nullable: true })
  @JoinColumn({ name: 'productId' })
  product: Product;

  // Category
  @ManyToOne(() => Category, (category) => category.courses, { nullable: true })
  @JoinColumn({ name: 'categoryId' })
  category: Category;

  @Column({ type: 'uuid', nullable: true })
  categoryId: string;

  // Duration and content
  @Column({ type: 'int', default: 0 })
  totalDuration: number; // minutes

  @Column({ type: 'int', default: 0 })
  lessonCount: number;

  @Column({ type: 'int', default: 0 })
  moduleCount: number;

  // Settings
  @Column({ type: 'boolean', default: true })
  hasCertificate: boolean;

  @Column({ type: 'boolean', default: true })
  hasLifetimeAccess: boolean;

  @Column({ type: 'int', nullable: true })
  accessDuration: number; // days

  @Column({ type: 'boolean', default: true })
  allowDownload: boolean;

  @Column({ type: 'boolean', default: true })
  allowDiscussion: boolean;

  // Pricing (if different from product)
  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  price: number;

  // SEO
  @Column({ type: 'varchar', length: 255, nullable: true })
  metaTitle: string;

  @Column({ type: 'text', nullable: true })
  metaDescription: string;

  @Column({ type: 'varchar', length: 500, nullable: true })
  metaKeywords: string;

  // Statistics
  @Column({ type: 'int', default: 0 })
  enrollmentCount: number;

  @Column({ type: 'int', default: 0 })
  completionCount: number;

  @Column({ type: 'decimal', precision: 3, scale: 2, nullable: true })
  averageRating: number;

  @Column({ type: 'int', default: 0 })
  reviewCount: number;

  // Relationships
  @OneToMany(() => Module, (module) => module.course, { cascade: true })
  modules: Module[];

  @OneToMany(() => Enrollment, (enrollment) => enrollment.course)
  enrollments: Enrollment[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  publishedAt: Date;

  // Methods
  get completionRate(): number {
    if (this.enrollmentCount === 0) return 0;
    return Math.round((this.completionCount / this.enrollmentCount) * 100);
  }
}
