import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  OneToMany,
  OneToOne,
  ManyToMany,
  JoinTable,
  Index,
} from 'typeorm';
import { Product } from './product.entity';
import { Affiliate } from './affiliate.entity';
import { Sale } from './sale.entity';
import { Enrollment } from './enrollment.entity';
import { Review } from './review.entity';
import { Withdrawal } from './withdrawal.entity';

export enum UserRole {
  MASTER = 'master',
  PRODUCER = 'producer',
  AFFILIATE = 'affiliate',
  CUSTOMER = 'customer',
}

export enum UserStatus {
  ACTIVE = 'active',
  INACTIVE = 'inactive',
  PENDING = 'pending',
  BLOCKED = 'blocked',
  SUSPENDED = 'suspended',
}

export enum DocumentType {
  CPF = 'cpf',
  CNPJ = 'cnpj',
}

@Entity('users')
@Index(['email'], { unique: true })
@Index(['document'], { unique: true })
@Index(['role'])
@Index(['status'])
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 100 })
  firstName: string;

  @Column({ type: 'varchar', length: 100 })
  lastName: string;

  @Column({ type: 'varchar', length: 200 })
  fullName: string;

  @Column({ type: 'varchar', length: 255, unique: true })
  email: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  password: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  phone: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  avatar: string;

  @Column({ type: 'enum', enum: DocumentType, nullable: true })
  documentType: DocumentType;

  @Column({ type: 'varchar', length: 20, nullable: true, unique: true })
  document: string;

  @Column({ type: 'date', nullable: true })
  birthDate: Date;

  @Column({ type: 'enum', enum: UserRole, default: UserRole.CUSTOMER })
  role: UserRole;

  @Column({ type: 'enum', enum: UserStatus, default: UserStatus.PENDING })
  status: UserStatus;

  @Column({ type: 'boolean', default: false })
  emailVerified: boolean;

  @Column({ type: 'varchar', length: 255, nullable: true })
  emailVerificationToken: string;

  @Column({ type: 'timestamp', nullable: true })
  emailVerificationExpires: Date;

  @Column({ type: 'varchar', length: 255, nullable: true })
  passwordResetToken: string;

  @Column({ type: 'timestamp', nullable: true })
  passwordResetExpires: Date;

  // 2FA
  @Column({ type: 'boolean', default: false })
  twoFactorEnabled: boolean;

  @Column({ type: 'varchar', length: 255, nullable: true })
  twoFactorSecret: string;

  @Column({ type: 'boolean', default: false })
  twoFactorVerified: boolean;

  // Address
  @Column({ type: 'varchar', length: 255, nullable: true })
  address: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  addressNumber: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  complement: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  neighborhood: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  city: string;

  @Column({ type: 'varchar', length: 2, nullable: true })
  state: string;

  @Column({ type: 'varchar', length: 10, nullable: true })
  zipCode: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  country: string;

  // Bank account (for withdrawals)
  @Column({ type: 'varchar', length: 100, nullable: true })
  bankName: string;

  @Column({ type: 'varchar', length: 10, nullable: true })
  bankCode: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  agency: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  accountNumber: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  accountType: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  pixKey: string;

  // Stripe/MercadoPago account
  @Column({ type: 'varchar', length: 255, nullable: true })
  stripeAccountId: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  mercadoPagoAccountId: string;

  // Social login
  @Column({ type: 'varchar', length: 255, nullable: true })
  googleId: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  facebookId: string;

  // Notifications
  @Column({ type: 'boolean', default: true })
  emailNotifications: boolean;

  @Column({ type: 'boolean', default: true })
  marketingEmails: boolean;

  @Column({ type: 'boolean', default: true })
  affiliateNotifications: boolean;

  // Metadata
  @Column({ type: 'jsonb', nullable: true })
  metadata: Record<string, any>;

  @Column({ type: 'varchar', length: 45, nullable: true })
  lastIp: string;

  @Column({ type: 'timestamp', nullable: true })
  lastLoginAt: Date;

  @Column({ type: 'text', nullable: true })
  userAgent: string;

  // Relationships
  @OneToMany(() => Product, (product) => product.producer)
  products: Product[];

  @OneToOne(() => Affiliate, (affiliate) => affiliate.user)
  affiliate: Affiliate;

  @OneToMany(() => Sale, (sale) => sale.customer)
  purchases: Sale[];

  @OneToMany(() => Enrollment, (enrollment) => enrollment.user)
  enrollments: Enrollment[];

  @OneToMany(() => Review, (review) => review.user)
  reviews: Review[];

  @OneToMany(() => Withdrawal, (withdrawal) => withdrawal.user)
  withdrawals: Withdrawal[];

  @ManyToMany(() => Product, (product) => product.favoritedBy)
  @JoinTable({
    name: 'user_favorites',
    joinColumn: { name: 'userId', referencedColumnName: 'id' },
    inverseJoinColumn: { name: 'productId', referencedColumnName: 'id' },
  })
  favorites: Product[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get fullNameComputed(): string {
    return `${this.firstName} ${this.lastName}`;
  }

  isActive(): boolean {
    return this.status === UserStatus.ACTIVE;
  }

  isProducer(): boolean {
    return this.role === UserRole.PRODUCER || this.role === UserRole.MASTER;
  }

  isAffiliate(): boolean {
    return this.role === UserRole.AFFILIATE || this.role === UserRole.PRODUCER || this.role === UserRole.MASTER;
  }

  isAdmin(): boolean {
    return this.role === UserRole.MASTER;
  }
}
