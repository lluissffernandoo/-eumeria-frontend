import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  OneToMany,
  ManyToOne,
  JoinColumn,
  Tree,
  TreeChildren,
  TreeParent,
  Index,
} from 'typeorm';
import { Product } from './product.entity';
import { Course } from './course.entity';

@Entity('categories')
@Tree('materialized-path')
@Index(['slug'], { unique: true })
@Index(['status'])
export class Category {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 100 })
  name: string;

  @Column({ type: 'varchar', length: 100, unique: true })
  slug: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  image: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  icon: string;

  @Column({ type: 'varchar', length: 7, nullable: true })
  color: string;

  @Column({ type: 'enum', enum: ['active', 'inactive'], default: 'active' })
  status: string;

  @Column({ type: 'int', default: 0 })
  sortOrder: number;

  @Column({ type: 'varchar', length: 255, nullable: true })
  metaTitle: string;

  @Column({ type: 'text', nullable: true })
  metaDescription: string;

  @Column({ type: 'varchar', length: 500, nullable: true })
  metaKeywords: string;

  // Tree structure
  @TreeParent()
  @JoinColumn({ name: 'parentId' })
  parent: Category;

  @Column({ type: 'uuid', nullable: true })
  parentId: string;

  @TreeChildren()
  children: Category[];

  // Relationships
  @OneToMany(() => Product, (product) => product.category)
  products: Product[];

  @OneToMany(() => Course, (course) => course.category)
  courses: Course[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;
}
