import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToMany,
  ManyToMany,
  JoinColumn,
  JoinTable,
  Index,
} from 'typeorm';
import { User } from './user.entity';
import { Category } from './category.entity';
import { Sale } from './sale.entity';
import { Coupon } from './coupon.entity';
import { Review } from './review.entity';
import { Affiliate } from './affiliate.entity';

export enum ProductType {
  DIGITAL = 'digital',
  COURSE = 'course',
  EBOOK = 'ebook',
  SOFTWARE = 'software',
  MEMBERSHIP = 'membership',
  BUNDLE = 'bundle',
}

export enum ProductStatus {
  DRAFT = 'draft',
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  PUBLISHED = 'published',
  UNPUBLISHED = 'unpublished',
  SUSPENDED = 'suspended',
}

export enum CommissionType {
  FIXED = 'fixed',
  PERCENTAGE = 'percentage',
}

@Entity('products')
@Index(['slug'], { unique: true })
@Index(['status'])
@Index(['type'])
@Index(['producer'])
@Index(['category'])
@Index(['price'])
@Index(['isFeatured'])
export class Product {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 200 })
  name: string;

  @Column({ type: 'varchar', length: 200, unique: true })
  slug: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'text', nullable: true })
  shortDescription: string;

  @Column({ type: 'enum', enum: ProductType, default: ProductType.DIGITAL })
  type: ProductType;

  @Column({ type: 'enum', enum: ProductStatus, default: ProductStatus.DRAFT })
  status: ProductStatus;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  price: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  comparePrice: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  costPrice: number;

  @Column({ type: 'varchar', length: 3, default: 'BRL' })
  currency: string;

  // Media
  @Column({ type: 'varchar', length: 255, nullable: true })
  coverImage: string;

  @Column({ type: 'simple-array', nullable: true })
  galleryImages: string[];

  @Column({ type: 'varchar', length: 255, nullable: true })
  previewVideo: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  salesVideo: string;

  // Files
  @Column({ type: 'varchar', length: 255, nullable: true })
  mainFile: string;

  @Column({ type: 'simple-array', nullable: true })
  additionalFiles: string[];

  @Column({ type: 'bigint', nullable: true })
  fileSize: number;

  // Commission settings
  @Column({ type: 'enum', enum: CommissionType, default: CommissionType.PERCENTAGE })
  commissionType: CommissionType;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 30 })
  commissionRate: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  commissionFixed: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 10 })
  platformFee: number;

  // Affiliate settings
  @Column({ type: 'boolean', default: true })
  allowAffiliates: boolean;

  @Column({ type: 'boolean', default: false })
  affiliateApprovalRequired: boolean;

  @Column({ type: 'simple-array', nullable: true })
  approvedAffiliates: string[];

  @Column({ type: 'simple-array', nullable: true })
  blockedAffiliates: string[];

  // Marketing
  @Column({ type: 'varchar', length: 255, nullable: true })
  metaTitle: string;

  @Column({ type: 'text', nullable: true })
  metaDescription: string;

  @Column({ type: 'varchar', length: 500, nullable: true })
  metaKeywords: string;

  @Column({ type: 'text', nullable: true })
  salesPageHtml: string;

  @Column({ type: 'text', nullable: true })
  thankYouPageHtml: string;

  // Settings
  @Column({ type: 'int', default: 7 })
  guaranteeDays: number;

  @Column({ type: 'boolean', default: true })
  hasUnlimitedAccess: boolean;

  @Column({ type: 'int', nullable: true })
  accessDuration: number; // days

  @Column({ type: 'int', default: 0 })
  maxDownloads: number;

  @Column({ type: 'boolean', default: false })
  isFeatured: boolean;

  @Column({ type: 'int', default: 0 })
  sortOrder: number;

  // Inventory
  @Column({ type: 'int', nullable: true })
  stock: number;

  @Column({ type: 'boolean', default: false })
  trackInventory: boolean;

  // Statistics
  @Column({ type: 'int', default: 0 })
  viewCount: number;

  @Column({ type: 'int', default: 0 })
  salesCount: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  totalRevenue: number;

  @Column({ type: 'decimal', precision: 3, scale: 2, nullable: true })
  averageRating: number;

  @Column({ type: 'int', default: 0 })
  reviewCount: number;

  // Relationships
  @ManyToOne(() => User, (user) => user.products)
  @JoinColumn({ name: 'producerId' })
  producer: User;

  @Column({ type: 'uuid' })
  producerId: string;

  @ManyToOne(() => Category, (category) => category.products, { nullable: true })
  @JoinColumn({ name: 'categoryId' })
  category: Category;

  @Column({ type: 'uuid', nullable: true })
  categoryId: string;

  @OneToMany(() => Sale, (sale) => sale.product)
  sales: Sale[];

  @OneToMany(() => Coupon, (coupon) => coupon.product)
  coupons: Coupon[];

  @OneToMany(() => Review, (review) => review.product)
  reviews: Review[];

  @ManyToMany(() => Affiliate, (affiliate) => affiliate.products)
  @JoinTable({
    name: 'product_affiliates',
    joinColumn: { name: 'productId', referencedColumnName: 'id' },
    inverseJoinColumn: { name: 'affiliateId', referencedColumnName: 'id' },
  })
  affiliates: Affiliate[];

  @ManyToMany(() => User, (user) => user.favorites)
  favoritedBy: User[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  publishedAt: Date;

  // Methods
  get discountPercentage(): number {
    if (!this.comparePrice || this.comparePrice <= this.price) return 0;
    return Math.round(((this.comparePrice - this.price) / this.comparePrice) * 100);
  }

  get isOnSale(): boolean {
    return this.comparePrice > this.price;
  }

  get affiliateCommission(): number {
    if (this.commissionType === CommissionType.FIXED) {
      return this.commissionFixed || 0;
    }
    return (this.price * (this.commissionRate || 0)) / 100;
  }

  get producerRevenue(): number {
    const platformFee = (this.price * this.platformFee) / 100;
    const affiliateCommission = this.affiliateCommission;
    return this.price - platformFee - affiliateCommission;
  }
}
