import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

export enum ConfigCategory {
  GENERAL = 'general',
  PAYMENT = 'payment',
  AFFILIATE = 'affiliate',
  EMAIL = 'email',
  SEO = 'seo',
  SECURITY = 'security',
  APPEARANCE = 'appearance',
  INTEGRATIONS = 'integrations',
}

@Entity('configurations')
@Index(['key'], { unique: true })
@Index(['category'])
export class Configuration {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 100, unique: true })
  key: string;

  @Column({ type: 'text' })
  value: string;

  @Column({ type: 'enum', enum: ConfigCategory, default: ConfigCategory.GENERAL })
  category: ConfigCategory;

  @Column({ type: 'varchar', length: 200 })
  label: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'varchar', length: 50, default: 'string' })
  type: 'string' | 'number' | 'boolean' | 'json' | 'array';

  @Column({ type: 'simple-json', nullable: true })
  options: Array<{ label: string; value: any }>;

  @Column({ type: 'boolean', default: false })
  isPublic: boolean;

  @Column({ type: 'boolean', default: true })
  isEditable: boolean;

  @Column({ type: 'int', default: 0 })
  sortOrder: number;

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Methods
  getTypedValue(): any {
    switch (this.type) {
      case 'boolean':
        return this.value === 'true';
      case 'number':
        return parseFloat(this.value);
      case 'json':
        try {
          return JSON.parse(this.value);
        } catch {
          return {};
        }
      case 'array':
        try {
          return JSON.parse(this.value);
        } catch {
          return [];
        }
      default:
        return this.value;
    }
  }

  setTypedValue(value: any): void {
    if (this.type === 'json' || this.type === 'array') {
      this.value = JSON.stringify(value);
    } else {
      this.value = String(value);
    }
  }
}
