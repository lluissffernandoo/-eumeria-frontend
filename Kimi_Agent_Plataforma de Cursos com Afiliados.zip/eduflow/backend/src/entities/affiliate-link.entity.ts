import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { Affiliate } from './affiliate.entity';
import { Product } from './product.entity';

export enum LinkType {
  PRODUCT = 'product',
  CATEGORY = 'category',
  HOME = 'home',
  CHECKOUT = 'checkout',
  CUSTOM = 'custom',
}

@Entity('affiliate_links')
@Index(['code'], { unique: true })
@Index(['affiliate'])
@Index(['product'])
@Index(['type'])
export class AffiliateLink {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 100, unique: true })
  code: string;

  @Column({ type: 'enum', enum: LinkType, default: LinkType.PRODUCT })
  type: LinkType;

  @Column({ type: 'varchar', length: 500, nullable: true })
  customUrl: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  title: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  utmSource: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  utmMedium: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  utmCampaign: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  utmContent: string;

  // Statistics
  @Column({ type: 'int', default: 0 })
  totalClicks: number;

  @Column({ type: 'int', default: 0 })
  uniqueClicks: number;

  @Column({ type: 'int', default: 0 })
  totalConversions: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  totalRevenue: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  totalCommission: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 0 })
  conversionRate: number;

  @Column({ type: 'timestamp', nullable: true })
  lastClickedAt: Date;

  @Column({ type: 'boolean', default: true })
  isActive: boolean;

  // Relationships
  @ManyToOne(() => Affiliate, (affiliate) => affiliate.links, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'affiliateId' })
  affiliate: Affiliate;

  @Column({ type: 'uuid' })
  affiliateId: string;

  @ManyToOne(() => Product, (product) => product.id, { nullable: true })
  @JoinColumn({ name: 'productId' })
  product: Product;

  @Column({ type: 'uuid', nullable: true })
  productId: string;

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get trackingUrl(baseUrl: string): string {
    let url = `${baseUrl}/a/${this.code}`;
    
    const params = new URLSearchParams();
    if (this.utmSource) params.append('utm_source', this.utmSource);
    if (this.utmMedium) params.append('utm_medium', this.utmMedium);
    if (this.utmCampaign) params.append('utm_campaign', this.utmCampaign);
    if (this.utmContent) params.append('utm_content', this.utmContent);
    
    const queryString = params.toString();
    if (queryString) {
      url += `?${queryString}`;
    }
    
    return url;
  }

  updateConversionRate(): void {
    if (this.uniqueClicks > 0) {
      this.conversionRate = parseFloat(((this.totalConversions / this.uniqueClicks) * 100).toFixed(2));
    }
  }

  recordClick(isUnique: boolean = false): void {
    this.totalClicks++;
    if (isUnique) {
      this.uniqueClicks++;
    }
    this.lastClickedAt = new Date();
  }

  recordConversion(amount: number, commission: number): void {
    this.totalConversions++;
    this.totalRevenue += amount;
    this.totalCommission += commission;
    this.updateConversionRate();
  }
}
