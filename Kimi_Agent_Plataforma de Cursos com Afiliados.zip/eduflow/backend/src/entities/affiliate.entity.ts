import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToMany,
  ManyToMany,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from './user.entity';
import { Product } from './product.entity';
import { AffiliateLink } from './affiliate-link.entity';
import { Commission } from './commission.entity';

export enum AffiliateStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  BLOCKED = 'blocked',
  SUSPENDED = 'suspended',
}

export enum AffiliateTier {
  BRONZE = 'bronze',
  SILVER = 'silver',
  GOLD = 'gold',
  PLATINUM = 'platinum',
  DIAMOND = 'diamond',
}

@Entity('affiliates')
@Index(['code'], { unique: true })
@Index(['status'])
@Index(['tier'])
@Index(['user'])
export class Affiliate {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 50, unique: true })
  code: string;

  @Column({ type: 'enum', enum: AffiliateStatus, default: AffiliateStatus.PENDING })
  status: AffiliateStatus;

  @Column({ type: 'enum', enum: AffiliateTier, default: AffiliateTier.BRONZE })
  tier: AffiliateTier;

  // Bio and marketing
  @Column({ type: 'text', nullable: true })
  bio: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  website: string;

  @Column({ type: 'simple-array', nullable: true })
  socialMedia: string[];

  @Column({ type: 'varchar', length: 255, nullable: true })
  trafficSource: string;

  @Column({ type: 'text', nullable: true })
  marketingStrategy: string;

  // Commission settings (override product settings)
  @Column({ type: 'decimal', precision: 5, scale: 2, nullable: true })
  customCommissionRate: number;

  @Column({ type: 'boolean', default: false })
  hasCustomCommission: boolean;

  // Statistics
  @Column({ type: 'int', default: 0 })
  totalClicks: number;

  @Column({ type: 'int', default: 0 })
  totalConversions: number;

  @Column({ type: 'decimal', precision: 5, scale: 2, default: 0 })
  conversionRate: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  totalCommission: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  pendingCommission: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  availableCommission: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  withdrawnCommission: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  totalSales: number;

  // Tier requirements
  @Column({ type: 'int', default: 0 })
  tierSalesCount: number;

  @Column({ type: 'decimal', precision: 15, scale: 2, default: 0 })
  tierSalesAmount: number;

  // Approval info
  @Column({ type: 'text', nullable: true })
  rejectionReason: string;

  @Column({ type: 'uuid', nullable: true })
  approvedBy: string;

  @Column({ type: 'timestamp', nullable: true })
  approvedAt: Date;

  // Relationships
  @ManyToOne(() => User, (user) => user.affiliate, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column({ type: 'uuid' })
  userId: string;

  @OneToMany(() => AffiliateLink, (link) => link.affiliate)
  links: AffiliateLink[];

  @OneToMany(() => Commission, (commission) => commission.affiliate)
  commissions: Commission[];

  @ManyToMany(() => Product, (product) => product.affiliates)
  products: Product[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get performanceScore(): number {
    if (this.totalClicks === 0) return 0;
    const conversionWeight = 0.4;
    const revenueWeight = 0.6;
    const normalizedConversion = Math.min(this.conversionRate / 10, 1);
    const normalizedRevenue = Math.min(this.totalSales / 10000, 1);
    return (normalizedConversion * conversionWeight + normalizedRevenue * revenueWeight) * 100;
  }

  updateConversionRate(): void {
    if (this.totalClicks > 0) {
      this.conversionRate = parseFloat(((this.totalConversions / this.totalClicks) * 100).toFixed(2));
    }
  }

  canWithdraw(amount: number): boolean {
    return this.availableCommission >= amount;
  }
}
