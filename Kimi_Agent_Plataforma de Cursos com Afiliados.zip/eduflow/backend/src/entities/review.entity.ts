import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from './user.entity';
import { Product } from './product.entity';
import { Course } from './course.entity';

export enum ReviewStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
}

@Entity('reviews')
@Index(['user', 'product'], { unique: true })
@Index(['status'])
@Index(['rating'])
@Index(['product'])
@Index(['course'])
export class Review {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'int' })
  rating: number; // 1-5

  @Column({ type: 'text' })
  comment: string;

  @Column({ type: 'enum', enum: ReviewStatus, default: ReviewStatus.APPROVED })
  status: ReviewStatus;

  @Column({ type: 'boolean', default: false })
  isVerifiedPurchase: boolean;

  @Column({ type: 'varchar', length: 255, nullable: true })
  orderNumber: string;

  @Column({ type: 'simple-array', nullable: true })
  likes: string[]; // User IDs who liked

  @Column({ type: 'int', default: 0 })
  likesCount: number;

  @Column({ type: 'simple-array', nullable: true })
  dislikes: string[];

  @Column({ type: 'int', default: 0 })
  dislikesCount: number;

  @Column({ type: 'simple-json', nullable: true })
  replies: Array<{
    id: string;
    userId: string;
    userName: string;
    userAvatar: string;
    comment: string;
    createdAt: Date;
  }>;

  @Column({ type: 'boolean', default: false })
  isHighlighted: boolean;

  @Column({ type: 'int', nullable: true })
  highlightOrder: number;

  // Moderation
  @Column({ type: 'text', nullable: true })
  rejectionReason: string;

  @Column({ type: 'uuid', nullable: true })
  moderatedBy: string;

  @Column({ type: 'timestamp', nullable: true })
  moderatedAt: Date;

  // Relationships
  @ManyToOne(() => User, (user) => user.reviews)
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column({ type: 'uuid' })
  userId: string;

  @ManyToOne(() => Product, (product) => product.reviews, { nullable: true })
  @JoinColumn({ name: 'productId' })
  product: Product;

  @Column({ type: 'uuid', nullable: true })
  productId: string;

  @ManyToOne(() => Course, (course) => course.id, { nullable: true })
  @JoinColumn({ name: 'courseId' })
  course: Course;

  @Column({ type: 'uuid', nullable: true })
  courseId: string;

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  like(userId: string): void {
    if (!this.likes.includes(userId)) {
      this.likes.push(userId);
      this.likesCount = this.likes.length;
      
      // Remove from dislikes if present
      const dislikeIndex = this.dislikes.indexOf(userId);
      if (dislikeIndex > -1) {
        this.dislikes.splice(dislikeIndex, 1);
        this.dislikesCount = this.dislikes.length;
      }
    }
  }

  dislike(userId: string): void {
    if (!this.dislikes.includes(userId)) {
      this.dislikes.push(userId);
      this.dislikesCount = this.dislikes.length;
      
      // Remove from likes if present
      const likeIndex = this.likes.indexOf(userId);
      if (likeIndex > -1) {
        this.likes.splice(likeIndex, 1);
        this.likesCount = this.likes.length;
      }
    }
  }

  addReply(userId: string, userName: string, userAvatar: string, comment: string): void {
    if (!this.replies) {
      this.replies = [];
    }
    
    this.replies.push({
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      userId,
      userName,
      userAvatar,
      comment,
      createdAt: new Date(),
    });
  }

  approve(adminId: string): void {
    this.status = ReviewStatus.APPROVED;
    this.moderatedBy = adminId;
    this.moderatedAt = new Date();
  }

  reject(adminId: string, reason: string): void {
    this.status = ReviewStatus.REJECTED;
    this.rejectionReason = reason;
    this.moderatedBy = adminId;
    this.moderatedAt = new Date();
  }
}
