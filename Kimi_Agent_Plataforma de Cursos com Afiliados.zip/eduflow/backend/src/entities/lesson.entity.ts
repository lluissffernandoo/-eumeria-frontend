import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Index,
} from 'typeorm';
import { Module } from './module.entity';
import { Progress } from './progress.entity';

export enum LessonType {
  VIDEO = 'video',
  AUDIO = 'audio',
  TEXT = 'text',
  PDF = 'pdf',
  QUIZ = 'quiz',
  ASSIGNMENT = 'assignment',
  LIVE = 'live',
}

export enum VideoProvider {
  LOCAL = 'local',
  YOUTUBE = 'youtube',
  VIMEO = 'vimeo',
  WISTIA = 'wistia',
  PANDAVIDEO = 'pandavideo',
}

@Entity('lessons')
@Index(['module'])
@Index(['sortOrder'])
@Index(['type'])
export class Lesson {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 200 })
  title: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({ type: 'enum', enum: LessonType, default: LessonType.VIDEO })
  type: LessonType;

  @Column({ type: 'int', default: 0 })
  sortOrder: number;

  @Column({ type: 'boolean', default: true })
  isPublished: boolean;

  @Column({ type: 'boolean', default: false })
  isFree: boolean;

  // Video content
  @Column({ type: 'enum', enum: VideoProvider, default: VideoProvider.LOCAL })
  videoProvider: VideoProvider;

  @Column({ type: 'varchar', length: 255, nullable: true })
  videoUrl: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  videoFile: string;

  @Column({ type: 'bigint', nullable: true })
  videoSize: number;

  @Column({ type: 'int', nullable: true })
  duration: number; // seconds

  @Column({ type: 'varchar', length: 255, nullable: true })
  thumbnail: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  videoId: string; // For external providers

  // Text content
  @Column({ type: 'text', nullable: true })
  content: string;

  // File attachments
  @Column({ type: 'simple-json', nullable: true })
  attachments: Array<{
    name: string;
    url: string;
    size: number;
    type: string;
  }>;

  // Downloadable resources
  @Column({ type: 'simple-json', nullable: true })
  downloads: Array<{
    name: string;
    url: string;
    size: number;
  }>;

  // Quiz settings
  @Column({ type: 'simple-json', nullable: true })
  quizData: {
    questions: Array<{
      question: string;
      options: string[];
      correctAnswer: number;
      explanation?: string;
    }>;
    passingScore: number;
    maxAttempts: number;
  };

  // Live class settings
  @Column({ type: 'timestamp', nullable: true })
  liveStartTime: Date;

  @Column({ type: 'timestamp', nullable: true })
  liveEndTime: Date;

  @Column({ type: 'varchar', length: 255, nullable: true })
  liveUrl: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  recordingUrl: string;

  // Settings
  @Column({ type: 'boolean', default: false })
  allowComments: boolean;

  @Column({ type: 'boolean', default: true })
  allowDownload: boolean;

  @Column({ type: 'boolean', default: false })
  isPreview: boolean;

  // Drip content
  @Column({ type: 'int', nullable: true })
  dripDays: number; // Days after enrollment to release

  @Column({ type: 'uuid', nullable: true })
  dripAfterLessonId: string; // Release after completing this lesson

  // Statistics
  @Column({ type: 'int', default: 0 })
  viewCount: number;

  @Column({ type: 'int', default: 0 })
  completionCount: number;

  // Relationships
  @ManyToOne(() => Module, (module) => module.lessons, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'moduleId' })
  module: Module;

  @Column({ type: 'uuid' })
  moduleId: string;

  @OneToMany(() => Progress, (progress) => progress.lesson)
  progress: Progress[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get durationFormatted(): string {
    if (!this.duration) return '00:00';
    const hours = Math.floor(this.duration / 3600);
    const minutes = Math.floor((this.duration % 3600) / 60);
    const seconds = this.duration % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  get isVideo(): boolean {
    return this.type === LessonType.VIDEO;
  }

  get isLive(): boolean {
    return this.type === LessonType.LIVE;
  }

  get isQuiz(): boolean {
    return this.type === LessonType.QUIZ;
  }
}
