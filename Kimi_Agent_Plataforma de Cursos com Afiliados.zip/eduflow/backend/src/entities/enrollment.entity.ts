import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from './user.entity';
import { Course } from './course.entity';
import { Product } from './product.entity';
import { Progress } from './progress.entity';
import { Sale } from './sale.entity';

export enum EnrollmentStatus {
  ACTIVE = 'active',
  COMPLETED = 'completed',
  EXPIRED = 'expired',
  CANCELLED = 'cancelled',
  REFUNDED = 'refunded',
  SUSPENDED = 'suspended',
}

@Entity('enrollments')
@Index(['user', 'course'], { unique: true })
@Index(['status'])
@Index(['user'])
@Index(['course'])
@Index(['expiresAt'])
export class Enrollment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: EnrollmentStatus, default: EnrollmentStatus.ACTIVE })
  status: EnrollmentStatus;

  @Column({ type: 'timestamp', nullable: true })
  completedAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  expiresAt: Date;

  @Column({ type: 'int', default: 0 })
  progressPercentage: number;

  @Column({ type: 'int', default: 0 })
  completedLessons: number;

  @Column({ type: 'int', default: 0 })
  totalLessons: number;

  @Column({ type: 'int', default: 0 })
  timeSpent: number; // minutes

  @Column({ type: 'int', default: 0 })
  lastLessonId: number;

  @Column({ type: 'timestamp', nullable: true })
  lastAccessedAt: Date;

  @Column({ type: 'varchar', length: 45, nullable: true })
  lastAccessIp: string;

  // Certificate
  @Column({ type: 'boolean', default: false })
  certificateIssued: boolean;

  @Column({ type: 'varchar', length: 100, nullable: true })
  certificateNumber: string;

  @Column({ type: 'timestamp', nullable: true })
  certificateIssuedAt: Date;

  @Column({ type: 'varchar', length: 255, nullable: true })
  certificateUrl: string;

  // Purchase info
  @Column({ type: 'decimal', precision: 10, scale: 2 })
  purchasePrice: number;

  @Column({ type: 'varchar', length: 50 })
  orderNumber: string;

  // Relationships
  @ManyToOne(() => User, (user) => user.enrollments)
  @JoinColumn({ name: 'userId' })
  user: User;

  @Column({ type: 'uuid' })
  userId: string;

  @ManyToOne(() => Course, (course) => course.enrollments)
  @JoinColumn({ name: 'courseId' })
  course: Course;

  @Column({ type: 'uuid' })
  courseId: string;

  @ManyToOne(() => Product, (product) => product.id, { nullable: true })
  @JoinColumn({ name: 'productId' })
  product: Product;

  @Column({ type: 'uuid', nullable: true })
  productId: string;

  @ManyToOne(() => Sale, (sale) => sale.id, { nullable: true })
  @JoinColumn({ name: 'saleId' })
  sale: Sale;

  @Column({ type: 'uuid', nullable: true })
  saleId: string;

  @OneToMany(() => Progress, (progress) => progress.enrollment)
  progress: Progress[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get isActive(): boolean {
    if (this.status !== EnrollmentStatus.ACTIVE) return false;
    if (this.expiresAt && new Date() > this.expiresAt) return false;
    return true;
  }

  get isExpired(): boolean {
    return this.expiresAt !== null && new Date() > this.expiresAt;
  }

  get isCompleted(): boolean {
    return this.status === EnrollmentStatus.COMPLETED;
  }

  get canAccess(): boolean {
    return this.isActive;
  }

  updateProgress(): void {
    if (this.totalLessons > 0) {
      this.progressPercentage = Math.round((this.completedLessons / this.totalLessons) * 100);
    }
    
    if (this.progressPercentage >= 100) {
      this.status = EnrollmentStatus.COMPLETED;
      this.completedAt = new Date();
    }
  }

  recordAccess(ip?: string): void {
    this.lastAccessedAt = new Date();
    if (ip) {
      this.lastAccessIp = ip;
    }
  }

  issueCertificate(): void {
    if (this.isCompleted && !this.certificateIssued) {
      this.certificateIssued = true;
      this.certificateIssuedAt = new Date();
      this.certificateNumber = `CERT-${Date.now()}-${this.userId.slice(0, 8)}`;
    }
  }
}
