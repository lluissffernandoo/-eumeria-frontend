import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { Enrollment } from './enrollment.entity';
import { Lesson } from './lesson.entity';

@Entity('progress')
@Index(['enrollment', 'lesson'], { unique: true })
@Index(['enrollment'])
@Index(['lesson'])
@Index(['isCompleted'])
export class Progress {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'int', default: 0 })
  progressPercentage: number;

  @Column({ type: 'int', default: 0 })
  timeSpent: number; // seconds

  @Column({ type: 'int', nullable: true })
  lastPosition: number; // seconds for video

  @Column({ type: 'boolean', default: false })
  isCompleted: boolean;

  @Column({ type: 'timestamp', nullable: true })
  completedAt: Date;

  @Column({ type: 'int', default: 0 })
  attempts: number;

  @Column({ type: 'simple-json', nullable: true })
  quizResults: {
    score: number;
    maxScore: number;
    answers: number[];
    passed: boolean;
    attempts: number;
  };

  @Column({ type: 'text', nullable: true })
  notes: string;

  // Relationships
  @ManyToOne(() => Enrollment, (enrollment) => enrollment.progress, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'enrollmentId' })
  enrollment: Enrollment;

  @Column({ type: 'uuid' })
  enrollmentId: string;

  @ManyToOne(() => Lesson, (lesson) => lesson.progress, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'lessonId' })
  lesson: Lesson;

  @Column({ type: 'uuid' })
  lessonId: string;

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Methods
  updateProgress(percentage: number): void {
    this.progressPercentage = Math.min(percentage, 100);
    
    if (this.progressPercentage >= 90 && !this.isCompleted) {
      this.markAsCompleted();
    }
  }

  markAsCompleted(): void {
    this.isCompleted = true;
    this.progressPercentage = 100;
    this.completedAt = new Date();
  }

  addTimeSpent(seconds: number): void {
    this.timeSpent += seconds;
  }

  recordQuizAttempt(score: number, maxScore: number, answers: number[], passed: boolean): void {
    this.attempts++;
    this.quizResults = {
      score,
      maxScore,
      answers,
      passed,
      attempts: this.attempts,
    };
    
    if (passed) {
      this.markAsCompleted();
    }
  }
}
