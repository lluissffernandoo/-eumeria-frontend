import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
} from 'typeorm';

export enum LogLevel {
  DEBUG = 'debug',
  INFO = 'info',
  WARN = 'warn',
  ERROR = 'error',
  FATAL = 'fatal',
}

export enum LogCategory {
  AUTH = 'auth',
  USER = 'user',
  PRODUCT = 'product',
  SALE = 'sale',
  PAYMENT = 'payment',
  AFFILIATE = 'affiliate',
  COMMISSION = 'commission',
  WITHDRAWAL = 'withdrawal',
  SYSTEM = 'system',
  SECURITY = 'security',
  API = 'api',
  WEBHOOK = 'webhook',
  EMAIL = 'email',
  DATABASE = 'database',
}

@Entity('logs')
@Index(['level'])
@Index(['category'])
@Index(['userId'])
@Index(['createdAt'])
@Index(['ip'])
export class Log {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'enum', enum: LogLevel })
  level: LogLevel;

  @Column({ type: 'enum', enum: LogCategory })
  category: LogCategory;

  @Column({ type: 'text' })
  message: string;

  @Column({ type: 'simple-json', nullable: true })
  context: Record<string, any>;

  @Column({ type: 'simple-json', nullable: true })
  metadata: Record<string, any>;

  @Column({ type: 'text', nullable: true })
  stackTrace: string;

  // User info
  @Column({ type: 'uuid', nullable: true })
  userId: string;

  @Column({ type: 'varchar', length: 200, nullable: true })
  userEmail: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  userRole: string;

  // Request info
  @Column({ type: 'varchar', length: 10, nullable: true })
  method: string;

  @Column({ type: 'varchar', length: 500, nullable: true })
  path: string;

  @Column({ type: 'simple-json', nullable: true })
  requestBody: Record<string, any>;

  @Column({ type: 'simple-json', nullable: true })
  requestHeaders: Record<string, any>;

  @Column({ type: 'int', nullable: true })
  statusCode: number;

  @Column({ type: 'int', nullable: true })
  responseTime: number;

  // Client info
  @Column({ type: 'varchar', length: 45, nullable: true })
  ip: string;

  @Column({ type: 'text', nullable: true })
  userAgent: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  fingerprint: string;

  // Entity reference
  @Column({ type: 'varchar', length: 50, nullable: true })
  entityType: string;

  @Column({ type: 'uuid', nullable: true })
  entityId: string;

  // Timestamp
  @CreateDateColumn()
  createdAt: Date;

  // Static methods for easy logging
  static create(level: LogLevel, category: LogCategory, message: string, context?: Record<string, any>): Log {
    const log = new Log();
    log.level = level;
    log.category = category;
    log.message = message;
    log.context = context || {};
    return log;
  }

  static debug(category: LogCategory, message: string, context?: Record<string, any>): Log {
    return this.create(LogLevel.DEBUG, category, message, context);
  }

  static info(category: LogCategory, message: string, context?: Record<string, any>): Log {
    return this.create(LogLevel.INFO, category, message, context);
  }

  static warn(category: LogCategory, message: string, context?: Record<string, any>): Log {
    return this.create(LogLevel.WARN, category, message, context);
  }

  static error(category: LogCategory, message: string, context?: Record<string, any>, stackTrace?: string): Log {
    const log = this.create(LogLevel.ERROR, category, message, context);
    log.stackTrace = stackTrace;
    return log;
  }

  static fatal(category: LogCategory, message: string, context?: Record<string, any>, stackTrace?: string): Log {
    const log = this.create(LogLevel.FATAL, category, message, context);
    log.stackTrace = stackTrace;
    return log;
  }

  setUser(userId: string, email: string, role: string): void {
    this.userId = userId;
    this.userEmail = email;
    this.userRole = role;
  }

  setRequest(method: string, path: string, body?: Record<string, any>, headers?: Record<string, any>): void {
    this.method = method;
    this.path = path;
    this.requestBody = body;
    this.requestHeaders = headers;
  }

  setResponse(statusCode: number, responseTime: number): void {
    this.statusCode = statusCode;
    this.responseTime = responseTime;
  }

  setClientInfo(ip: string, userAgent: string, fingerprint?: string): void {
    this.ip = ip;
    this.userAgent = userAgent;
    this.fingerprint = fingerprint;
  }

  setEntity(entityType: string, entityId: string): void {
    this.entityType = entityType;
    this.entityId = entityId;
  }
}
