import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  DeleteDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Index,
} from 'typeorm';
import { User } from './user.entity';
import { Product } from './product.entity';
import { Affiliate } from './affiliate.entity';
import { AffiliateLink } from './affiliate-link.entity';
import { Commission } from './commission.entity';
import { Coupon } from './coupon.entity';

export enum SaleStatus {
  PENDING = 'pending',
  PROCESSING = 'processing',
  COMPLETED = 'completed',
  FAILED = 'failed',
  REFUNDED = 'refunded',
  PARTIALLY_REFUNDED = 'partially_refunded',
  CANCELLED = 'cancelled',
  DISPUTED = 'disputed',
  CHARGEBACK = 'chargeback',
}

export enum PaymentMethod {
  CREDIT_CARD = 'credit_card',
  DEBIT_CARD = 'debit_card',
  BOLETO = 'boleto',
  PIX = 'pix',
  BANK_TRANSFER = 'bank_transfer',
  WALLET = 'wallet',
  FREE = 'free',
}

export enum PaymentStatus {
  PENDING = 'pending',
  AUTHORIZED = 'authorized',
  PAID = 'paid',
  FAILED = 'failed',
  REFUNDED = 'refunded',
  CANCELLED = 'cancelled',
}

@Entity('sales')
@Index(['orderNumber'], { unique: true })
@Index(['status'])
@Index(['paymentStatus'])
@Index(['customer'])
@Index(['product'])
@Index(['affiliate'])
@Index(['createdAt'])
export class Sale {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 50, unique: true })
  orderNumber: string;

  @Column({ type: 'enum', enum: SaleStatus, default: SaleStatus.PENDING })
  status: SaleStatus;

  // Pricing
  @Column({ type: 'decimal', precision: 10, scale: 2 })
  originalPrice: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  discountAmount: number;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  finalPrice: number;

  @Column({ type: 'varchar', length: 3, default: 'BRL' })
  currency: string;

  // Payment
  @Column({ type: 'enum', enum: PaymentMethod })
  paymentMethod: PaymentMethod;

  @Column({ type: 'enum', enum: PaymentStatus, default: PaymentStatus.PENDING })
  paymentStatus: PaymentStatus;

  @Column({ type: 'varchar', length: 255, nullable: true })
  paymentIntentId: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  paymentTransactionId: string;

  @Column({ type: 'int', default: 1 })
  installments: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  installmentAmount: number;

  @Column({ type: 'timestamp', nullable: true })
  paidAt: Date;

  @Column({ type: 'timestamp', nullable: true })
  refundedAt: Date;

  @Column({ type: 'decimal', precision: 10, scale: 2, nullable: true })
  refundedAmount: number;

  // Fees
  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  platformFee: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  paymentFee: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  affiliateCommission: number;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  producerRevenue: number;

  // Affiliate tracking
  @Column({ type: 'boolean', default: false })
  hasAffiliate: boolean;

  @Column({ type: 'varchar', length: 100, nullable: true })
  affiliateCode: string;

  @Column({ type: 'varchar', length: 45, nullable: true })
  affiliateIp: string;

  @Column({ type: 'text', nullable: true })
  affiliateUserAgent: string;

  @Column({ type: 'timestamp', nullable: true })
  affiliateClickAt: Date;

  @Column({ type: 'varchar', length: 100, nullable: true })
  referrer: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  landingPage: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  utmSource: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  utmMedium: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  utmCampaign: string;

  // Customer info (snapshot at purchase)
  @Column({ type: 'varchar', length: 200 })
  customerName: string;

  @Column({ type: 'varchar', length: 255 })
  customerEmail: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  customerPhone: string;

  @Column({ type: 'varchar', length: 20, nullable: true })
  customerDocument: string;

  // Fraud prevention
  @Column({ type: 'varchar', length: 45 })
  customerIp: string;

  @Column({ type: 'text' })
  userAgent: string;

  @Column({ type: 'varchar', length: 100, nullable: true })
  fingerprint: string;

  @Column({ type: 'boolean', default: false })
  isSelfPurchase: boolean;

  @Column({ type: 'simple-json', nullable: true })
  fraudCheck: {
    score: number;
    riskLevel: 'low' | 'medium' | 'high';
    flags: string[];
  };

  // Guarantee
  @Column({ type: 'int', default: 7 })
  guaranteeDays: number;

  @Column({ type: 'timestamp', nullable: true })
  guaranteeExpiresAt: Date;

  @Column({ type: 'boolean', default: false })
  guaranteeClaimed: boolean;

  @Column({ type: 'timestamp', nullable: true })
  guaranteeClaimedAt: Date;

  // Metadata
  @Column({ type: 'simple-json', nullable: true })
  metadata: Record<string, any>;

  @Column({ type: 'text', nullable: true })
  notes: string;

  // Relationships
  @ManyToOne(() => User, (user) => user.purchases)
  @JoinColumn({ name: 'customerId' })
  customer: User;

  @Column({ type: 'uuid' })
  customerId: string;

  @ManyToOne(() => Product, (product) => product.sales)
  @JoinColumn({ name: 'productId' })
  product: Product;

  @Column({ type: 'uuid' })
  productId: string;

  @ManyToOne(() => Affiliate, (affiliate) => affiliate.id, { nullable: true })
  @JoinColumn({ name: 'affiliateId' })
  affiliate: Affiliate;

  @Column({ type: 'uuid', nullable: true })
  affiliateId: string;

  @ManyToOne(() => AffiliateLink, (link) => link.id, { nullable: true })
  @JoinColumn({ name: 'affiliateLinkId' })
  affiliateLink: AffiliateLink;

  @Column({ type: 'uuid', nullable: true })
  affiliateLinkId: string;

  @ManyToOne(() => Coupon, (coupon) => coupon.sales, { nullable: true })
  @JoinColumn({ name: 'couponId' })
  coupon: Coupon;

  @Column({ type: 'uuid', nullable: true })
  couponId: string;

  @OneToMany(() => Commission, (commission) => commission.sale)
  commissions: Commission[];

  // Timestamps
  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @DeleteDateColumn()
  deletedAt: Date;

  // Methods
  get isPaid(): boolean {
    return this.paymentStatus === PaymentStatus.PAID;
  }

  get isRefunded(): boolean {
    return this.status === SaleStatus.REFUNDED || this.status === SaleStatus.PARTIALLY_REFUNDED;
  }

  get isCompleted(): boolean {
    return this.status === SaleStatus.COMPLETED;
  }

  get isInGuaranteePeriod(): boolean {
    if (!this.guaranteeExpiresAt) return false;
    return new Date() < this.guaranteeExpiresAt;
  }

  get discountPercentage(): number {
    if (this.originalPrice === 0) return 0;
    return Math.round((this.discountAmount / this.originalPrice) * 100);
  }

  canRefund(): boolean {
    return this.isPaid && !this.isRefunded && this.status !== SaleStatus.CHARGEBACK;
  }

  calculateCommission(): void {
    this.platformFee = (this.finalPrice * 0.1); // 10% platform fee
    
    if (this.hasAffiliate) {
      this.affiliateCommission = (this.finalPrice * 0.3); // 30% affiliate commission
    }
    
    this.producerRevenue = this.finalPrice - this.platformFee - this.affiliateCommission - this.paymentFee;
  }
}
