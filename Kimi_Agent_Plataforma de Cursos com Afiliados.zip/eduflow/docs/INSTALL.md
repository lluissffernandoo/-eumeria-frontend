# Guia de Instalação - Eumería

Este guia detalha o processo completo de instalação da plataforma Eumería.

## 📋 Requisitos do Sistema

### Mínimos
- Node.js 18.x
- PostgreSQL 14.x
- 2GB RAM
- 20GB espaço em disco

### Recomendados
- Node.js 20.x LTS
- PostgreSQL 15.x
- 4GB RAM
- 50GB SSD
- Redis 7.x (opcional)

## 🖥️ Instalação Local (Desenvolvimento)

### Windows

1. **Instale o Node.js**
   - Baixe em https://nodejs.org
   - Instale a versão LTS
   - Verifique: `node -v` e `npm -v`

2. **Instale o PostgreSQL**
   - Baixe em https://postgresql.org/download/windows
   - Durante a instalação, defina a senha do postgres
   - Anote a porta (padrão: 5432)

3. **Configure o banco de dados**
   ```bash
   # Abra o pgAdmin ou psql
   CREATE DATABASE eumeria;
   CREATE USER eumeria WITH PASSWORD 'eumeria123';
   GRANT ALL PRIVILEGES ON DATABASE eumeria TO eumeria;
   ```

4. **Clone e configure o projeto**
   ```bash
   git clone https://github.com/seu-usuario/eumeria.git
   cd eumeria/backend
   npm install
   copy .env.example .env
   ```

5. **Edite o arquivo .env**
   ```env
   DB_PASSWORD=sua-senha-do-postgres
   JWT_ACCESS_SECRET=uma-chave-super-segura-aqui
   JWT_REFRESH_SECRET=outra-chave-super-segura-aqui
   ```

6. **Execute as migrações e inicie**
   ```bash
   npm run migration:run
   npm run start:dev
   ```

### macOS

1. **Instale o Homebrew** (se não tiver)
   ```bash
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```

2. **Instale as dependências**
   ```bash
   brew install node@18 postgresql@15
   brew services start postgresql@15
   ```

3. **Configure o banco de dados**
   ```bash
   createdb eumeria
   createuser -P eumeria  # Defina a senha quando solicitado
   psql -c "GRANT ALL PRIVILEGES ON DATABASE eumeria TO eumeria;"
   ```

4. **Continue a partir do passo 4 do Windows**

### Linux (Ubuntu/Debian)

1. **Atualize o sistema**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

2. **Instale Node.js**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

3. **Instale PostgreSQL**
   ```bash
   sudo apt install postgresql postgresql-contrib -y
   sudo systemctl start postgresql
   sudo systemctl enable postgresql
   ```

4. **Configure o banco de dados**
   ```bash
   sudo -u postgres psql -c "CREATE DATABASE eumeria;"
   sudo -u postgres psql -c "CREATE USER eumeria WITH PASSWORD 'eumeria123';"
   sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE eumeria TO eumeria;"
   ```

5. **Clone e configure**
   ```bash
   git clone https://github.com/seu-usuario/eumeria.git
   cd eumeria/backend
   npm install
   cp .env.example .env
   nano .env  # Edite as configurações
   ```

6. **Execute migrações e inicie**
   ```bash
   npm run migration:run
   npm run start:dev
   ```

## 🚀 Instalação em Produção (VPS)

### 1. Preparação do Servidor

```bash
# Atualize o sistema
sudo apt update && sudo apt upgrade -y

# Instale ferramentas essenciais
sudo apt install -y curl wget git build-essential nginx

# Configure firewall
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### 2. Instale Node.js

```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verifique
node -v
npm -v
```

### 3. Instale e Configure PostgreSQL

```bash
sudo apt install postgresql postgresql-contrib -y
sudo systemctl enable postgresql

# Configure o banco
sudo -u postgres psql << EOF
CREATE DATABASE eumeria;
CREATE USER eumeria WITH PASSWORD 'sua-senha-forte-aqui';
GRANT ALL PRIVILEGES ON DATABASE eumeria TO eumeria;
\q
EOF
```

### 4. Instale PM2

```bash
sudo npm install -g pm2
```

### 5. Deploy da Aplicação

```bash
# Crie usuário para a aplicação
sudo useradd -m -s /bin/bash eumeria
sudo usermod -aG sudo eumeria

# Mude para o usuário
sudo su - eumeria

# Clone o repositório
git clone https://github.com/seu-usuario/eumeria.git
cd eumeria/backend

# Instale dependências
npm install --production

# Configure o ambiente
cp .env.example .env
nano .env
```

Configure o `.env` para produção:
```env
NODE_ENV=production
PORT=3001
DB_HOST=localhost
DB_PASSWORD=sua-senha-forte-aqui
JWT_ACCESS_SECRET=chave-super-secreta-e-longa-para-producao
JWT_REFRESH_SECRET=outra-chave-super-secreta-e-longa
# ... outras configurações
```

```bash
# Execute migrações
npm run migration:run

# Build
npm run build

# Inicie com PM2
pm2 start dist/main.js --name eumeria-api
pm2 save
pm2 startup
```

### 6. Configure o Nginx

```bash
sudo nano /etc/nginx/sites-available/eumeria
```

Adicione:
```nginx
server {
    listen 80;
    server_name api.seudominio.com.br;

    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/eumeria /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 7. Configure SSL (HTTPS)

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d api.seudominio.com.br
```

### 8. Configurações de Segurança Adicionais

```bash
# Limite de arquivos abertos
sudo nano /etc/security/limits.conf
# Adicione:
# eumeria soft nofile 65535
# eumeria hard nofile 65535

# Configurações do kernel
sudo nano /etc/sysctl.conf
# Adicione:
# fs.file-max = 2097152
# net.core.somaxconn = 65535
```

## 🐳 Instalação com Docker

### Usando Docker Compose

1. **Crie o arquivo docker-compose.yml**

```yaml
version: '3.8'

services:
  api:
    build: ./backend
    ports:
      - "3001:3001"
    environment:
      - NODE_ENV=production
      - DB_HOST=postgres
      - DB_PORT=5432
      - DB_NAME=eumeria
      - DB_USERNAME=eumeria
      - DB_PASSWORD=eumeria123
      - JWT_ACCESS_SECRET=your-secret
      - JWT_REFRESH_SECRET=your-refresh-secret
    depends_on:
      - postgres
      - redis
    volumes:
      - ./uploads:/app/uploads

  postgres:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=eumeria
      - POSTGRES_USER=eumeria
      - POSTGRES_PASSWORD=eumeria123
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - api

volumes:
  postgres_data:
```

2. **Execute**

```bash
docker-compose up -d
```

## 🔧 Solução de Problemas

### Erro: "Cannot find module"

```bash
# Limpe o cache e reinstale
rm -rf node_modules package-lock.json
npm install
```

### Erro: "Connection refused" no PostgreSQL

```bash
# Verifique se o PostgreSQL está rodando
sudo systemctl status postgresql

# Verifique a configuração de conexão
sudo nano /etc/postgresql/15/main/pg_hba.conf
# Altere para:
# host all all 127.0.0.1/32 md5

sudo systemctl restart postgresql
```

### Erro: "Port already in use"

```bash
# Encontre o processo usando a porta
sudo lsof -i :3001

# Mate o processo
sudo kill -9 <PID>
```

### Erro de migração

```bash
# Reset das migrações (CUIDADO: Apaga dados)
npm run typeorm schema:drop
npm run migration:run

# Ou recrie o banco
sudo -u postgres psql -c "DROP DATABASE eumeria;"
sudo -u postgres psql -c "CREATE DATABASE eumeria;"
npm run migration:run
```

## 📞 Suporte

Se encontrar problemas:

1. Verifique os logs: `npm run start:dev` ou `pm2 logs eumeria-api`
2. Consulte a documentação: `/docs`
3. Abra uma issue no GitHub
4. Entre em contato: suporte@eumeria.com.br

---

**Próximo passo**: [Guia de Configuração](CONFIGURATION.md)
