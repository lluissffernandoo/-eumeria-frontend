# Eumería - Plataforma de Cursos e Produtos Digitais

Sistema completo de vendas de cursos e produtos digitais com sistema de afiliados integrado.

## 📋 Sumário

- [Visão Geral](#visão-geral)
- [Funcionalidades](#funcionalidades)
- [Tecnologias](#tecnologias)
- [Arquitetura](#arquitetura)
- [Instalação](#instalação)
- [Configuração](#configuração)
- [Uso](#uso)
- [API Documentation](#api-documentation)
- [Deploy](#deploy)
- [Segurança](#segurança)
- [Contribuição](#contribuição)

## 🎯 Visão Geral

A Eumería é uma plataforma white-label completa para venda de cursos online e produtos digitais com sistema de afiliados integrado. Desenvolvida com tecnologias modernas e escaláveis, oferece:

- 4 níveis de usuários: Master, Produtor, Afiliado e Cliente
- Sistema completo de afiliados com tracking de 30 dias
- Gateway de pagamento integrado (Stripe e Mercado Pago)
- Área de membros completa
- Painéis administrativos robustos
- Sistema de comissões automático

## ✨ Funcionalidades

### Administrador Master
- ✅ Gerenciamento completo de usuários
- ✅ Edição e exclusão de produtos
- ✅ Configuração de taxas da plataforma
- ✅ Ajuste manual de comissões
- ✅ Aprovação/bloqueio de produtores e afiliados
- ✅ Gestão de saques
- ✅ Visualização total de vendas
- ✅ Exportação de relatórios CSV
- ✅ Controle de cupons globais
- ✅ Configuração de prazo de garantia
- ✅ Gerenciamento de banners
- ✅ Logs do sistema
- ✅ Backup manual do banco de dados

### Produtor
- ✅ Criar e editar produtos digitais
- ✅ Criar cursos com módulos e aulas
- ✅ Upload de vídeos e arquivos
- ✅ Definir porcentagem de comissão
- ✅ Aprovar/reprovar afiliados
- ✅ Criar cupons próprios
- ✅ Métricas e relatórios de vendas

### Afiliado
- ✅ Link exclusivo com código único
- ✅ Visualizar cliques e conversões
- ✅ Comissão pendente/liberada/sacada
- ✅ Solicitar saque
- ✅ Materiais de divulgação
- ✅ Ranking de afiliados

### Cliente
- ✅ Criar conta
- ✅ Comprar produtos
- ✅ Acessar área de membros
- ✅ Visualizar histórico de compras

## 🛠 Tecnologias

### Backend
- **Node.js** + **NestJS** - Framework escalável
- **TypeScript** - Tipagem estática
- **PostgreSQL** - Banco de dados relacional
- **TypeORM** - ORM para PostgreSQL
- **JWT** - Autenticação com access e refresh tokens
- **bcrypt** - Hash de senhas
- **Redis** - Cache e sessões (preparado)
- **Stripe/Mercado Pago** - Gateway de pagamento

### Frontend
- **React 18** + **TypeScript**
- **Vite** - Build tool
- **Tailwind CSS** - Estilização
- **shadcn/ui** - Componentes UI
- **React Query** - Gerenciamento de estado
- **React Router** - Roteamento
- **Axios** - HTTP client

### Segurança
- HTTPS obrigatório
- Hash de senha com bcrypt
- Proteção contra SQL Injection
- Proteção contra XSS
- Rate limiting em login
- Verificação de e-mail
- 2FA opcional

## 🏗 Arquitetura

```
eumeria/
├── backend/                 # API NestJS
│   ├── src/
│   │   ├── config/         # Configurações
│   │   ├── entities/       # Entidades TypeORM
│   │   ├── modules/        # Módulos da aplicação
│   │   │   ├── auth/       # Autenticação
│   │   │   ├── users/      # Usuários
│   │   │   ├── products/   # Produtos
│   │   │   ├── courses/    # Cursos
│   │   │   ├── affiliates/ # Afiliados
│   │   │   ├── sales/      # Vendas
│   │   │   ├── commissions/# Comissões
│   │   │   ├── withdrawals/# Saques
│   │   │   ├── payments/   # Pagamentos
│   │   │   └── admin/      # Admin
│   │   ├── common/         # Utilitários
│   │   └── main.ts         # Entry point
│   └── package.json
├── frontend/               # Aplicação React
│   ├── src/
│   │   ├── components/     # Componentes
│   │   ├── pages/          # Páginas
│   │   ├── hooks/          # Custom hooks
│   │   ├── services/       # API services
│   │   └── store/          # Estado global
│   └── package.json
├── database/              # Migrations e seeds
└── docs/                  # Documentação
```

## 📦 Instalação

### Pré-requisitos
- Node.js 18+
- PostgreSQL 14+
- Redis 7+ (opcional)
- NPM ou Yarn

### 1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/eumeria.git
cd eumeria
```

### 2. Instale as dependências do backend
```bash
cd backend
npm install
```

### 3. Configure o ambiente
```bash
cp .env.example .env
# Edite o arquivo .env com suas configurações
```

### 4. Execute as migrações
```bash
npm run migration:run
```

### 5. (Opcional) Execute os seeds
```bash
npm run seed
```

### 6. Inicie o servidor
```bash
# Desenvolvimento
npm run start:dev

# Produção
npm run build
npm run start:prod
```

### 7. Instale e inicie o frontend
```bash
cd ../frontend
npm install
npm run dev
```

## ⚙️ Configuração

### Variáveis de Ambiente Principais

| Variável | Descrição | Padrão |
|----------|-----------|--------|
| `NODE_ENV` | Ambiente (development/production) | development |
| `PORT` | Porta do servidor | 3001 |
| `DB_HOST` | Host do PostgreSQL | localhost |
| `DB_PORT` | Porta do PostgreSQL | 5432 |
| `DB_NAME` | Nome do banco | eumeria |
| `JWT_ACCESS_SECRET` | Secret do JWT | - |
| `STRIPE_SECRET_KEY` | Secret key do Stripe | - |
| `MP_ACCESS_TOKEN` | Token do Mercado Pago | - |

### Configuração de Pagamentos

#### Stripe
1. Crie uma conta em https://stripe.com
2. Obtenha suas chaves de API
3. Configure o webhook para `/webhooks/stripe`

#### Mercado Pago
1. Crie uma conta em https://mercadopago.com.br
2. Obtenha suas credenciais
3. Configure a URL de notificação

## 🚀 Uso

### Acesso ao Sistema

Após a instalação, acesse:

- **Frontend**: http://localhost:3000
- **API**: http://localhost:3001
- **Documentação API**: http://localhost:3001/api/docs

### Credenciais Padrão (após seed)

- **Email**: admin@eumeria.com.br
- **Senha**: Admin@123

## 📚 API Documentation

A documentação completa da API está disponível em `/api/docs` quando o servidor está rodando.

### Endpoints Principais

#### Autenticação
- `POST /api/v1/auth/register` - Registrar usuário
- `POST /api/v1/auth/login` - Login
- `POST /api/v1/auth/refresh` - Renovar token
- `POST /api/v1/auth/logout` - Logout
- `GET /api/v1/auth/me` - Dados do usuário

#### Usuários
- `GET /api/v1/users` - Listar usuários
- `GET /api/v1/users/:id` - Obter usuário
- `POST /api/v1/users` - Criar usuário
- `PUT /api/v1/users/:id` - Atualizar usuário
- `DELETE /api/v1/users/:id` - Excluir usuário

#### Produtos
- `GET /api/v1/products` - Listar produtos
- `GET /api/v1/products/:id` - Obter produto
- `POST /api/v1/products` - Criar produto
- `PUT /api/v1/products/:id` - Atualizar produto
- `DELETE /api/v1/products/:id` - Excluir produto

#### Afiliados
- `GET /api/v1/affiliates` - Listar afiliados
- `POST /api/v1/affiliates` - Registrar como afiliado
- `GET /api/v1/affiliates/dashboard` - Dashboard do afiliado
- `GET /api/v1/affiliates/links` - Links de afiliado

#### Vendas
- `GET /api/v1/sales` - Listar vendas
- `GET /api/v1/sales/:id` - Obter venda
- `POST /api/v1/sales/checkout` - Iniciar checkout
- `POST /api/v1/sales/webhook` - Webhook de pagamento

## 🌐 Deploy

### Deploy em VPS (Ubuntu)

1. **Configure o servidor**
```bash
# Atualize o sistema
sudo apt update && sudo apt upgrade -y

# Instale Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Instale PostgreSQL
sudo apt install postgresql postgresql-contrib -y

# Instale PM2
sudo npm install -g pm2
```

2. **Configure o banco de dados**
```bash
sudo -u postgres psql -c "CREATE DATABASE eumeria;"
sudo -u postgres psql -c "CREATE USER eumeria WITH PASSWORD 'sua-senha';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE eumeria TO eumeria;"
```

3. **Deploy da aplicação**
```bash
# Clone o repositório
git clone https://github.com/seu-usuario/eumeria.git
cd eumeria/backend

# Instale dependências
npm install --production

# Configure o ambiente
cp .env.example .env
nano .env

# Execute migrações
npm run migration:run

# Build
npm run build

# Inicie com PM2
pm2 start dist/main.js --name eumeria-api
pm2 save
pm2 startup
```

4. **Configure o Nginx**
```nginx
server {
    listen 80;
    server_name api.seudominio.com.br;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

5. **Configure SSL com Certbot**
```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d api.seudominio.com.br
```

## 🔒 Segurança

### Checklist de Segurança

- [ ] Altere todas as secrets em produção
- [ ] Use HTTPS obrigatoriamente
- [ ] Configure rate limiting
- [ ] Habilite verificação de e-mail
- [ ] Configure 2FA para administradores
- [ ] Faça backup regular do banco de dados
- [ ] Mantenha as dependências atualizadas
- [ ] Monitore logs de segurança

### Headers de Segurança

O sistema já inclui:
- Helmet.js para headers de segurança
- CORS configurado
- Proteção XSS
- Content Security Policy

## 📊 Escalabilidade

### Preparado para:
- ✅ Redis para cache e sessões
- ✅ CDN para vídeos (AWS S3, Cloudflare)
- ✅ Load balancing
- ✅ Microsserviços (arquitetura modular)
- ✅ Replicação de banco de dados
- ✅ Filas com Redis/Bull

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🆘 Suporte

Para suporte, envie um e-mail para suporte@eumeria.com.br ou abra uma issue no GitHub.

---

Desenvolvido com ❤️ pela equipe Eumería
