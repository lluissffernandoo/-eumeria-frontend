import { Outlet, Link, useLocation } from 'react-router-dom'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { getInitials } from '@/lib/utils'
import {
  LayoutDashboard,
  BookOpen,
  ShoppingBag,
  Users,
  Settings,
  Link as LinkIcon,
  DollarSign,
  CreditCard,
  LogOut,
  Menu,
  ChevronDown,
  User,
  Package,
  BarChart3,
} from 'lucide-react'
import { useState } from 'react'

interface NavItem {
  label: string
  href: string
  icon: React.ElementType
  roles: string[]
}

const navItems: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard, roles: ['customer', 'affiliate', 'producer', 'master'] },
  { label: 'Meus Cursos', href: '/my-courses', icon: BookOpen, roles: ['customer', 'affiliate', 'producer', 'master'] },
  { label: 'Compras', href: '/purchases', icon: ShoppingBag, roles: ['customer', 'affiliate', 'producer', 'master'] },
  { label: 'Dashboard', href: '/admin', icon: LayoutDashboard, roles: ['master'] },
  { label: 'Usuários', href: '/admin/users', icon: Users, roles: ['master'] },
  { label: 'Produtos', href: '/admin/products', icon: Package, roles: ['master'] },
  { label: 'Vendas', href: '/admin/sales', icon: BarChart3, roles: ['master'] },
  { label: 'Comissões', href: '/admin/commissions', icon: DollarSign, roles: ['master'] },
  { label: 'Saques', href: '/admin/withdrawals', icon: CreditCard, roles: ['master'] },
  { label: 'Configurações', href: '/admin/settings', icon: Settings, roles: ['master'] },
  { label: 'Dashboard', href: '/producer', icon: LayoutDashboard, roles: ['producer'] },
  { label: 'Meus Produtos', href: '/producer/products', icon: Package, roles: ['producer'] },
  { label: 'Dashboard', href: '/affiliate', icon: LayoutDashboard, roles: ['affiliate'] },
  { label: 'Links', href: '/affiliate/links', icon: LinkIcon, roles: ['affiliate'] },
  { label: 'Comissões', href: '/affiliate/commissions', icon: DollarSign, roles: ['affiliate'] },
]

export default function DashboardLayout() {
  const { user, logout } = useAuth()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const filteredNavItems = navItems.filter(
    (item) => user?.role === 'master' || item.roles.includes(user?.role || '')
  )

  const isActive = (href: string) => location.pathname === href

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <BookOpen className="h-6 w-6 text-primary" />
        <span className="text-xl font-bold">Eumería</span>
      </div>
      <nav className="flex-1 space-y-1 p-4">
        {filteredNavItems.map((item) => (
          <Link
            key={item.href}
            to={item.href}
            className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
              isActive(item.href)
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            }`}
            onClick={() => setSidebarOpen(false)}
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  )

  return (
    <div className="flex h-screen">
      {/* Desktop Sidebar */}
      <aside className="hidden w-64 border-r bg-background lg:block">
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="w-64 p-0">
          <SidebarContent />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Header */}
        <header className="flex h-16 items-center justify-between border-b bg-background px-4 lg:px-6">
          <div className="flex items-center gap-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 p-0">
                <SidebarContent />
              </SheetContent>
            </Sheet>
          </div>

          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar || ''} alt={user?.fullName} />
                    <AvatarFallback>{getInitials(user?.fullName || '')}</AvatarFallback>
                  </Avatar>
                  <span className="hidden md:inline">{user?.fullName}</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center gap-2 p-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar || ''} alt={user?.fullName} />
                    <AvatarFallback>{getInitials(user?.fullName || '')}</AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <p className="text-sm font-medium">{user?.fullName}</p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/profile">
                    <User className="mr-2 h-4 w-4" />
                    Perfil
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/dashboard">
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    Dashboard
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
