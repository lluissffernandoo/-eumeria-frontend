export interface User {
  id: string
  email: string
  firstName: string
  lastName: string
  fullName: string
  role: 'master' | 'producer' | 'affiliate' | 'customer'
  avatar: string | null
  emailVerified: boolean
  twoFactorEnabled: boolean
  phone?: string
  document?: string
  createdAt: string
}

export interface Product {
  id: string
  name: string
  slug: string
  description: string
  shortDescription: string
  type: 'digital' | 'course' | 'ebook' | 'software' | 'membership' | 'bundle'
  status: 'draft' | 'pending' | 'approved' | 'published' | 'unpublished'
  price: number
  comparePrice?: number
  currency: string
  coverImage?: string
  galleryImages?: string[]
  previewVideo?: string
  commissionRate: number
  platformFee: number
  allowAffiliates: boolean
  guaranteeDays: number
  viewCount: number
  salesCount: number
  totalRevenue: number
  averageRating?: number
  reviewCount: number
  producerId: string
  producer?: User
  categoryId?: string
  category?: Category
  createdAt: string
  updatedAt: string
}

export interface Category {
  id: string
  name: string
  slug: string
  description?: string
  image?: string
  icon?: string
  color?: string
  status: 'active' | 'inactive'
  sortOrder: number
  parentId?: string
  children?: Category[]
}

export interface Course {
  id: string
  title: string
  slug: string
  description: string
  shortDescription: string
  status: 'draft' | 'pending' | 'approved' | 'published'
  level: 'beginner' | 'intermediate' | 'advanced' | 'all_levels'
  coverImage?: string
  trailerVideo?: string
  totalDuration: number
  lessonCount: number
  moduleCount: number
  hasCertificate: boolean
  enrollmentCount: number
  averageRating?: number
  reviewCount: number
  productId?: string
  categoryId?: string
  category?: Category
  modules?: Module[]
}

export interface Module {
  id: string
  title: string
  description?: string
  sortOrder: number
  isPublished: boolean
  isFree: boolean
  duration: number
  lessonCount: number
  courseId: string
  lessons?: Lesson[]
}

export interface Lesson {
  id: string
  title: string
  description?: string
  type: 'video' | 'audio' | 'text' | 'pdf' | 'quiz' | 'assignment' | 'live'
  sortOrder: number
  isPublished: boolean
  isFree: boolean
  videoProvider: 'local' | 'youtube' | 'vimeo' | 'wistia' | 'pandavideo'
  videoUrl?: string
  videoFile?: string
  duration?: number
  thumbnail?: string
  content?: string
  attachments?: Attachment[]
  downloads?: Download[]
  isPreview: boolean
  viewCount: number
  moduleId: string
}

export interface Attachment {
  name: string
  url: string
  size: number
  type: string
}

export interface Download {
  name: string
  url: string
  size: number
}

export interface Affiliate {
  id: string
  code: string
  status: 'pending' | 'approved' | 'rejected' | 'blocked'
  tier: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond'
  bio?: string
  website?: string
  totalClicks: number
  totalConversions: number
  conversionRate: number
  totalCommission: number
  pendingCommission: number
  availableCommission: number
  withdrawnCommission: number
  userId: string
  user?: User
}

export interface Sale {
  id: string
  orderNumber: string
  status: string
  originalPrice: number
  discountAmount: number
  finalPrice: number
  currency: string
  paymentMethod: string
  paymentStatus: string
  paidAt?: string
  refundedAt?: string
  refundedAmount?: number
  platformFee: number
  affiliateCommission: number
  producerRevenue: number
  hasAffiliate: boolean
  affiliateCode?: string
  guaranteeDays: number
  guaranteeExpiresAt?: string
  customerId: string
  customer?: User
  productId: string
  product?: Product
  affiliateId?: string
  affiliate?: Affiliate
  createdAt: string
}

export interface Commission {
  id: string
  type: 'affiliate' | 'producer' | 'platform' | 'bonus'
  status: 'pending' | 'approved' | 'available' | 'withdrawn' | 'cancelled'
  amount: number
  rate: number
  currency: string
  saleAmount: number
  orderNumber: string
  productName: string
  approvedAt?: string
  availableAt?: string
  withdrawnAt?: string
  affiliateId?: string
  affiliate?: Affiliate
  saleId: string
  sale?: Sale
  createdAt: string
}

export interface Withdrawal {
  id: string
  referenceNumber: string
  status: 'pending' | 'processing' | 'approved' | 'completed' | 'rejected' | 'failed'
  method: 'bank_transfer' | 'pix' | 'paypal' | 'stripe'
  amount: number
  fee: number
  netAmount: number
  currency: string
  bankName?: string
  pixKey?: string
  processedAt?: string
  transactionId?: string
  receiptUrl?: string
  rejectionReason?: string
  commissionIds: string[]
  commissionCount: number
  userId: string
  createdAt: string
}

export interface Coupon {
  id: string
  code: string
  name: string
  description?: string
  type: 'percentage' | 'fixed' | 'free_shipping'
  status: 'active' | 'inactive' | 'expired' | 'depleted'
  scope: 'global' | 'product' | 'category' | 'user'
  discountPercentage?: number
  discountFixed?: number
  maxDiscountAmount?: number
  minOrderAmount?: number
  maxUses?: number
  usedCount: number
  startDate?: string
  endDate?: string
  firstPurchaseOnly: boolean
  isAffiliateCoupon: boolean
  productId?: string
  product?: Product
  createdAt: string
}

export interface Enrollment {
  id: string
  status: 'active' | 'completed' | 'expired' | 'cancelled'
  completedAt?: string
  expiresAt?: string
  progressPercentage: number
  completedLessons: number
  totalLessons: number
  timeSpent: number
  lastAccessedAt?: string
  certificateIssued: boolean
  certificateNumber?: string
  certificateUrl?: string
  purchasePrice: number
  userId: string
  courseId: string
  course?: Course
  createdAt: string
}

export interface DashboardStats {
  totalSales: number
  totalRevenue: number
  totalCustomers: number
  totalProducts: number
  recentSales: Sale[]
  topProducts: Product[]
}

export interface AffiliateStats {
  totalClicks: number
  totalConversions: number
  conversionRate: number
  totalCommission: number
  availableCommission: number
  pendingCommission: number
  recentCommissions: Commission[]
  topLinks: { code: string; clicks: number; conversions: number }[]
}
