import { useParams } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { formatCurrency } from '@/lib/utils'
import { Check, Star, Play, Users, Clock, Shield } from 'lucide-react'

const product = {
  id: '1',
  name: 'Curso Completo de React',
  description: 'Aprenda React do zero ao avançado com projetos práticos. Este curso abrange tudo desde os fundamentos até conceitos avançados como hooks, context API, e muito mais.',
  price: 297,
  comparePrice: 497,
  coverImage: null,
  category: 'Programação',
  rating: 4.8,
  reviewCount: 128,
  salesCount: 456,
  duration: '24 horas',
  lessonsCount: 45,
  guaranteeDays: 7,
  producer: {
    name: 'João Professor',
    avatar: null,
  },
  includes: [
    '24 horas de conteúdo',
    '45 aulas em vídeo',
    'Certificado de conclusão',
    'Acesso vitalício',
    'Suporte ao aluno',
    'Projetos práticos',
  ],
}

export default function ProductDetail() {
  const { slug } = useParams()

  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2">
          <div className="aspect-video bg-muted rounded-lg flex items-center justify-center mb-6">
            <Play className="h-16 w-16 text-muted-foreground" />
          </div>

          <div className="mb-6">
            <Badge className="mb-2">{product.category}</Badge>
            <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-1">
                <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                <span className="font-medium">{product.rating}</span>
              </div>
              <span className="text-muted-foreground">({product.reviewCount} avaliações)</span>
              <span className="text-muted-foreground">• {product.salesCount} alunos</span>
            </div>
            <p className="text-muted-foreground">{product.description}</p>
          </div>

          <Tabs defaultValue="content">
            <TabsList>
              <TabsTrigger value="content">Conteúdo</TabsTrigger>
              <TabsTrigger value="reviews">Avaliações</TabsTrigger>
              <TabsTrigger value="instructor">Instrutor</TabsTrigger>
            </TabsList>

            <TabsContent value="content" className="mt-6">
              <h3 className="text-xl font-semibold mb-4">O que você vai aprender</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {product.includes.map((item, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-green-500" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="mt-6">
              <h3 className="text-xl font-semibold mb-4">Avaliações dos Alunos</h3>
              <p className="text-muted-foreground">Em breve...</p>
            </TabsContent>

            <TabsContent value="instructor" className="mt-6">
              <h3 className="text-xl font-semibold mb-4">Sobre o Instrutor</h3>
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
                  <span className="text-xl font-bold">{product.producer.name.charAt(0)}</span>
                </div>
                <div>
                  <p className="font-semibold">{product.producer.name}</p>
                  <p className="text-muted-foreground">Instrutor experiente em desenvolvimento web</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div>
          <Card className="sticky top-4">
            <CardContent className="p-6">
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-3xl font-bold text-primary">
                    {formatCurrency(product.price)}
                  </span>
                  {product.comparePrice > product.price && (
                    <span className="text-lg text-muted-foreground line-through">
                      {formatCurrency(product.comparePrice)}
                    </span>
                  )}
                </div>
                <Badge variant="secondary" className="mb-4">
                  {Math.round((1 - product.price / product.comparePrice) * 100)}% OFF
                </Badge>
              </div>

              <Button className="w-full mb-4" size="lg">
                Comprar Agora
              </Button>

              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>{product.duration} de conteúdo</span>
                </div>
                <div className="flex items-center gap-2">
                  <Play className="h-4 w-4 text-muted-foreground" />
                  <span>{product.lessonsCount} aulas</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span>{product.salesCount} alunos</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-muted-foreground" />
                  <span>Garantia de {product.guaranteeDays} dias</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
