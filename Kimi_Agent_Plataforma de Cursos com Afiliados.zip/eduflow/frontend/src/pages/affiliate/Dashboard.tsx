import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'
import { Link as LinkIcon, DollarSign, MousePointer, TrendingUp } from 'lucide-react'

export default function AffiliateDashboard() {
  const stats = [
    { title: 'Cliques', value: '1.234', icon: MousePointer },
    { title: 'Conversões', value: '56', icon: TrendingUp },
    { title: 'Taxa de Conversão', value: '4.5%', icon: TrendingUp },
    { title: 'Comissões', value: 'R$ 2.456', icon: DollarSign },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard do Afiliado</h1>
          <p className="text-muted-foreground">
            Acompanhe seus links e comissões
          </p>
        </div>
        <Link to="/affiliate/links">
          <Button>
            <LinkIcon className="h-4 w-4 mr-2" />
            Meus Links
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Links Mais Performáticos</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Lista de links...</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Comissões Recentes</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Lista de comissões...</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
