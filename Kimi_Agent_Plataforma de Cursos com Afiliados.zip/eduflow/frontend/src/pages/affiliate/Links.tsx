import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { affiliateService } from '@/services'
import { toast } from 'sonner'
import { Copy, ExternalLink, Plus } from 'lucide-react'

export default function AffiliateLinks() {
  const [links, setLinks] = useState([])
  const [loading, setLoading] = useState(true)
  const [newLinkProductId, setNewLinkProductId] = useState('')

  useEffect(() => {
    loadLinks()
  }, [])

  const loadLinks = async () => {
    try {
      const response = await affiliateService.getLinks()
      setLinks(response.data || [])
    } catch (error) {
      toast.error('Erro ao carregar links')
    } finally {
      setLoading(false)
    }
  }

  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url)
    toast.success('Link copiado para a área de transferência')
  }

  const handleCreateLink = async () => {
    if (!newLinkProductId) {
      toast.error('Selecione um produto')
      return
    }

    try {
      await affiliateService.createLink({ productId: newLinkProductId })
      toast.success('Link criado com sucesso')
      setNewLinkProductId('')
      loadLinks()
    } catch (error) {
      toast.error('Erro ao criar link')
    }
  }

  if (loading) {
    return <div className="flex justify-center p-8">Carregando...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Meus Links</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Criar Novo Link</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              placeholder="ID do Produto"
              value={newLinkProductId}
              onChange={(e) => setNewLinkProductId(e.target.value)}
            />
            <Button onClick={handleCreateLink}>
              <Plus className="mr-2 h-4 w-4" />
              Criar Link
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Links de Afiliado</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="pb-3 text-left">Produto</th>
                  <th className="pb-3 text-left">Link</th>
                  <th className="pb-3 text-left">Cliques</th>
                  <th className="pb-3 text-left">Conversões</th>
                  <th className="pb-3 text-left">Taxa</th>
                  <th className="pb-3 text-left">Receita</th>
                  <th className="pb-3 text-left">Comissão</th>
                  <th className="pb-3 text-left">Ações</th>
                </tr>
              </thead>
              <tbody>
                {links.map((link: any) => (
                  <tr key={link.id} className="border-b">
                    <td className="py-3">
                      <div className="flex items-center gap-3">
                        {link.product?.coverImage && (
                          <img
                            src={link.product.coverImage}
                            alt={link.product.name}
                            className="h-10 w-10 rounded object-cover"
                          />
                        )}
                        <div>
                          <p className="font-medium">{link.product?.name}</p>
                          <p className="text-sm text-gray-500">
                            {link.commissionRate}% comissão
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3">
                      <code className="rounded bg-gray-100 px-2 py-1 text-sm">
                        {link.url}
                      </code>
                    </td>
                    <td className="py-3">{link.clicks}</td>
                    <td className="py-3">{link.conversions}</td>
                    <td className="py-3">
                      {link.conversionRate?.toFixed(2)}%
                    </td>
                    <td className="py-3">
                      R$ {(link.revenue || 0).toFixed(2)}
                    </td>
                    <td className="py-3">
                      R$ {(link.commission || 0).toFixed(2)}
                    </td>
                    <td className="py-3">
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyLink(link.url)}
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => window.open(link.url, '_blank')}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
