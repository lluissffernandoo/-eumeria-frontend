import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { affiliateService, withdrawalService } from '@/services'
import { toast } from 'sonner'
import { Wallet } from 'lucide-react'

export default function AffiliateCommissions() {
  const [commissions, setCommissions] = useState([])
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [commissionsResponse, statsResponse] = await Promise.all([
        affiliateService.getCommissions(),
        affiliateService.getStats(),
      ])
      setCommissions(commissionsResponse.data || [])
      setStats(statsResponse.data)
    } catch (error) {
      toast.error('Erro ao carregar comissões')
    } finally {
      setLoading(false)
    }
  }

  const handleRequestWithdrawal = async () => {
    if (!stats?.availableCommission || stats.availableCommission < 50) {
      toast.error('Saldo mínimo para saque é R$ 50,00')
      return
    }

    // Navigate to withdrawal page or open modal
    toast.info('Redirecionando para página de saque...')
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-blue-100 text-blue-800',
      available: 'bg-green-100 text-green-800',
      withdrawn: 'bg-gray-100 text-gray-800',
      cancelled: 'bg-red-100 text-red-800',
      refunded: 'bg-gray-100 text-gray-800',
    }
    return (
      <Badge className={variants[status] || 'bg-gray-100'}>
        {status === 'pending' ? 'Pendente' :
         status === 'approved' ? 'Aprovada' :
         status === 'available' ? 'Disponível' :
         status === 'withdrawn' ? 'Sacada' :
         status === 'cancelled' ? 'Cancelada' : 'Reembolsada'}
      </Badge>
    )
  }

  if (loading) {
    return <div className="flex justify-center p-8">Carregando...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Minhas Comissões</h1>
        <Button onClick={handleRequestWithdrawal}>
          <Wallet className="mr-2 h-4 w-4" />
          Solicitar Saque
        </Button>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total em Vendas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.totalSales || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Comissão Total</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">
                R$ {(stats.totalCommission || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pendente</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">
                R$ {(stats.pendingCommission || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Disponível para Saque</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">
                R$ {(stats.availableCommission || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Histórico de Comissões</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="pb-3 text-left">Pedido</th>
                  <th className="pb-3 text-left">Produto</th>
                  <th className="pb-3 text-left">Valor da Venda</th>
                  <th className="pb-3 text-left">Comissão</th>
                  <th className="pb-3 text-left">Taxa</th>
                  <th className="pb-3 text-left">Status</th>
                  <th className="pb-3 text-left">Data</th>
                </tr>
              </thead>
              <tbody>
                {commissions.map((commission: any) => (
                  <tr key={commission.id} className="border-b">
                    <td className="py-3 font-medium">{commission.orderNumber}</td>
                    <td className="py-3">{commission.productName}</td>
                    <td className="py-3">
                      R$ {Number(commission.saleAmount).toFixed(2)}
                    </td>
                    <td className="py-3 font-medium text-green-600">
                      R$ {Number(commission.amount).toFixed(2)}
                    </td>
                    <td className="py-3">{commission.rate}%</td>
                    <td className="py-3">{getStatusBadge(commission.status)}</td>
                    <td className="py-3">
                      {new Date(commission.createdAt).toLocaleDateString('pt-BR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
