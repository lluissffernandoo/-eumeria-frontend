import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { formatCurrency } from '@/lib/utils'
import { Search, Filter, Star } from 'lucide-react'

const products = [
  {
    id: '1',
    name: 'Curso Completo de React',
    slug: 'curso-completo-react',
    description: 'Aprenda React do zero ao avançado com projetos práticos.',
    price: 297,
    comparePrice: 497,
    coverImage: null,
    category: 'Programação',
    rating: 4.8,
    reviewCount: 128,
    salesCount: 456,
  },
  {
    id: '2',
    name: 'Node.js para Iniciantes',
    slug: 'nodejs-para-iniciantes',
    description: 'Domine o backend com Node.js, Express e MongoDB.',
    price: 197,
    comparePrice: 347,
    coverImage: null,
    category: 'Programação',
    rating: 4.6,
    reviewCount: 89,
    salesCount: 234,
  },
  {
    id: '3',
    name: 'TypeScript do Zero',
    slug: 'typescript-do-zero',
    description: 'Aprenda TypeScript e torne seu código mais seguro.',
    price: 147,
    comparePrice: 247,
    coverImage: null,
    category: 'Programação',
    rating: 4.9,
    reviewCount: 67,
    salesCount: 189,
  },
]

export default function Products() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Cursos e Produtos</h1>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar cursos..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filtros
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="overflow-hidden group">
            <Link to={`/products/${product.slug}`}>
              <div className="aspect-video bg-muted flex items-center justify-center relative overflow-hidden">
                {product.coverImage ? (
                  <img 
                    src={product.coverImage} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                ) : (
                  <div className="text-muted-foreground text-4xl font-bold">
                    {product.name.charAt(0)}
                  </div>
                )}
                <Badge className="absolute top-2 right-2">
                  {product.category}
                </Badge>
              </div>
            </Link>
            <CardContent className="p-4">
              <Link to={`/products/${product.slug}`}>
                <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                  {product.name}
                </h3>
              </Link>
              <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                {product.description}
              </p>
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm font-medium">{product.rating}</span>
                </div>
                <span className="text-sm text-muted-foreground">
                  ({product.reviewCount} avaliações)
                </span>
                <span className="text-sm text-muted-foreground">
                  • {product.salesCount} vendas
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl font-bold text-primary">
                    {formatCurrency(product.price)}
                  </span>
                  {product.comparePrice > product.price && (
                    <span className="text-sm text-muted-foreground line-through">
                      {formatCurrency(product.comparePrice)}
                    </span>
                  )}
                </div>
                <Link to={`/products/${product.slug}`}>
                  <Button>Ver Detalhes</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
