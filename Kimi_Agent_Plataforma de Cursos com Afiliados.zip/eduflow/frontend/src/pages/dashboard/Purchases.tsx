import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatCurrency, formatDate } from '@/lib/utils'
import { Download, FileText } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Purchases() {
  const purchases = [
    {
      id: 'ORD-001',
      product: 'Curso de React Completo',
      date: '2024-01-15',
      amount: 297.00,
      status: 'completed',
      paymentMethod: 'Cartão de Crédito',
    },
    {
      id: 'ORD-002',
      product: 'Ebook de TypeScript',
      date: '2024-01-10',
      amount: 47.00,
      status: 'completed',
      paymentMethod: 'PIX',
    },
    {
      id: 'ORD-003',
      product: 'Curso de Node.js',
      date: '2024-01-05',
      amount: 197.00,
      status: 'completed',
      paymentMethod: 'Boleto',
    },
  ]

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      completed: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      failed: 'bg-red-100 text-red-800',
      refunded: 'bg-gray-100 text-gray-800',
    }
    const labels: Record<string, string> = {
      completed: 'Concluído',
      pending: 'Pendente',
      failed: 'Falhou',
      refunded: 'Reembolsado',
    }
    return (
      <Badge className={styles[status] || 'bg-gray-100'}>
        {labels[status] || status}
      </Badge>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Histórico de Compras</h1>
        <p className="text-muted-foreground">
          Veja todas as suas compras e acesse os produtos
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Compras Realizadas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {purchases.map((purchase) => (
              <div
                key={purchase.id}
                className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg gap-4"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold">{purchase.product}</span>
                    {getStatusBadge(purchase.status)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Pedido: {purchase.id} • {formatDate(purchase.date)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Pagamento: {purchase.paymentMethod}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-semibold">{formatCurrency(purchase.amount)}</span>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <FileText className="h-4 w-4 mr-2" />
                      Nota
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
