import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Play, Award, Clock } from 'lucide-react'
import { Link } from 'react-router-dom'

export default function MyCourses() {
  const courses = [
    { id: 1, title: 'Curso de React', progress: 75, totalLessons: 20, completedLessons: 15, duration: '12h', image: null },
    { id: 2, title: 'Curso de Node.js', progress: 30, totalLessons: 15, completedLessons: 5, duration: '8h', image: null },
    { id: 3, title: 'Curso de TypeScript', progress: 100, totalLessons: 10, completedLessons: 10, duration: '5h', image: null, completed: true },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Meus Cursos</h1>
        <p className="text-muted-foreground">
          Acesse todos os cursos que você comprou
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => (
          <Card key={course.id} className="overflow-hidden">
            <div className="aspect-video bg-muted flex items-center justify-center">
              {course.image ? (
                <img src={course.image} alt={course.title} className="w-full h-full object-cover" />
              ) : (
                <Play className="h-12 w-12 text-muted-foreground" />
              )}
            </div>
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-semibold">{course.title}</h3>
                {course.completed && <Award className="h-5 w-5 text-yellow-500" />}
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {course.duration}
                </span>
                <span>{course.completedLessons}/{course.totalLessons} aulas</span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progresso</span>
                  <span>{course.progress}%</span>
                </div>
                <Progress value={course.progress} />
              </div>
              <div className="mt-4">
                <Link to={`/courses/${course.id}`}>
                  <Button className="w-full">
                    {course.completed ? 'Revisar Curso' : 'Continuar'}
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
