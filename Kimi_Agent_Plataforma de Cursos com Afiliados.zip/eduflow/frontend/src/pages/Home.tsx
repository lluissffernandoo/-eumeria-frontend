import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { BookOpen, Users, TrendingUp, Shield, Star, CheckCircle } from 'lucide-react'

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 bg-gradient-to-b from-primary/10 to-background">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                Aprenda com os melhores
              </h1>
              <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                Plataforma completa de cursos online e produtos digitais. 
                Aprenda no seu ritmo, onde e quando quiser.
              </p>
            </div>
            <div className="space-x-4">
              <Link to="/products">
                <Button size="lg">Explorar Cursos</Button>
              </Link>
              <Link to="/register">
                <Button variant="outline" size="lg">
                  Criar Conta
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 lg:py-24">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Por que escolher a Eumería?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Uma plataforma completa para quem quer aprender e ensinar
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="pt-6">
                <BookOpen className="h-10 w-10 text-primary mb-4" />
                <h3 className="font-semibold mb-2">Cursos de Qualidade</h3>
                <p className="text-sm text-muted-foreground">
                  Conteúdo produzido por especialistas em diversas áreas
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <Users className="h-10 w-10 text-primary mb-4" />
                <h3 className="font-semibold mb-2">Comunidade Ativa</h3>
                <p className="text-sm text-muted-foreground">
                  Conecte-se com outros alunos e professores
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <TrendingUp className="h-10 w-10 text-primary mb-4" />
                <h3 className="font-semibold mb-2">Aprenda no Seu Ritmo</h3>
                <p className="text-sm text-muted-foreground">
                  Acesso ilimitado aos cursos que você comprar
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <Shield className="h-10 w-10 text-primary mb-4" />
                <h3 className="font-semibold mb-2">Garantia de 7 Dias</h3>
                <p className="text-sm text-muted-foreground">
                  Satisfação garantida ou seu dinheiro de volta
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">10k+</div>
              <div className="text-sm text-muted-foreground">Alunos</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-sm text-muted-foreground">Cursos</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">100+</div>
              <div className="text-sm text-muted-foreground">Professores</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">50k+</div>
              <div className="text-sm text-muted-foreground">Vendas</div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 lg:py-24">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">O que dizem nossos alunos</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">
                    "Plataforma incrível! Os cursos são de alta qualidade e os professores são muito competentes."
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="font-semibold text-primary">A{i}</span>
                    </div>
                    <div>
                      <p className="font-semibold">Aluno {i}</p>
                      <p className="text-sm text-muted-foreground">Estudante</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 lg:py-24">
        <div className="container px-4 md:px-6">
          <div className="bg-primary rounded-2xl p-8 md:p-12 text-center text-primary-foreground">
            <h2 className="text-3xl font-bold mb-4">Pronto para começar?</h2>
            <p className="max-w-2xl mx-auto mb-8 opacity-90">
              Crie sua conta gratuita e comece a aprender hoje mesmo. 
              Ou torne-se um produtor e compartilhe seu conhecimento.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" variant="secondary">
                  Criar Conta Grátis
                </Button>
              </Link>
              <Link to="/products">
                <Button size="lg" variant="outline" className="border-primary-foreground hover:bg-primary-foreground hover:text-primary">
                  Ver Cursos
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-muted">
        <div className="container px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Como funciona</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Em poucos passos você começa a aprender
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { step: '1', title: 'Crie sua conta', desc: 'Cadastro rápido e gratuito' },
              { step: '2', title: 'Escolha um curso', desc: 'Navegue entre as categorias' },
              { step: '3', title: 'Faça o pagamento', desc: 'Pagamento seguro e rápido' },
              { step: '4', title: 'Comece a aprender', desc: 'Acesso imediato ao conteúdo' },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xl font-bold mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits List */}
      <section className="py-16 lg:py-24">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">
                Tudo que você precisa em uma só plataforma
              </h2>
              <ul className="space-y-4">
                {[
                  'Acesso vitalício aos cursos comprados',
                  'Certificado de conclusão',
                  'Suporte ao aluno dedicado',
                  'Conteúdo atualizado regularmente',
                  'App mobile para assistir em qualquer lugar',
                  'Comunidade exclusiva de alunos',
                ].map((benefit, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-muted rounded-2xl p-8">
              <div className="aspect-video bg-primary/10 rounded-lg flex items-center justify-center">
                <BookOpen className="h-20 w-20 text-primary/50" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
