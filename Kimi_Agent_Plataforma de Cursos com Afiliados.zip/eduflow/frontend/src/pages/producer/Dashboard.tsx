import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'
import { Package, DollarSign, Users, TrendingUp, Plus } from 'lucide-react'

export default function ProducerDashboard() {
  const stats = [
    { title: 'Meus Produtos', value: '12', icon: Package },
    { title: 'Vendas', value: '456', icon: TrendingUp },
    { title: 'Receita', value: 'R$ 23.456', icon: DollarSign },
    { title: 'Alunos', value: '1.234', icon: Users },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard do Produtor</h1>
          <p className="text-muted-foreground">
            Gerencie seus produtos e acompanhe suas vendas
          </p>
        </div>
        <Link to="/producer/products/create">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Novo Produto
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Vendas Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Lista de vendas recentes...</p>
        </CardContent>
      </Card>
    </div>
  )
}
