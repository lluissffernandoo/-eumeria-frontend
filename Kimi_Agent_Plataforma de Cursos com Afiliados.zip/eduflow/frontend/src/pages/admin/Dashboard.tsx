import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Users, 
  ShoppingCart, 
  DollarSign, 
  TrendingUp,
  Package,
  CreditCard
} from 'lucide-react'

export default function AdminDashboard() {
  const stats = [
    { title: 'Usuários', value: '1,234', icon: Users, change: '+12%' },
    { title: 'Vendas', value: '567', icon: ShoppingCart, change: '+8%' },
    { title: 'Receita', value: 'R$ 45.678', icon: DollarSign, change: '+23%' },
    { title: 'Produtos', value: '89', icon: Package, change: '+5%' },
  ]

  const recentSales = [
    { id: 'ORD-001', customer: 'João Silva', product: 'Curso de React', amount: 297, date: '2024-01-15' },
    { id: 'ORD-002', customer: 'Maria Santos', product: 'Ebook TypeScript', amount: 47, date: '2024-01-14' },
    { id: 'ORD-003', customer: 'Pedro Costa', product: 'Curso Node.js', amount: 197, date: '2024-01-13' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard Administrativo</h1>
        <p className="text-muted-foreground">
          Visão geral da plataforma
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-green-500">{stat.change} este mês</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="sales">
        <TabsList>
          <TabsTrigger value="sales">Vendas Recentes</TabsTrigger>
          <TabsTrigger value="users">Novos Usuários</TabsTrigger>
          <TabsTrigger value="products">Produtos Populares</TabsTrigger>
        </TabsList>

        <TabsContent value="sales">
          <Card>
            <CardHeader>
              <CardTitle>Vendas Recentes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentSales.map((sale) => (
                  <div key={sale.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-semibold">{sale.product}</p>
                      <p className="text-sm text-muted-foreground">{sale.customer} • {sale.id}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">R$ {sale.amount}</p>
                      <p className="text-sm text-muted-foreground">{sale.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>Novos Usuários</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Lista de novos usuários...</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products">
          <Card>
            <CardHeader>
              <CardTitle>Produtos Populares</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Lista de produtos populares...</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
