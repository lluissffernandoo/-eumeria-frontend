import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Search, Plus, MoreHorizontal } from 'lucide-react'

const users = [
  { id: '1', name: 'João Silva', email: 'joao@email.com', role: 'customer', status: 'active' },
  { id: '2', name: 'Maria Santos', email: 'maria@email.com', role: 'producer', status: 'active' },
  { id: '3', name: 'Pedro Costa', email: 'pedro@email.com', role: 'affiliate', status: 'pending' },
]

export default function Users() {
  const [searchTerm, setSearchTerm] = useState('')

  const getRoleBadge = (role: string) => {
    const styles: Record<string, string> = {
      master: 'bg-purple-100 text-purple-800',
      producer: 'bg-blue-100 text-blue-800',
      affiliate: 'bg-green-100 text-green-800',
      customer: 'bg-gray-100 text-gray-800',
    }
    const labels: Record<string, string> = {
      master: 'Master',
      producer: 'Produtor',
      affiliate: 'Afiliado',
      customer: 'Cliente',
    }
    return (
      <Badge className={styles[role] || 'bg-gray-100'}>
        {labels[role] || role}
      </Badge>
    )
  }

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-gray-100 text-gray-800',
      pending: 'bg-yellow-100 text-yellow-800',
      blocked: 'bg-red-100 text-red-800',
    }
    return (
      <Badge className={styles[status] || 'bg-gray-100'}>
        {status}
      </Badge>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Usuários</h1>
          <p className="text-muted-foreground">
            Gerencie todos os usuários da plataforma
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Novo Usuário
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar usuários..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>E-mail</TableHead>
                <TableHead>Papel</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-10"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>{getRoleBadge(user.role)}</TableCell>
                  <TableCell>{getStatusBadge(user.status)}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
