import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { saleService } from '@/services'
import { toast } from 'sonner'
import { Search, Download } from 'lucide-react'

export default function AdminSales() {
  const [sales, setSales] = useState([])
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [salesResponse, statsResponse] = await Promise.all([
        saleService.getAll({ limit: 100 }),
        saleService.getStats(),
      ])
      setSales(salesResponse.data || [])
      setStats(statsResponse.data)
    } catch (error) {
      toast.error('Erro ao carregar vendas')
    } finally {
      setLoading(false)
    }
  }

  const filteredSales = sales.filter((sale: any) =>
    sale.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
    sale.customerName.toLowerCase().includes(search.toLowerCase()) ||
    sale.product?.name.toLowerCase().includes(search.toLowerCase())
  )

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      completed: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      processing: 'bg-blue-100 text-blue-800',
      failed: 'bg-red-100 text-red-800',
      refunded: 'bg-gray-100 text-gray-800',
    }
    return (
      <Badge className={variants[status] || 'bg-gray-100'}>
        {status === 'completed' ? 'Concluída' :
         status === 'pending' ? 'Pendente' :
         status === 'processing' ? 'Processando' :
         status === 'failed' ? 'Falhou' : 'Reembolsada'}
      </Badge>
    )
  }

  if (loading) {
    return <div className="flex justify-center p-8">Carregando...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Vendas</h1>
        <Button variant="outline">
          <Download className="mr-2 h-4 w-4" />
          Exportar
        </Button>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total de Vendas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.total?.totalSales || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">
                R$ {(stats.total?.totalRevenue || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Últimos 30 Dias</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.last30Days?.totalSales || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.last30Days?.totalRevenue || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Últimos 7 Dias</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.last7Days?.totalSales || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.last7Days?.totalRevenue || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Todas as Vendas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar vendas..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="pb-3 text-left">Pedido</th>
                  <th className="pb-3 text-left">Cliente</th>
                  <th className="pb-3 text-left">Produto</th>
                  <th className="pb-3 text-left">Valor</th>
                  <th className="pb-3 text-left">Status</th>
                  <th className="pb-3 text-left">Data</th>
                </tr>
              </thead>
              <tbody>
                {filteredSales.map((sale: any) => (
                  <tr key={sale.id} className="border-b">
                    <td className="py-3 font-medium">{sale.orderNumber}</td>
                    <td className="py-3">{sale.customerName}</td>
                    <td className="py-3">{sale.product?.name}</td>
                    <td className="py-3">
                      R$ {Number(sale.finalPrice).toFixed(2)}
                    </td>
                    <td className="py-3">{getStatusBadge(sale.status)}</td>
                    <td className="py-3">
                      {new Date(sale.createdAt).toLocaleDateString('pt-BR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
