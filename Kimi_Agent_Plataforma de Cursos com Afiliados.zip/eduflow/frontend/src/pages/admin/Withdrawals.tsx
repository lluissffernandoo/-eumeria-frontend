import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { withdrawalService } from '@/services'
import { toast } from 'sonner'
import { Search, CheckCircle, XCircle } from 'lucide-react'

export default function AdminWithdrawals() {
  const [withdrawals, setWithdrawals] = useState([])
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [withdrawalsResponse, statsResponse] = await Promise.all([
        withdrawalService.getAll({ limit: 100 }),
        withdrawalService.getStats(),
      ])
      setWithdrawals(withdrawalsResponse.data || [])
      setStats(statsResponse.data)
    } catch (error) {
      toast.error('Erro ao carregar saques')
    } finally {
      setLoading(false)
    }
  }

  const handleApprove = async (id: string) => {
    try {
      await withdrawalService.approve(id)
      toast.success('Saque aprovado com sucesso')
      loadData()
    } catch (error) {
      toast.error('Erro ao aprovar saque')
    }
  }

  const handleComplete = async (id: string) => {
    try {
      await withdrawalService.complete(id)
      toast.success('Saque completado com sucesso')
      loadData()
    } catch (error) {
      toast.error('Erro ao completar saque')
    }
  }

  const handleReject = async (id: string) => {
    const reason = prompt('Motivo da rejeição:')
    if (!reason) return

    try {
      await withdrawalService.reject(id, reason)
      toast.success('Saque rejeitado')
      loadData()
    } catch (error) {
      toast.error('Erro ao rejeitar saque')
    }
  }

  const filteredWithdrawals = withdrawals.filter((withdrawal: any) =>
    withdrawal.affiliate?.user?.name.toLowerCase().includes(search.toLowerCase()) ||
    withdrawal.method.toLowerCase().includes(search.toLowerCase())
  )

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-blue-100 text-blue-800',
      completed: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      cancelled: 'bg-gray-100 text-gray-800',
    }
    return (
      <Badge className={variants[status] || 'bg-gray-100'}>
        {status === 'pending' ? 'Pendente' :
         status === 'approved' ? 'Aprovado' :
         status === 'completed' ? 'Completado' :
         status === 'rejected' ? 'Rejeitado' : 'Cancelado'}
      </Badge>
    )
  }

  if (loading) {
    return <div className="flex justify-center p-8">Carregando...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Saques</h1>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.total?.count || 0}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.pending?.count || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.pending?.amount || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Completados</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.completed?.count || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.completed?.amount || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Rejeitados</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.rejected?.count || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.rejected?.amount || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Todos os Saques</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar saques..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="pb-3 text-left">Afiliado</th>
                  <th className="pb-3 text-left">Valor</th>
                  <th className="pb-3 text-left">Taxa</th>
                  <th className="pb-3 text-left">Líquido</th>
                  <th className="pb-3 text-left">Método</th>
                  <th className="pb-3 text-left">Status</th>
                  <th className="pb-3 text-left">Data</th>
                  <th className="pb-3 text-left">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredWithdrawals.map((withdrawal: any) => (
                  <tr key={withdrawal.id} className="border-b">
                    <td className="py-3">{withdrawal.affiliate?.user?.name}</td>
                    <td className="py-3">
                      R$ {Number(withdrawal.amount).toFixed(2)}
                    </td>
                    <td className="py-3">
                      R$ {Number(withdrawal.fee).toFixed(2)}
                    </td>
                    <td className="py-3">
                      R$ {Number(withdrawal.netAmount).toFixed(2)}
                    </td>
                    <td className="py-3">
                      {withdrawal.method === 'pix' ? 'PIX' :
                       withdrawal.method === 'bank_transfer' ? 'Transferência' :
                       withdrawal.method === 'paypal' ? 'PayPal' : 'Payoneer'}
                    </td>
                    <td className="py-3">{getStatusBadge(withdrawal.status)}</td>
                    <td className="py-3">
                      {new Date(withdrawal.createdAt).toLocaleDateString('pt-BR')}
                    </td>
                    <td className="py-3">
                      <div className="flex gap-2">
                        {withdrawal.status === 'pending' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleApprove(withdrawal.id)}
                          >
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          </Button>
                        )}
                        {withdrawal.status === 'approved' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleComplete(withdrawal.id)}
                          >
                            <CheckCircle className="h-4 w-4 text-blue-500" />
                          </Button>
                        )}
                        {(withdrawal.status === 'pending' || withdrawal.status === 'approved') && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleReject(withdrawal.id)}
                          >
                            <XCircle className="h-4 w-4 text-red-500" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
