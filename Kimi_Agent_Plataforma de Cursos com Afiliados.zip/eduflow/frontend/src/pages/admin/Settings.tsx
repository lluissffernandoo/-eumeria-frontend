import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { toast } from 'sonner'

export default function AdminSettings() {
  const [generalSettings, setGeneralSettings] = useState({
    siteName: 'Eumería',
    siteDescription: 'Plataforma de cursos e produtos digitais',
    contactEmail: 'contato@eumeria.com',
    supportPhone: '(11) 99999-9999',
  })

  const [paymentSettings, setPaymentSettings] = useState({
    currency: 'BRL',
    platformFee: 10,
    affiliateCommission: 30,
    guaranteeDays: 7,
    minWithdrawal: 50,
  })

  const handleSaveGeneral = () => {
    toast.success('Configurações gerais salvas com sucesso')
  }

  const handleSavePayment = () => {
    toast.success('Configurações de pagamento salvas com sucesso')
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Configurações</h1>
      </div>

      <Tabs defaultValue="general">
        <TabsList>
          <TabsTrigger value="general">Geral</TabsTrigger>
          <TabsTrigger value="payment">Pagamento</TabsTrigger>
          <TabsTrigger value="email">Email</TabsTrigger>
          <TabsTrigger value="security">Segurança</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações Gerais</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="siteName">Nome do Site</Label>
                <Input
                  id="siteName"
                  value={generalSettings.siteName}
                  onChange={(e) => setGeneralSettings({ ...generalSettings, siteName: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="siteDescription">Descrição do Site</Label>
                <Input
                  id="siteDescription"
                  value={generalSettings.siteDescription}
                  onChange={(e) => setGeneralSettings({ ...generalSettings, siteDescription: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contactEmail">Email de Contato</Label>
                <Input
                  id="contactEmail"
                  type="email"
                  value={generalSettings.contactEmail}
                  onChange={(e) => setGeneralSettings({ ...generalSettings, contactEmail: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="supportPhone">Telefone de Suporte</Label>
                <Input
                  id="supportPhone"
                  value={generalSettings.supportPhone}
                  onChange={(e) => setGeneralSettings({ ...generalSettings, supportPhone: e.target.value })}
                />
              </div>
              <Button onClick={handleSaveGeneral}>Salvar Alterações</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Pagamento</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currency">Moeda</Label>
                <Input
                  id="currency"
                  value={paymentSettings.currency}
                  onChange={(e) => setPaymentSettings({ ...paymentSettings, currency: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="platformFee">Taxa da Plataforma (%)</Label>
                <Input
                  id="platformFee"
                  type="number"
                  value={paymentSettings.platformFee}
                  onChange={(e) => setPaymentSettings({ ...paymentSettings, platformFee: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="affiliateCommission">Comissão Padrão de Afiliados (%)</Label>
                <Input
                  id="affiliateCommission"
                  type="number"
                  value={paymentSettings.affiliateCommission}
                  onChange={(e) => setPaymentSettings({ ...paymentSettings, affiliateCommission: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="guaranteeDays">Dias de Garantia</Label>
                <Input
                  id="guaranteeDays"
                  type="number"
                  value={paymentSettings.guaranteeDays}
                  onChange={(e) => setPaymentSettings({ ...paymentSettings, guaranteeDays: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="minWithdrawal">Saque Mínimo (R$)</Label>
                <Input
                  id="minWithdrawal"
                  type="number"
                  value={paymentSettings.minWithdrawal}
                  onChange={(e) => setPaymentSettings({ ...paymentSettings, minWithdrawal: Number(e.target.value) })}
                />
              </div>
              <Button onClick={handleSavePayment}>Salvar Alterações</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="email" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Email</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">Configure as configurações de SMTP para envio de emails.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Segurança</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500">Configure opções de segurança da plataforma.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
