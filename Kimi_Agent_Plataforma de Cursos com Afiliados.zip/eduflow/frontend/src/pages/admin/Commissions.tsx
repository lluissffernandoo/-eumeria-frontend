import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { commissionService } from '@/services'
import { toast } from 'sonner'
import { Search, CheckCircle } from 'lucide-react'

export default function AdminCommissions() {
  const [commissions, setCommissions] = useState([])
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [commissionsResponse, statsResponse] = await Promise.all([
        commissionService.getAll({ limit: 100 }),
        commissionService.getStats(),
      ])
      setCommissions(commissionsResponse.data || [])
      setStats(statsResponse.data)
    } catch (error) {
      toast.error('Erro ao carregar comissões')
    } finally {
      setLoading(false)
    }
  }

  const handleApprove = async (id: string) => {
    try {
      await commissionService.approve(id)
      toast.success('Comissão aprovada com sucesso')
      loadData()
    } catch (error) {
      toast.error('Erro ao aprovar comissão')
    }
  }

  const filteredCommissions = commissions.filter((commission: any) =>
    commission.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
    commission.productName.toLowerCase().includes(search.toLowerCase()) ||
    commission.affiliate?.user?.name.toLowerCase().includes(search.toLowerCase())
  )

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-blue-100 text-blue-800',
      available: 'bg-green-100 text-green-800',
      withdrawn: 'bg-gray-100 text-gray-800',
      cancelled: 'bg-red-100 text-red-800',
      refunded: 'bg-gray-100 text-gray-800',
    }
    return (
      <Badge className={variants[status] || 'bg-gray-100'}>
        {status === 'pending' ? 'Pendente' :
         status === 'approved' ? 'Aprovada' :
         status === 'available' ? 'Disponível' :
         status === 'withdrawn' ? 'Sacada' :
         status === 'cancelled' ? 'Cancelada' : 'Reembolsada'}
      </Badge>
    )
  }

  if (loading) {
    return <div className="flex justify-center p-8">Carregando...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Comissões</h1>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.total?.count || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.total?.amount || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pendentes</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.pending?.count || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.pending?.amount || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Disponíveis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.available?.count || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.available?.amount || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Sacadas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats.withdrawn?.count || 0}</p>
              <p className="text-sm text-gray-500">
                R$ {(stats.withdrawn?.amount || 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Todas as Comissões</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar comissões..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="pb-3 text-left">Pedido</th>
                  <th className="pb-3 text-left">Afiliado</th>
                  <th className="pb-3 text-left">Produto</th>
                  <th className="pb-3 text-left">Valor</th>
                  <th className="pb-3 text-left">Taxa</th>
                  <th className="pb-3 text-left">Status</th>
                  <th className="pb-3 text-left">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredCommissions.map((commission: any) => (
                  <tr key={commission.id} className="border-b">
                    <td className="py-3 font-medium">{commission.orderNumber}</td>
                    <td className="py-3">{commission.affiliate?.user?.name || 'N/A'}</td>
                    <td className="py-3">{commission.productName}</td>
                    <td className="py-3">
                      R$ {Number(commission.amount).toFixed(2)}
                    </td>
                    <td className="py-3">{commission.rate}%</td>
                    <td className="py-3">{getStatusBadge(commission.status)}</td>
                    <td className="py-3">
                      {commission.status === 'pending' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleApprove(commission.id)}
                        >
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
