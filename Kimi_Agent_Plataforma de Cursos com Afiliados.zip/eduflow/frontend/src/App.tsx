import { Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/sonner'
import { AuthProvider } from '@/contexts/AuthContext'
import { ThemeProvider } from '@/contexts/ThemeContext'

// Layouts
import MainLayout from '@/layouts/MainLayout'
import DashboardLayout from '@/layouts/DashboardLayout'

// Public Pages
import Home from '@/pages/Home'
import Login from '@/pages/auth/Login'
import Register from '@/pages/auth/Register'
import ForgotPassword from '@/pages/auth/ForgotPassword'
import Products from '@/pages/Products'
import ProductDetail from '@/pages/ProductDetail'

// Protected Pages
import Dashboard from '@/pages/dashboard/Dashboard'
import Profile from '@/pages/dashboard/Profile'
import MyCourses from '@/pages/dashboard/MyCourses'
import Purchases from '@/pages/dashboard/Purchases'

// Admin Pages
import AdminDashboard from '@/pages/admin/Dashboard'
import Users from '@/pages/admin/Users'
import AdminProducts from '@/pages/admin/Products'
import Sales from '@/pages/admin/Sales'
import Commissions from '@/pages/admin/Commissions'
import Withdrawals from '@/pages/admin/Withdrawals'
import Settings from '@/pages/admin/Settings'

// Producer Pages
import ProducerDashboard from '@/pages/producer/Dashboard'
import MyProducts from '@/pages/producer/MyProducts'
import CreateProduct from '@/pages/producer/CreateProduct'
import EditProduct from '@/pages/producer/EditProduct'

// Affiliate Pages
import AffiliateDashboard from '@/pages/affiliate/Dashboard'
import AffiliateLinks from '@/pages/affiliate/Links'
import AffiliateCommissions from '@/pages/affiliate/Commissions'

// Components
import ProtectedRoute from '@/components/ProtectedRoute'
import RoleRoute from '@/components/RoleRoute'

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="eumeria-theme">
      <AuthProvider>
        <Routes>
          {/* Public Routes */}
          <Route element={<MainLayout />}>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/products" element={<Products />} />
            <Route path="/products/:slug" element={<ProductDetail />} />
          </Route>

          {/* Protected Routes - Customer */}
          <Route element={<ProtectedRoute />}>
            <Route element={<DashboardLayout />}>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/my-courses" element={<MyCourses />} />
              <Route path="/purchases" element={<Purchases />} />
            </Route>
          </Route>

          {/* Admin Routes */}
          <Route element={<RoleRoute allowedRoles={['master']} />}>
            <Route element={<DashboardLayout />}>
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/users" element={<Users />} />
              <Route path="/admin/products" element={<AdminProducts />} />
              <Route path="/admin/sales" element={<Sales />} />
              <Route path="/admin/commissions" element={<Commissions />} />
              <Route path="/admin/withdrawals" element={<Withdrawals />} />
              <Route path="/admin/settings" element={<Settings />} />
            </Route>
          </Route>

          {/* Producer Routes */}
          <Route element={<RoleRoute allowedRoles={['master', 'producer']} />}>
            <Route element={<DashboardLayout />}>
              <Route path="/producer" element={<ProducerDashboard />} />
              <Route path="/producer/products" element={<MyProducts />} />
              <Route path="/producer/products/create" element={<CreateProduct />} />
              <Route path="/producer/products/:id/edit" element={<EditProduct />} />
            </Route>
          </Route>

          {/* Affiliate Routes */}
          <Route element={<RoleRoute allowedRoles={['master', 'producer', 'affiliate']} />}>
            <Route element={<DashboardLayout />}>
              <Route path="/affiliate" element={<AffiliateDashboard />} />
              <Route path="/affiliate/links" element={<AffiliateLinks />} />
              <Route path="/affiliate/commissions" element={<AffiliateCommissions />} />
            </Route>
          </Route>
        </Routes>
        <Toaster position="top-right" />
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App
