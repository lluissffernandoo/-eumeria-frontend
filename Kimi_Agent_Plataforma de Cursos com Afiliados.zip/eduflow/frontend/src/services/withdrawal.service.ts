import api from './api'

export const withdrawalService = {
  async create(data: any): Promise<any> {
    const response = await api.post('/withdrawals', data)
    return response.data
  },

  async getAll(filters: any = {}): Promise<any> {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, String(value))
      }
    })
    const response = await api.get(`/withdrawals?${params.toString()}`)
    return response.data
  },

  async getById(id: string): Promise<any> {
    const response = await api.get(`/withdrawals/${id}`)
    return response.data
  },

  async getStats(): Promise<any> {
    const response = await api.get('/withdrawals/stats')
    return response.data
  },

  async cancel(id: string): Promise<any> {
    const response = await api.post(`/withdrawals/${id}/cancel`)
    return response.data
  },
}
