import api from './api'

export const commissionService = {
  async getAll(filters: any = {}): Promise<any> {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, String(value))
      }
    })
    const response = await api.get(`/commissions?${params.toString()}`)
    return response.data
  },

  async getById(id: string): Promise<any> {
    const response = await api.get(`/commissions/${id}`)
    return response.data
  },

  async getStats(): Promise<any> {
    const response = await api.get('/commissions/stats')
    return response.data
  },

  async approve(id: string): Promise<any> {
    const response = await api.post(`/commissions/${id}/approve`)
    return response.data
  },

  async makeAvailable(id: string): Promise<any> {
    const response = await api.post(`/commissions/${id}/make-available`)
    return response.data
  },

  async cancel(id: string, reason: string): Promise<any> {
    const response = await api.post(`/commissions/${id}/cancel`, { reason })
    return response.data
  },
}
