import api from './api'

export interface ProductFilters {
  page?: number
  limit?: number
  category?: string
  search?: string
  minPrice?: number
  maxPrice?: number
  sortBy?: string
  sortOrder?: 'ASC' | 'DESC'
}

export const productService = {
  async getAll(filters: ProductFilters = {}): Promise<any> {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, String(value))
      }
    })
    const response = await api.get(`/products?${params.toString()}`)
    return response.data
  },

  async getById(id: string): Promise<any> {
    const response = await api.get(`/products/${id}`)
    return response.data
  },

  async getBySlug(slug: string): Promise<any> {
    const response = await api.get(`/products/slug/${slug}`)
    return response.data
  },

  async create(data: any): Promise<any> {
    const response = await api.post('/products', data)
    return response.data
  },

  async update(id: string, data: any): Promise<any> {
    const response = await api.patch(`/products/${id}`, data)
    return response.data
  },

  async delete(id: string): Promise<any> {
    const response = await api.delete(`/products/${id}`)
    return response.data
  },

  async getMyProducts(): Promise<any> {
    const response = await api.get('/products/my-products')
    return response.data
  },

  async getStats(): Promise<any> {
    const response = await api.get('/products/stats')
    return response.data
  },
}
