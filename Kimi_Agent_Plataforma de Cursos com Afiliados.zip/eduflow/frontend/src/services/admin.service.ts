import api from './api'

export const adminService = {
  async getDashboardStats(): Promise<any> {
    const response = await api.get('/admin/dashboard')
    return response.data
  },

  async getSalesReport(startDate: string, endDate: string): Promise<any> {
    const response = await api.get('/admin/reports/sales', {
      params: { startDate, endDate },
    })
    return response.data
  },

  async getAffiliateReport(startDate: string, endDate: string): Promise<any> {
    const response = await api.get('/admin/reports/affiliates', {
      params: { startDate, endDate },
    })
    return response.data
  },

  async getRecentActivity(limit: number = 10): Promise<any> {
    const response = await api.get('/admin/activity', {
      params: { limit },
    })
    return response.data
  },

  async getSystemHealth(): Promise<any> {
    const response = await api.get('/admin/health')
    return response.data
  },
}
