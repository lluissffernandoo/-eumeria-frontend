import api from './api'

export const courseService = {
  async getAll(filters: any = {}): Promise<any> {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, String(value))
      }
    })
    const response = await api.get(`/courses?${params.toString()}`)
    return response.data
  },

  async getById(id: string): Promise<any> {
    const response = await api.get(`/courses/${id}`)
    return response.data
  },

  async create(data: any): Promise<any> {
    const response = await api.post('/courses', data)
    return response.data
  },

  async update(id: string, data: any): Promise<any> {
    const response = await api.patch(`/courses/${id}`, data)
    return response.data
  },

  async delete(id: string): Promise<any> {
    const response = await api.delete(`/courses/${id}`)
    return response.data
  },

  // Modules
  async createModule(courseId: string, data: any): Promise<any> {
    const response = await api.post(`/courses/${courseId}/modules`, data)
    return response.data
  },

  async updateModule(courseId: string, moduleId: string, data: any): Promise<any> {
    const response = await api.patch(`/courses/${courseId}/modules/${moduleId}`, data)
    return response.data
  },

  async deleteModule(courseId: string, moduleId: string): Promise<any> {
    const response = await api.delete(`/courses/${courseId}/modules/${moduleId}`)
    return response.data
  },

  // Lessons
  async createLesson(courseId: string, moduleId: string, data: any): Promise<any> {
    const response = await api.post(`/courses/${courseId}/modules/${moduleId}/lessons`, data)
    return response.data
  },

  async updateLesson(courseId: string, moduleId: string, lessonId: string, data: any): Promise<any> {
    const response = await api.patch(`/courses/${courseId}/modules/${moduleId}/lessons/${lessonId}`, data)
    return response.data
  },

  async deleteLesson(courseId: string, moduleId: string, lessonId: string): Promise<any> {
    const response = await api.delete(`/courses/${courseId}/modules/${moduleId}/lessons/${lessonId}`)
    return response.data
  },
}
