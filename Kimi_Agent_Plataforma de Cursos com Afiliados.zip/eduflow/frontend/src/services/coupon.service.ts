import api from './api'

export const couponService = {
  async getAll(filters: any = {}): Promise<any> {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, String(value))
      }
    })
    const response = await api.get(`/coupons?${params.toString()}`)
    return response.data
  },

  async getById(id: string): Promise<any> {
    const response = await api.get(`/coupons/${id}`)
    return response.data
  },

  async getByCode(code: string): Promise<any> {
    const response = await api.get(`/coupons/code/${code}`)
    return response.data
  },

  async create(data: any): Promise<any> {
    const response = await api.post('/coupons', data)
    return response.data
  },

  async update(id: string, data: any): Promise<any> {
    const response = await api.patch(`/coupons/${id}`, data)
    return response.data
  },

  async delete(id: string): Promise<any> {
    const response = await api.delete(`/coupons/${id}`)
    return response.data
  },

  async validate(code: string, productId: string, amount: number): Promise<any> {
    const response = await api.get('/coupons/validate', {
      params: { code, productId, amount },
    })
    return response.data
  },

  async getStats(): Promise<any> {
    const response = await api.get('/coupons/stats')
    return response.data
  },
}
