import api from './api'

export const memberService = {
  async getMyCourses(): Promise<any> {
    const response = await api.get('/members/my-courses')
    return response.data
  },

  async getCourseContent(courseId: string): Promise<any> {
    const response = await api.get(`/members/my-courses/${courseId}`)
    return response.data
  },

  async getLesson(lessonId: string): Promise<any> {
    const response = await api.get(`/members/lessons/${lessonId}`)
    return response.data
  },

  async updateProgress(lessonId: string, data: any): Promise<any> {
    const response = await api.patch(`/members/lessons/${lessonId}/progress`, data)
    return response.data
  },

  async getMyProducts(): Promise<any> {
    const response = await api.get('/members/my-products')
    return response.data
  },

  async getProductDownload(productId: string): Promise<any> {
    const response = await api.get(`/members/my-products/${productId}/download`)
    return response.data
  },

  async getStats(): Promise<any> {
    const response = await api.get('/members/stats')
    return response.data
  },
}
