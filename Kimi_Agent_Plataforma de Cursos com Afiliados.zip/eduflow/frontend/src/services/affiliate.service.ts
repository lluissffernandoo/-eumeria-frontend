import api from './api'

export const affiliateService = {
  async register(data: any): Promise<any> {
    const response = await api.post('/affiliates/register', data)
    return response.data
  },

  async getProfile(): Promise<any> {
    const response = await api.get('/affiliates/profile')
    return response.data
  },

  async updateProfile(data: any): Promise<any> {
    const response = await api.patch('/affiliates/profile', data)
    return response.data
  },

  async getLinks(): Promise<any> {
    const response = await api.get('/affiliates/links')
    return response.data
  },

  async createLink(data: any): Promise<any> {
    const response = await api.post('/affiliates/links', data)
    return response.data
  },

  async getClicks(filters: any = {}): Promise<any> {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, String(value))
      }
    })
    const response = await api.get(`/affiliates/clicks?${params.toString()}`)
    return response.data
  },

  async getCommissions(filters: any = {}): Promise<any> {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, String(value))
      }
    })
    const response = await api.get(`/affiliates/commissions?${params.toString()}`)
    return response.data
  },

  async getStats(): Promise<any> {
    const response = await api.get('/affiliates/stats')
    return response.data
  },

  async getDashboard(): Promise<any> {
    const response = await api.get('/affiliates/dashboard')
    return response.data
  },
}
