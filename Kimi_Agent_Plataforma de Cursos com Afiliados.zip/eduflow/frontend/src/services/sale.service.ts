import api from './api'

export const saleService = {
  async create(data: any): Promise<any> {
    const response = await api.post('/sales', data)
    return response.data
  },

  async getAll(filters: any = {}): Promise<any> {
    const params = new URLSearchParams()
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined) {
        params.append(key, String(value))
      }
    })
    const response = await api.get(`/sales?${params.toString()}`)
    return response.data
  },

  async getById(id: string): Promise<any> {
    const response = await api.get(`/sales/${id}`)
    return response.data
  },

  async getByOrderNumber(orderNumber: string): Promise<any> {
    const response = await api.get(`/sales/order/${orderNumber}`)
    return response.data
  },

  async getStats(): Promise<any> {
    const response = await api.get('/sales/stats')
    return response.data
  },

  async refund(id: string, data: any): Promise<any> {
    const response = await api.post(`/sales/${id}/refund`, data)
    return response.data
  },
}
